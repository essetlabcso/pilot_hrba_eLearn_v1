# Module 6 Design and Visual Interaction Specification

## Module title

**Module 6: Applying HRBA During Implementation**

## Design purpose

Module 6 should feel like a practical implementation support studio. It should help local CSO practitioners keep participation, inclusion, feedback, accountability, safe engagement, adaptation, and do-no-harm documentation alive during delivery.

The visual experience should not feel like a static project management manual, a compliance checklist, or a generic LMS page. It should feel like a guided, safe, premium learning journey focused on day-to-day CSO practice.

## Visual identity

| Use | Color |
|---|---|
| Primary action / active progress | `#3B99D4` |
| Positive accent / completion / growth | `#91C852` |
| Deep heading / navigation text | `#0F172A` |
| Main text | `#111827` |
| Secondary text | `#6B7280` |
| Background | `#F9FAFB` |
| Card background | `#FFFFFF` |
| Border | `#E5E7EB` |
| Warning / safety accent | `#F97316` |
| Critical safety warning only | `#EF4444` |

## Source visual interaction controls

| Implementation area | Required instruction | Acceptance check | Source/evidence | Status | Notes |
| --- | --- | --- | --- | --- | --- |
| Global visual system | Use DEC/CSO Learning Hub visual identity: #3B99D4, #91C852, #0F172A, #F9FAFB, white cards, #111827 text, #E5E7EB borders, rounded corners, soft shadows. | Visuals match course system and do not look like generic LMS pages. | Course Player Spec; landing/design specs | Approved | No new color system. |
| Layout | Use learner-facing course player: left navigation/progress, main canvas, optional resource/notes drawer. | Module renders inside existing course player route. | Course Player Spec | Approved | /learn/courses/applying-hrba-local-cso-practice?lesson=M06-L01 |
| Lesson pattern | Each lesson contains explain + practice/apply + check + safety where relevant. | No text-only lesson. | Annex 6 Build Studio | Approved | Core build rule. |
| Scenario style | Use compact narrative cards with fictional CSO situations. | No real organizations or sensitive local actors. | Prompt; Annex 12 | Approved | Avoid sensationalism. |
| Process behavior | Processes reveal steps progressively and include plain text alternatives. | All steps viewable and text alternative present. | Annex 6; Accessibility QA | Approved | For L6.1 and L6.3. |
| Feedback loop behavior | Feedback loop uses six-step process and matching; response/report-back emphasized. | Feedback is not reduced to collection. | EU HRBA/Accountability evidence | Approved | L6.3. |
| Adaptation decision behavior | Decision activity gives option consequences and reinforces evidence-informed, participatory, documented adaptation. | Correct feedback explains why adaptation is accountability. | EU HRBA Toolbox | Approved | L6.5. |
| Chart behavior | Synthetic participation chart includes data table, no real data upload, no color-only meaning. | Learner can understand chart via table/text. | OHCHR indicators; Annex 12 | Approved | L6.5. |
| Safe documentation behavior | Sorting + accordion + checklist make minimum necessary data concrete. | No learner uploads documents or records. | Annex 12 | Approved | L6.6. |
| Safety styling | Use calm warning/note callouts, not fear-based red alerts except critical errors. | Safety visible but not dominant. | Course synthesis; Annex 12 | Approved | Balance learning and safety. |
| Asset behavior | Images are optional enhancements; essential content remains in text. | Module works without images. | Accessibility/low-bandwidth rules | Approved | Approved asset behavior; use filenames/register as locked production instructions. |
| Completion behavior | Core interactions required for lesson completion; portfolio save optional. | Learner can complete module without external uploads. | Course Player Spec | Approved | No proof upload. |

## Section design rules

| Section | Visual / interaction treatment |
|---|---|
| Module intro | Hero/bridge card with implementation image, safety reminder, certificate separation |
| 6.1 Keeping Participation Alive | Scenario hook, micro-lesson, participation cycle/process, checklist/tool, MCQ |
| 6.2 Inclusive Delivery | Scenario/image, labeled barrier graphic, checklist/tool, multiple-response check, optional reflection |
| 6.3 Feedback and Report-Back Loops | Feedback loop process, scenario, matching/tool, MCQ, safety reminder |
| 6.4 Constructive Engagement | Tabs/cards for roles, decision scenario, reflection, MCQ |
| 6.5 Adaptive Implementation | Case, synthetic chart/table, decision, adaptation note tool, MCQ |
| 6.6 Safe Documentation | Safety statement, sorting, accordion, safe documentation checklist, MCQ, summary |

## Sensitive design rules

- Avoid identifiable community photos, complaint forms, safeguarding records, referral notes, or readable operational documents.
- Use fictional implementation scenarios.
- Use synthetic data only for charts/tables.
- Use orange callouts for privacy, documentation, feedback, and safeguarding reminders.
- Use red only for true critical release-blocking warnings, not learner feedback.
- Feedback and documentation tools should feel protective and practical, not investigative.

## Mobile behavior

On mobile:

- all layouts become single column;
- navigation collapses to drawer/menu;
- process diagrams become stacked step cards;
- tabs and accordions stack vertically;
- sorting/matching becomes tap/dropdown;
- tool/checklist forms use short grouped sections;
- CTAs are full width;
- all interactions remain keyboard/tap accessible.

## Feedback states

| State | Design rule |
|---|---|
| Best response | Green accent; text begins “That’s right” or “Good choice” |
| Weaker response | Neutral or soft amber accent; text begins “Not quite” |
| Saved portfolio | Green confirmation; “Saved privately” language |
| Safety reminder | Orange accent; calm protective tone |
| Documentation warning | Orange caution card with minimum necessary principle |
| Critical warning | Red only for true critical risk, not learner mistakes |

## Design no-drift rules

The coding agent must not:

- turn Module 6 into a static article;
- reduce implementation to workplan delivery only;
- remove private tool/portfolio options;
- request real complaints or safeguarding records;
- use drag-only interactions;
- imply Module 6 tools/checks affect certificate;
- create public peer exchange;
- use “Incorrect” feedback;
- ask for uploads or identifiable photos;
- use real data in charts;
- omit text alternatives for essential visuals.
