# Module 6 Overview

## Course

**Applying the Human Rights-Based Approach (HRBA) in CSO Practice**

## Module title

**Module 6: Applying HRBA During Implementation**

## Module role

Module 6 is a practical implementation module. It helps participants keep HRBA alive during day-to-day delivery after a project has started.

## Recommended duration

**90–110 minutes**

## Primary audience

Local and grassroots CSO staff, project officers, field teams, MEAL/accountability staff, facilitators, coordinators, and organizational focal persons involved in day-to-day implementation.

## Main learner shift

From:

> “Implementation means delivering the approved workplan.”

To:

> “Implementation means continuously protecting participation, inclusion, feedback, accountability, constructive engagement, safe adaptation, and do-no-harm documentation while delivering the workplan.”

## Module learning outcomes

By the end of Module 6, participants should be able to:

1. keep participation alive after project launch;
2. identify and reduce inclusion and access barriers during delivery;
3. strengthen feedback, accountability, and report-back loops;
4. engage duty-bearers and partners constructively and safely;
5. use feedback and evidence to adapt implementation safely;
6. document only what is necessary while protecting people from harm;
7. save or download private Module 6 implementation tools without affecting certificate eligibility.

## Approved lesson sequence

1. **Module intro**
2. **Keeping Participation Alive During Implementation**
3. **Inclusive Delivery in Practice**
4. **Feedback, Accountability, and Report-Back Loops**
5. **Constructive Duty-Bearer and Partner Engagement**
6. **Adaptive Implementation and Safe Learning**
7. **Safe Documentation and Do-No-Harm Reporting**

## Main portfolio/tool outputs

- Participation improvement checklist
- Inclusive delivery reflection note
- Feedback loop improvement note
- Constructive engagement reflection
- Adaptation decision note
- Safe documentation checklist

## Assessment rule

All Module 6 checks are formative only. They support implementation practice and review. They do not issue a certificate, unlock a certificate, rank participants, or rank CSOs.

## Certificate rule

Certificate eligibility remains tied to the final course test with a score of **80% or above**.

## Safety level

Moderate to high because implementation can involve feedback, complaints, safeguarding, referral information, operational records, photos, and civic-space-sensitive engagement.

## Privacy rule

Tool outputs, optional notes, implementation reflections, adaptation notes, feedback-loop notes, and documentation checklists are private by default.

## Sensitive data rule

Do not ask learners to provide names, real complaints, safeguarding/protection records, referral details, identifiable photos, staff/beneficiary lists, political details, confidential operational records, raw organizational data, or uploads.
