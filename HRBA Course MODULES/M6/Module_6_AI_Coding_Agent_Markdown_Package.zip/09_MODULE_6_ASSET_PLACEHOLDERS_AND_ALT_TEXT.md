# Module 6 Asset Placeholders and Alt Text

## Asset rule

Do not invent final asset filenames or paths. Use approved source-named assets where listed. If a file is missing, use a placeholder component with the approved filename reference.

## Visual style

Use CSO Learning Hub / DEC visual identity:

- primary blue: `#3B99D4`
- accent green: `#91C852`
- deep navy: `#0F172A`
- light background: `#F9FAFB`
- white cards
- dark text: `#111827`
- subtle borders: `#E5E7EB`
- rounded corners
- soft shadows

## Asset register

| Asset ID | File name | Asset type | Placement | Purpose/scene | Production direction | Alt text | Low-bandwidth alternative | Safety/privacy note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-M06-001 | module-6-hrba-implementation.jpg | Module header image | M06-B00 | Show implementation as participatory, inclusive, accountable practice | Realistic Ethiopian/East African local CSO field team reviewing feedback and implementation notes; warm natural light; no readable text/logos/UI. | Local CSO team reviewing implementation notes and community feedback together. | Text intro card with no image required. | No recognizable faces; no sensitive text. |
| A-M06-002 | participation-after-launch.jpg | Scenario image | M06-L01-B01 | Planning meeting after project launch | Small CSO team around table reviewing activity calendar and community notes; no readable text. | CSO staff discussing activity implementation after project launch. | Scenario text card. | No real project names/logos. |
| A-M06-003 | participation-implementation-cycle.svg | Process diagram | M06-L01-B03 | Four moments of participation | DEC blue/green process diagram with four circular steps: before, during, after, before changes. | Diagram showing four moments for participation during implementation. | Plain numbered list. | No sensitive disclosure. |
| A-M06-004 | participation-checklist.pdf | Worksheet | M06-L01-B04 | Participation improvement checklist | Accessible one-page fillable/printable worksheet. | Participation improvement checklist worksheet. | In-platform checklist fields. | No names or sensitive group identifiers. |
| A-M06-005 | inclusive-delivery-case.jpg | Case image | M06-L02-B01 | Training setting with access considerations | Modest training room with diverse participants and accessible seating; no readable text/logos. | Community training session arranged for inclusive participation. | Case text card. | Avoid stereotyping/pity imagery. |
| A-M06-006 | inclusion-barriers-labeled-graphic.svg | Labeled graphic | M06-L02-B02 | Common barriers to equal access | Central activity icon with six barrier cards: timing, transport, language, disability access, safety/social norms, information. | Labeled graphic showing common participation barriers. | Plain list of barriers with adjustments. | No sensitive examples. |
| A-M06-007 | inclusive-delivery-checklist.pdf | Worksheet | M06-L02-B04 | Inclusive delivery checklist | Worksheet fields for activity, excluded categories, barriers, adjustments, who to ask, access evidence. | Inclusive delivery checklist worksheet. | In-platform form fields. | Broad categories only. |
| A-M06-008 | accountability-feedback-loop.svg | Process diagram | M06-L03-B01 | Feedback loop diagram | Six-step loop: invite, record safely, analyze, respond/refer, act/adapt, close the loop; include safety lock icon. | Diagram showing a rights-based feedback and response loop. | Numbered process list. | Do not depict real complaints. |
| A-M06-009 | suggestion-box-feedback.jpg | Scenario image | M06-L03-B02 | Feedback channel scene | CSO staff reviewing a suggestion box and notes privately; no readable complaint text. | CSO staff safely reviewing feedback from a suggestion box. | Scenario text card. | No readable complaint text. |
| A-M06-010 | feedback-loop-improvement-template.pdf | Worksheet | M06-L03-B04 | Feedback loop improvement note | Template for feedback channel, access, exclusion, recording, review, response, improvement. | Feedback loop improvement worksheet. | In-platform form fields. | No real complaints/names. |
| A-M06-011 | cso-engagement-roles.svg | Tabs/diagram visual | M06-L04-B02 | Four CSO engagement roles | Four-card visual: bridge-builder, evidence sharer, capacity supporter, accountability actor. | Four cards showing CSO roles in duty-bearer and partner engagement. | Tab text only. | No real actor names. |
| A-M06-012 | adaptive-implementation-case.jpg | Case image | M06-L05-B01 | Team reviewing implementation signals | CSO team reviewing simple charts and feedback notes; no readable text. | CSO team reviewing project feedback and participation signals. | Case text card. | No real data. |
| A-M06-013 | participation-signals-chart.svg | Chart visual | M06-L05-B03 | Synthetic participation data chart | Accessible bar chart using synthetic percentages for broad groups; include data table alternative. | Chart showing participation differences across broad groups using synthetic data. | Data table with values. | Synthetic data only. |
| A-M06-014 | adaptation-decision-note-template.pdf | Worksheet | M06-L05-B05 | Adaptation decision note template | Fields: signal, affected group category, proposed change, risks, approval, communication/report-back. | Adaptation decision note worksheet. | In-platform form fields. | No real data/names. |
| A-M06-015 | safe-documentation-questions.svg | Accordion visual | M06-L06-B03 | Four safe documentation questions | Four cards: purpose, minimum necessary, consent/control, protection; calm safety icons. | Four safe documentation questions. | Accordion text only. | No sensitive examples. |
| A-M06-016 | safe-documentation-checklist.pdf | Worksheet | M06-L06-B04 | Safe documentation checklist | Template for information type, purpose, minimum needed, consent, access, anonymization, not collected, safer alternative. | Safe documentation checklist worksheet. | In-platform form fields. | No real sensitive records. |

## Asset implementation rules

- Every image/SVG must include alt text.
- Complex diagrams need text alternatives.
- PDF/DOCX/XLSX tools must also have in-platform field versions where feasible.
- Do not use photos that identify vulnerable people or sensitive situations.
- Do not show readable complaints, safeguarding records, referral notes, operational records, real logos, political signage, or confidential documents.
- Use synthetic data only in charts/tables.
- Avoid text-heavy images; all essential text must also exist as HTML text.
- If assets are missing, render placeholder cards using the approved filename reference.
