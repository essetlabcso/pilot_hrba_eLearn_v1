# Module 6 Interaction Logic

## Global rules

```text
Module 6 checks, tools, and reflections are formative only.
Certificate eligibility is not calculated in Module 6.
Certificate eligibility remains linked to the final course test with score >= 80%.

Do not expose to learners:
  screen IDs
  block IDs
  source IDs
  QA notes
  reviewer notes
  approval metadata
  implementation metadata

Do not request:
  names
  real complaints
  complainant details
  safeguarding/protection records
  referral details
  identifiable photos
  staff or beneficiary lists
  political/civic-space-sensitive details
  confidential operational records
  raw organizational data
  uploads
```

## Required completion logic

```text
Module 6 is complete when:
  module intro viewed
  participation implementation process viewed
  participation improvement checklist completed or acknowledged
  participation MCQ completed
  inclusion barriers graphic viewed
  inclusive delivery tool/checklist completed or acknowledged
  inclusive delivery multi-response completed
  feedback loop process viewed
  feedback channel matching/scenario completed
  feedback loop improvement tool completed or acknowledged
  feedback MCQ completed
  duty-bearer/partner engagement tabs viewed
  constructive engagement decision completed
  constructive engagement reflection viewed or skipped
  constructive accountability MCQ completed
  adaptive implementation case/data block viewed
  adaptation decision completed
  adaptation decision note tool completed or acknowledged
  adaptation MCQ completed
  safe/risky documentation sorting completed
  safe documentation accordion viewed
  safe documentation checklist completed or acknowledged
  minimum necessary data MCQ completed
  module summary viewed

Private saves and downloads must not affect certificate eligibility.
```

## Interaction map

| Interaction ID | Lesson | Block ID | Type | Learner task | Configuration | Expected response | Feedback behavior | Completion | Certificate | Portfolio/proof | Safety/privacy | Accessibility |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| INT-M06-01 | 6.1 | M06-L01-B03 | Process | Review four participation moments | Four sequential steps; require view all steps | All steps viewed | None | View all steps | None | No proof; supports practice | No sensitive disclosure | Text alternative |
| INT-M06-02 | 6.1 | M06-L01-B04 | Checklist / Tool | Check current participation practices | Six checklist items + optional note | No single correct answer | Band feedback by number checked | Complete checklist | None | Optional portfolio save | No names/sensitive examples | Keyboard/tap accessible |
| INT-M06-03 | 6.1 | M06-L01-B05 | MCQ | Choose sign of meaningful participation | One correct option | C | Immediate feedback | Answer required | Formative only | None | No sensitive data | Accessible MCQ |
| INT-M06-04 | 6.2 | M06-L02-B02 | Labeled graphic | Explore six access barriers | Six markers with example + adjustment | All opened | None | Open all markers | None | None | No sensitive data | Screen-reader marker list |
| INT-M06-05 | 6.2 | M06-L02-B04 | Tool activity | Identify barriers and adjustments | Fields: activity, excluded category, barrier, adjustment, who to ask, evidence | Specific barrier + feasible adjustment | Prompt to consult affected groups safely | Complete required fields | None | Optional portfolio save | Broad categories only | Mobile stacked fields |
| INT-M06-06 | 6.2 | M06-L02-B05 | Multiple response | Select inclusive delivery actions | Correct A,C,D | A,C,D | Immediate feedback | Answer required | Formative only | None | No real excluded groups | Accessible checkboxes |
| INT-M06-07 | 6.3 | M06-L03-B01 | Process | Review accountability loop | Six-step circular process | All steps viewed | None | View all steps | None | None | Confidentiality caveat | Text alternative |
| INT-M06-08 | 6.3 | M06-L03-B03 | Matching | Match actions to feedback steps | Six pairs; allow retry | All pairs matched | Reinforce response/action | Complete matching | Formative only | None | No real feedback data | Tap/keyboard alternative |
| INT-M06-09 | 6.3 | M06-L03-B04 | Tool activity | Improve one feedback channel | Seven fields; save optional | Access + response improvement | Encourage manageable improvement | Complete fields | None | Optional portfolio save | No complaints/names/details | Printable alternative |
| INT-M06-10 | 6.3 | M06-L03-B05 | MCQ | Identify rights-based feedback process | Correct B | B | Immediate feedback | Answer required | Formative only | None | No sensitive complaints | Accessible MCQ |
| INT-M06-11 | 6.4 | M06-L04-B02 | Tabs | Explore CSO engagement roles | Four tabs | All tabs viewed | None | View all tabs | None | None | No real actor names | Accessible tabs |
| INT-M06-12 | 6.4 | M06-L04-B03 | Decision scenario | Choose engagement approach | Four options with consequences | Best safe constructive option | Feedback per option | Choose option | Formative only | Optional reflection link | Fictional; no real institutions | Keyboard/tap selection |
| INT-M06-13 | 6.4 | M06-L04-B04 | Reflection | Select CSO engagement role | Private reflection; optional save | One broad role + reason | None | Submit or skip | None | Optional portfolio save | No sensitive actor names | Private by default |
| INT-M06-14 | 6.5 | M06-L05-B03 | Chart interpretation | Interpret synthetic participation signals | Synthetic chart + table | Identify possible access barriers | Data triggers questions, not blame | View chart/table | Formative only | None | Synthetic data only | Data table alternative |
| INT-M06-15 | 6.5 | M06-L05-B04 | Decision activity | Choose adaptation response | Four options | Best: consult, adapt, document, communicate | Immediate feedback | Answer required | Formative only | None | No real data | Accessible buttons |
| INT-M06-16 | 6.5 | M06-L05-B05 | Tool activity | Draft adaptation note | Fields: signal, affected, change, risks, approval, communication | Connect evidence, participation, risk, communication | Prompt to document and explain | Complete fields | None | Optional portfolio save | General examples only | Printable/fillable |
| INT-M06-17 | 6.6 | M06-L06-B02 | Sorting | Sort safe/risky documentation | Two categories; ten items | All items correctly sorted | Explain minimum necessary and consent | Complete sorting | Formative only | None | No real sensitive examples | Non-drag alternative |
| INT-M06-18 | 6.6 | M06-L06-B03 | Accordion | Review safe documentation questions | Four panels | All opened | None | Open all panels | None | None | No sensitive data | Screen-reader accessible |
| INT-M06-19 | 6.6 | M06-L06-B04 | Tool activity | Complete safe documentation checklist | Fields: info type, purpose, minimum, consent, access, anonymization, not collected, safer alternative | Purpose-limited, minimized, protected plan | Prompt safer alternative | Complete fields | None | Optional portfolio save | Do not enter names or cases | Printable/fillable |
| INT-M06-20 | 6.6 | M06-L06-B05 | MCQ | Define minimum necessary data | Correct B | B | Immediate feedback | Answer required | Formative only | None | No sensitive data | Accessible MCQ |

## Core behavior rules

### Process and step-list behavior

```text
For participation, feedback, adaptation, and documentation process blocks:
  every step must be keyboard focusable or visible in accessible text
  mark complete when all steps opened OR full step list viewed
  no animation is required
```

### Tabs / accordion behavior

```text
For tabs and accordions:
  support keyboard and tap
  tab/panel content must be screen-reader accessible
  mark completed when all tabs/panels opened OR accessible full text alternative is viewed
```

### Matching / sorting behavior

```text
For matching and sorting:
  provide non-drag alternative:
    dropdown
    tap-select cards
    keyboard-selectable category buttons
  show immediate feedback
  allow retry
  use “Good choice” or “That’s right” for best matches
  use “Not quite” for weaker matches
  no red failure-only state
```

### Tool and worksheet behavior

```text
For every implementation tool:
  show purpose and fields before the tool
  provide downloadable template where asset exists
  provide in-platform form/checklist alternative
  allow private save if portfolio is enabled
  allow download if save is not enabled
  do not require uploads
  do not ask for real complaints, case notes, referral details, identifiable photos, or confidential records
  do not affect certificate logic
```

### Reflection behavior

```text
For reflections:
  reflection is optional/private unless it is a checklist review
  show safety helper before free text
  allow skip without penalty where marked optional
  save only if learner chooses save
  do not send raw reflection to AI
```

### Knowledge check behavior

```text
For MCQ/MRQ/decision checks:
  formative only
  option-level feedback required
  no pass/fail language
  no certificate effect
  use “Not quite,” not “Incorrect”
  allow retry if platform supports it
```
