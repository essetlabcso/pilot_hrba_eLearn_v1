# Module 6 Screen-by-Screen Learner-Facing Content

# Module 6: Applying HRBA During Implementation

## Module introduction

Welcome to Module 6.

A strong project design is only the starting point. HRBA becomes real during daily implementation: how people participate, who can access activities, how feedback is handled, how partners are engaged, how teams adapt, and how information is documented safely.

This module helps you keep HRBA alive after implementation begins. It focuses on participation, inclusive delivery, feedback and report-back, constructive engagement, adaptive implementation, and safe documentation.

### Safety reminder

Use fictionalized, anonymized, or generalized examples. Do not include real complaints, safeguarding details, names, identifiable photos, referral records, political details, confidential operational records, or raw organizational data.

### Certificate reminder

Module 6 tools and checks are formative. Your certificate is linked to the final course test with a score of 80% or above.


# Module Intro

## M6-S0-01 — Applying HRBA During Implementation

A strong project design is only the starting point. HRBA becomes real during daily implementation: how people participate, who can access activities, how feedback is handled, how partners are engaged, how teams adapt, and how information is documented safely.

### Learner action / configuration

Viewed to continue

### Transition

Continue to next block

### Safety and accessibility note

No sensitive information requested. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

module-6-hrba-implementation.jpg

### Button

Continue

---


# 6.1

## M6-S1-01 — The meeting after the launch

Your CSO has started a community livelihood project. At first, many people attended meetings. One month later, only the same voices are being heard, and some concerns are no longer reaching the team. The workplan is moving, but participation is becoming weaker.

### Learner action / configuration

Think: what signs show that participation is weakening?

### Transition

Continue to next block

### Safety and accessibility note

Fictional scenario only; no real project names or people. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

participation-after-launch.jpg

### Button

Continue

---

## M6-S1-02 — Participation is not finished after design

Meaningful participation is not a one-time consultation at proposal stage. During implementation, affected people should still have safe and realistic ways to influence decisions, ask questions, raise concerns, and hear what changed because of their input.

### Learner action / configuration

Viewed to continue

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---

## M6-S1-03 — Participation during implementation: four moments

Use four moments to keep participation alive: before an activity, ask who may be left out; during the activity, notice who participates and who is missing; after the activity, ask what worked and what should change; before the next activity, explain what changed and why.

### Learner action / configuration

Open all process steps

### Transition

Continue to next block

### Safety and accessibility note

No sensitive disclosure; text alternative required. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

participation-implementation-cycle.svg

### Button

Continue

---

## M6-S1-04 — Participation improvement checklist

Choose one general activity your CSO implements or could implement. Check whether affected people can influence timing, location, communication, feedback, adaptation, and report-back. Use broad examples only, not names or real complaints.

### Learner action / configuration

Complete checklist; optional private save

### Feedback / completion message

Supportive feedback based on checklist completion

### Transition

Continue to next block

### Safety and accessibility note

Use general examples only; no names, complaint details, or sensitive records. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

participation-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M6-S1-05 — Check your understanding

Which is the strongest sign that participation is meaningful during implementation? A. Many attendance signatures are collected. B. The activity follows the original schedule. C. Participants influence adjustments and hear back on decisions. D. Photos are taken for the report.

### Learner action / configuration

Answer required

### Feedback / completion message

Immediate feedback with explanation

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S1-06 — Key message

Participation during implementation means people have influence, not only presence. A rights-based team listens, responds, adapts when needed, and explains decisions clearly.

### Learner action / configuration

Viewed to complete lesson

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---


# 6.2

## M6-S2-01 — The training that excluded people without intending to

A CSO organizes a skills training and invites the whole community. Attendance looks high, but some people do not come because the time, venue, communication method, cost, or format does not work for them. Equal invitation did not create equal access.

### Learner action / configuration

Identify possible barriers

### Transition

Continue to next block

### Safety and accessibility note

Fictional example; avoid stereotypes and identifiable group details. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

inclusive-delivery-case.jpg

### Button

Continue

---

## M6-S2-02 — Equal invitation is not equal access

Explore common implementation barriers: timing, location and transport, language and literacy, disability access, caregiving responsibilities, cost, safety, information flow, and confidence to speak. For each barrier, look for a practical adjustment.

### Learner action / configuration

Open all markers

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data; provide screen-reader marker list. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

inclusion-barriers-labeled-graphic.svg

### Button

Continue

---

## M6-S2-03 — Non-discrimination during delivery

Non-discrimination is not only about avoiding intentional exclusion. A normal activity rule can still exclude people if it ignores practical barriers. HRBA asks teams to notice barriers early and make reasonable, safe adjustments.

### Learner action / configuration

Viewed to continue

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---

## M6-S2-04 — Inclusive delivery checklist

Pick one general activity. Identify three barriers that could stop some people from joining or benefiting. For each barrier, write one practical adjustment and one safe way to ask affected people what would help.

### Learner action / configuration

Complete fields; optional private save

### Feedback / completion message

Supportive feedback; encourage safe, practical, manageable improvement

### Transition

Continue to next block

### Safety and accessibility note

Use broad categories only; do not name individuals or sensitive groups. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

inclusive-delivery-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M6-S2-05 — Which changes improve inclusion?

Select all actions that improve inclusive delivery: A. Adjust timing after asking participants. B. Use only one written announcement. C. Check whether the venue is accessible. D. Ask people facing barriers what would help. E. Assume absent people are not interested.

### Learner action / configuration

Answer required

### Feedback / completion message

Immediate feedback with explanation

### Transition

Continue to next block

### Safety and accessibility note

No real excluded groups requested. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S2-06 — One inclusion improvement

Write one small change your CSO could make to improve access or inclusion during implementation. Keep it general and avoid naming people, places, complaints, or sensitive situations.

### Learner action / configuration

Private reflection; optional save or skip

### Feedback / completion message

No scoring; private learning support

### Transition

Continue to next block

### Safety and accessibility note

Private by default; keep general and non-identifying. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Buttons

Save privately
Skip for now
Continue

---


# 6.3

## M6-S3-01 — The accountability loop

A feedback system is not complete when a CSO collects comments. A rights-based feedback loop invites feedback safely, records only what is needed, reviews it, responds or refers when appropriate, acts on learning, and reports back on what changed.

### Learner action / configuration

Open all steps

### Transition

Continue to next block

### Safety and accessibility note

Do not imply public sharing of sensitive feedback. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

accountability-feedback-loop.svg

### Button

Continue

---

## M6-S3-02 — The suggestion box problem

A CSO places a suggestion box at an activity site. Staff collect comments about timing and access, but no one explains what will happen next. People stop using the box. The issue is not the box itself; the feedback loop was not closed.

### Learner action / configuration

Review the scenario

### Transition

Continue to next block

### Safety and accessibility note

Fictional; do not describe real complaints or complainants. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

suggestion-box-feedback.jpg

### Button

Continue

---

## M6-S3-03 — Match the feedback step

Match each action to the right feedback-loop step: invite, record safely, review, respond or refer, act or adapt, and report back.

### Learner action / configuration

Complete matching

### Feedback / completion message

Feedback reinforces closed-loop accountability

### Transition

Continue to next block

### Safety and accessibility note

Do not request real feedback; include non-drag alternative. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S3-04 — Feedback loop improvement note

Choose one feedback channel your CSO uses or could use. Describe who can access it, who may be left out, how feedback is reviewed, how responses are shared, and one improvement that would make the loop safer and more useful.

### Learner action / configuration

Complete fields; optional private save

### Feedback / completion message

Supportive feedback; encourage safe, practical, manageable improvement

### Transition

Continue to next block

### Safety and accessibility note

Do not include real complaints, names, or case details. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

feedback-loop-improvement-template.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M6-S3-05 — What makes feedback rights-based?

Which option best describes a rights-based feedback process? A. Collect comments for donor reports only. B. Provide a safe channel, review feedback, respond, and improve practice. C. Let leaders decide what matters without review. D. Ignore difficult feedback.

### Learner action / configuration

Answer required

### Feedback / completion message

Immediate feedback with explanation

### Transition

Continue to next block

### Safety and accessibility note

No sensitive details. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S3-06 — Sensitive complaints need special care

If feedback includes safeguarding, protection, legal, security, or other sensitive concerns, do not handle it inside this course. Follow your organization’s approved procedures, referral pathways, consent rules, and duty-of-care requirements.

### Learner action / configuration

Viewed to continue

### Transition

Continue to next block

### Safety and accessibility note

High-sensitivity point; use calm warning style. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---


# 6.4

## M6-S4-01 — Constructive engagement during implementation

HRBA does not mean CSOs replace duty-bearers or treat partners as enemies. During implementation, CSOs can support constructive accountability by sharing safe evidence, raising access barriers, supporting capacity, and following up respectfully.

### Learner action / configuration

Viewed to continue

### Transition

Continue to next block

### Safety and accessibility note

Avoid legal, political, or adversarial wording. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---

## M6-S4-02 — Four engagement roles for CSOs

Explore four roles a CSO may play: bridge-builder, evidence sharer, capacity supporter, and accountability actor. The right role depends on safety, mandate, relationships, and what affected people want.

### Learner action / configuration

Open all tabs

### Transition

Continue to next block

### Safety and accessibility note

Use broad roles only; no real actor names. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

cso-engagement-roles.svg

### Button

Continue

---

## M6-S4-03 — Choosing the right engagement approach

Your CSO learns that a service point is not accessible to some people. Which response is most HRBA-aligned? Choose the option that protects people, uses general evidence, engages constructively, and follows up.

### Learner action / configuration

Choose option

### Feedback / completion message

Feedback by option; reinforce safe, constructive approach

### Transition

Continue to next block

### Safety and accessibility note

Fictional; no real institutions, authorities, or locations. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S4-04 — Your engagement role

Which engagement role might be useful in a broad issue your CSO works on: bridge-builder, evidence sharer, capacity supporter, or accountability actor? Write a short, general reason without naming real actors.

### Learner action / configuration

Private reflection; optional save or skip

### Feedback / completion message

No scoring; private learning support

### Transition

Continue to next block

### Safety and accessibility note

Private by default; no sensitive actor names. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Buttons

Save privately
Skip for now
Continue

---

## M6-S4-05 — Constructive accountability

What best describes constructive accountability? A. Avoiding duty-bearers completely. B. Publicly blaming people by name. C. Using safe evidence, community voice, clear responsibilities, and follow-up. D. Asking donors to solve all problems.

### Learner action / configuration

Answer required

### Feedback / completion message

Immediate feedback with explanation

### Transition

Continue to next block

### Safety and accessibility note

No sensitive details. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---


# 6.5

## M6-S5-01 — When the plan no longer fits

A training schedule worked at first, but attendance is dropping among some groups. The team could continue because the workplan says so, or pause to understand barriers and adjust safely. HRBA supports careful learning and adaptation.

### Learner action / configuration

Review the case

### Transition

Continue to next block

### Safety and accessibility note

Fictional; use synthetic data only. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

adaptive-implementation-case.jpg

### Button

Continue

---

## M6-S5-02 — Adaptation is part of accountability

Adaptive implementation means using feedback, participation signals, and field learning to improve delivery. It does not mean changing secretly or ignoring approved plans. Good adaptation is documented, justified, communicated, and risk-aware.

### Learner action / configuration

Viewed to continue

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---

## M6-S5-03 — Reading implementation signals

Review a synthetic chart showing different participation rates across broad groups. The chart is not for blame or ranking. It is a signal to ask better questions: who may face barriers, what changed, and what adjustment might help?

### Learner action / configuration

View chart and data table

### Feedback / completion message

Use synthetic data to prompt questions, not blame

### Transition

Continue to next block

### Safety and accessibility note

Synthetic data only; provide data table alternative. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

participation-signals-chart.svg

### Button

Continue

---

## M6-S5-04 — What should the team do?

Based on the participation signals, choose the most HRBA-aligned response: continue unchanged, remove groups from the plan, blame participants, or ask about barriers, adapt safely, document the decision, and report back.

### Learner action / configuration

Choose option

### Feedback / completion message

Feedback by option; reinforce participatory adaptation

### Transition

Continue to next block

### Safety and accessibility note

No real data requested. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S5-05 — Adaptation decision note

Use this mini-template to plan one safe adaptation using a general or fictional example: signal noticed, broad affected group category, proposed change, possible risks, who should approve, and how the change will be communicated.

### Learner action / configuration

Complete fields; optional private save

### Feedback / completion message

Supportive feedback; encourage safe, practical, manageable improvement

### Transition

Continue to next block

### Safety and accessibility note

Use general or synthetic examples only. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

adaptation-decision-note-template.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M6-S5-06 — Adaptive implementation

Which statement reflects HRBA-aligned adaptation? A. Never change once implementation starts. B. Change activities secretly to save time. C. Use safe feedback and evidence to improve delivery and explain decisions. D. Blame participants when activities do not work.

### Learner action / configuration

Answer required

### Feedback / completion message

Immediate feedback with explanation

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---


# 6.6

## M6-S6-01 — Documentation can help or harm

Documentation supports learning, accountability, and reporting. But collecting too much information, storing it poorly, or sharing it without consent can harm people and organizations. HRBA documentation uses only what is necessary and protects people.

### Learner action / configuration

Viewed to continue

### Transition

Continue to next block

### Safety and accessibility note

High-importance safety point. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---

## M6-S6-02 — Safe or risky documentation?

Sort documentation practices into safer practice or risky practice. Focus on purpose, consent, minimum necessary data, anonymization, safe storage, restricted access, and safer alternatives.

### Learner action / configuration

Complete sorting

### Feedback / completion message

Feedback explains minimum necessary documentation and consent

### Transition

Continue to next block

### Safety and accessibility note

No real examples; include tap/keyboard alternative. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S6-03 — Four safe documentation questions

Before collecting or sharing information, ask four questions: Why do we need this? What is the minimum necessary? Who has consent and control? How will we protect it or avoid collecting it?

### Learner action / configuration

Open all panels

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data; accessible accordion required. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

safe-documentation-questions.svg

### Button

Continue

---

## M6-S6-04 — Safe documentation checklist

Review one general information type your CSO collects, such as attendance totals or broad feedback patterns. Decide the purpose, minimum needed, consent approach, access control, anonymization, what not to collect, and safer alternative.

### Learner action / configuration

Complete fields; optional private save

### Feedback / completion message

Supportive feedback; encourage safe, practical, manageable improvement

### Transition

Continue to next block

### Safety and accessibility note

No names, complaints, safeguarding details, confidential records, or unredacted data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Asset reference

safe-documentation-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M6-S6-05 — Minimum necessary data

What does minimum necessary mean? A. Collect everything in case it is useful later. B. Collect only information needed for a clear purpose and protect it. C. Avoid all documentation. D. Share widely so everyone learns.

### Learner action / configuration

Answer required

### Feedback / completion message

Immediate feedback with explanation

### Transition

Continue to next block

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Submit and view feedback

---

## M6-S6-06 — Module 6 summary

You practiced keeping participation alive, improving inclusion, closing feedback loops, engaging constructively, adapting safely, and documenting without harm. In Module 7, you will connect these implementation practices to MEAL and evidence use.

### Learner action / configuration

Viewed to complete module

### Transition

Complete module and continue to Module 7

### Safety and accessibility note

No sensitive data. Alt/text alternative, keyboard/tap access, and mobile readability required.

### Button

Continue

---


## Module 6 next step

In Module 7, you will connect implementation practice to HRBA-aligned MEAL and evidence use. Your participation, inclusion, feedback, engagement, adaptation, and documentation notes will help you think about what evidence is useful, safe, accountable, and meaningful.

### Button

Continue to Module 7
