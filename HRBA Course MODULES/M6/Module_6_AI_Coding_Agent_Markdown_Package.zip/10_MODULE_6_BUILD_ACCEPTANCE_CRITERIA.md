# Module 6 Build Acceptance Criteria

## Source acceptance criteria

| Criteria area | Criterion | Pass condition | Status | Notes |
| --- | --- | --- | --- | --- |
| Module structure | Six learner-facing lessons match approved lesson map. | Lessons 6.1–6.6 appear in order with title/purpose. | Pass |  |
| Content quality | Module is practical, implementation-focused and locally grounded. | No generic project-management-only framing. | Pass |  |
| HRBA accuracy | Implementation links participation, inclusion, accountability, duty-bearer engagement, adaptation and do-no-harm. | No reduction to output delivery/attendance tracking. | Pass |  |
| Ethiopia-local relevance | Examples use local CSO realities without unsafe legal/political detail. | No real actors/locations/cases. | Pass |  |
| Participation quality | Participation is ongoing and decision-influencing, not one-time consultation. | L6.1 process/checklist passes. | Pass |  |
| Inclusion quality | Equal invitation vs equal access is clear. | L6.2 barriers and adjustments included. | Pass |  |
| Feedback-loop quality | Feedback includes safe collection, response, action/adaptation and report-back. | L6.3 process/matching/tool pass. | Pass |  |
| Duty-bearer engagement quality | Engagement is constructive, safe, role-based and non-adversarial. | L6.4 decision scenario passes. | Pass |  |
| Adaptation quality | Adaptation is evidence-informed, participatory, documented and communicated. | L6.5 scenario/decision/tool pass. | Pass |  |
| Safe documentation quality | Minimum necessary data, consent, anonymization, access control and not-collecting are clear. | L6.6 sorting/checklist pass. | Pass |  |
| Interaction quality | Every lesson has at least one practice/check interaction. | Block storyboard confirms. | Pass |  |
| Assessment/certificate | All Module 6 checks formative only; certificate 80% final test only. | No incorrect certificate-threshold statement or module-certifying check. | Pass | Certificate rule locked at final course test score of 80% or above. |
| Proof/portfolio separation | Portfolio outputs optional/private and not proof/certificate requirements. | Reflection/portfolio sheet confirms. | Pass |  |
| Safety/privacy | No real names, complaint details, safeguarding cases, photos, records, reports or unredacted data requested. | Safety sheet and block notes pass. | Pass |  |
| Asset readiness | Asset filenames, prompts, alt text, safety constraints, and low-bandwidth alternatives are approved for production/import. | Asset register and prompt sheets complete with approved status. | Pass | Physical asset creation/import is a build task using approved filenames. |
| Accessibility | Alt text, text alternatives, non-drag alternatives, chart data table, mobile/low-bandwidth behavior specified. | Accessibility QA pass. | Pass |  |
| Final learner cleanup | Learner-facing text contains no source IDs, reviewer notes, internal evidence references or open-decision markers. | 09_FINAL_CONTENT learner text clean. | Pass |  |

## Additional clean-package acceptance checks

| Check | Pass condition |
|---|---|
| Clean content only | Learner-facing build excludes QA history, source inventories, evidence packs, change logs, approval locks, and internal reviewer notes. |
| Approved title | Module title is “Applying HRBA During Implementation.” |
| Approved sequence | Six lessons appear in approved order, with module intro and summary. |
| Correct screen count | 36 learner-facing screens/blocks are represented. |
| Feedback wording | Weaker responses use “Not quite,” not “Incorrect.” |
| Certificate integrity | No Module 6 check, tool, worksheet, checklist, adaptation note, or reflection affects certificate eligibility. |
| 80% rule | Learner copy states certificate is linked to final course test score of 80% or above. |
| Portfolio privacy | Tool outputs, adaptation notes, feedback-loop notes, documentation checklists, and optional notes are private by default. |
| No sensitive data | No screen asks for names, real complaints, complainant details, safeguarding records, referral details, identifiable photos, staff/beneficiary lists, political details, confidential operational records, uploads, or raw data. |
| Feedback privacy boundary | Feedback lesson improves channels/processes without collecting real complaints or case details. |
| Documentation boundary | Documentation lesson uses minimum necessary principle and does not request records/photos/case files. |
| Synthetic data only | Adaptive implementation chart/table uses synthetic/generalized data only. |
| Peer exchange excluded | No required peer exchange or public implementation-note sharing appears in the build. |
| Accessibility | All interactions are keyboard/tap accessible and screen-reader friendly. |
| Low bandwidth | Essential learning does not depend on heavy media, PDFs, or external embeds. |
| Asset control | Source-named assets are preserved; missing assets remain placeholders. |
| Metadata hidden | Learners do not see screen IDs, block IDs, source IDs, QA notes, or implementation metadata. |
