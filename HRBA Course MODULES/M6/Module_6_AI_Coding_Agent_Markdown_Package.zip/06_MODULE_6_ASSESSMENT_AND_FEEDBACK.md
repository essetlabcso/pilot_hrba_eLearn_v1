# Module 6 Assessment and Feedback Map

## Module assessment rule

All Module 6 checks are **formative only**. They help participants practice HRBA implementation thinking and prepare for later modules.

Module 6 checks do **not**:

- issue a certificate;
- unlock a certificate;
- replace the final course test;
- rank the participant;
- rank the CSO;
- require sensitive information;
- require document uploads;
- require real complaints, safeguarding records, referral details, identifiable photos, or confidential operational data.

The course certificate remains linked to the **final course test with a score of 80% or above**.

## Assessment sequence

| Assessment ID | Lesson | Block ID | Type | Question/focus | Options/expected | Best/correct answer | Feedback | Status | Certificate implication | Accessibility note | Safety note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KC-M06-01 | 6.1 | M06-L01-B05 | MCQ | Meaningful participation during implementation | A. Many attendance signatures are collected; B. The workplan is followed exactly; C. Participants influence adjustments and hear back on decisions; D. Photos are taken for reports | C | Meaningful participation means people have influence and receive responses, not only attendance or visibility. | Formative | No certificate implication | Accessible MCQ | No sensitive data |
| KC-M06-02 | 6.2 | M06-L02-B05 | Multiple response | Inclusive delivery actions | A. Adjust timing after asking participants; B. Use only one written announcement; C. Check whether the venue is accessible; D. Ask people facing barriers what would help; E. Assume absent people are not interested | A, C, D | Inclusive delivery requires identifying barriers and making practical, safe adjustments. | Formative | No certificate implication | Accessible checkboxes | No real excluded groups requested |
| KC-M06-03 | 6.3 | M06-L03-B05 | MCQ | Rights-based feedback process | A. Collect comments for donor reports only; B. Provide a safe channel, review feedback, respond, and improve practice; C. Let leaders decide what matters without review; D. Ignore difficult feedback | B | Feedback is rights-based when it is safe, reviewed, acted on, and followed by report-back. | Formative | No certificate implication | Accessible MCQ | Sensitive complaints not requested |
| KC-M06-04 | 6.4 | M06-L04-B03 | Decision scenario | Constructive engagement with duty-bearers or partners | A. Publicly name and blame people; B. Consult safely, use generalized evidence, request constructive discussion, and follow up; C. Avoid engagement entirely; D. Send names and details to donors | B | Constructive accountability protects people, uses safe evidence, and opens a practical response pathway. | Formative | No certificate implication | Decision buttons accessible | Fictional scenario only; no real actors |
| KC-M06-05 | 6.4 | M06-L04-B05 | MCQ | Constructive accountability definition | A. Avoiding duty-bearers completely; B. Publicly blaming people by name; C. Using safe evidence, community voice, clear responsibilities, and follow-up; D. Asking donors to solve all problems | C | Constructive accountability combines voice, evidence, responsibility, safety, and follow-up. | Formative | No certificate implication | Accessible MCQ | No real actors |
| KC-M06-06 | 6.5 | M06-L05-B04 | Decision activity | Adaptive implementation response | A. Continue unchanged; B. Remove groups from the plan; C. Ask about barriers, adapt safely, document the decision, and report back; D. Blame participants | C | HRBA-aligned adaptation is evidence-informed, participatory, documented, communicated, and risk-aware. | Formative | No certificate implication | Accessible decision activity | Synthetic data only |
| KC-M06-07 | 6.5 | M06-L05-B06 | MCQ | Adaptation principle | A. Never change once implementation starts; B. Change secretly to save time; C. Use safe feedback and evidence to improve delivery and explain decisions; D. Blame participants when activities do not work | C | Adaptation is part of learning and accountability when it is safe, justified, documented, and explained. | Formative | No certificate implication | Accessible MCQ | No sensitive data |
| KC-M06-08 | 6.6 | M06-L06-B02 | Sorting | Safe vs risky documentation | Sort practices into safer or risky documentation categories. | All items correctly sorted | Safer documentation minimizes harm, protects identity, uses consent, limits access, and collects only what is necessary. | Formative | No certificate implication | Non-drag alternative | No real data |
| KC-M06-09 | 6.6 | M06-L06-B05 | MCQ | Minimum necessary data | A. Collect everything in case useful later; B. Collect only information needed for a clear purpose and protect it; C. Avoid all documentation; D. Share widely so everyone learns | B | Minimum necessary documentation protects people while still supporting learning and accountability. | Formative | No certificate implication | Accessible MCQ | No sensitive data |


# Repaired learner-facing feedback patterns

## KC-M06-01 — Meaningful participation during implementation

Question: Which sign best shows meaningful participation during implementation?

A. Many attendance signatures are collected.  
B. The workplan is followed exactly.  
C. Participants influence adjustments and hear back on decisions.  
D. Photos are taken for reports.

Best response: C

Feedback for A: Not quite. Attendance can be useful, but it does not show that people influenced decisions.  
Feedback for B: Not quite. Following the workplan exactly may ignore new barriers or feedback.  
Feedback for C: That’s right. Meaningful participation means people can influence adjustments and hear back on what changed.  
Feedback for D: Not quite. Photos are not a measure of meaningful participation and may create privacy risks.

## KC-M06-02 — Inclusive delivery actions

Question: Which actions strengthen inclusive delivery? Select all that apply.

A. Adjust timing after asking participants.  
B. Use only one written announcement.  
C. Check whether the venue is accessible.  
D. Ask people facing barriers what would help.  
E. Assume absent people are not interested.

Best responses: A, C, and D

Feedback for A/C/D: That’s right. Inclusive delivery requires practical adjustments based on barriers and participant realities.  
Feedback for B: Not quite. One written announcement can exclude people who face literacy, language, disability, distance, or information barriers.  
Feedback for E: Not quite. Absence may reflect barriers, not lack of interest.

## KC-M06-03 — Rights-based feedback process

Question: Which option best describes a rights-based feedback process?

A. Collect comments for donor reports only.  
B. Provide a safe channel, review feedback, respond, and improve practice.  
C. Let leaders decide what matters without review.  
D. Ignore difficult feedback.

Best response: B

Feedback for A: Not quite. Feedback is not only a reporting input.  
Feedback for B: That’s right. Feedback becomes accountability when it is safe, reviewed, responded to, and used to improve practice.  
Feedback for C: Not quite. Feedback should be reviewed through a clear and safe process, not filtered only by leaders.  
Feedback for D: Not quite. Difficult feedback may reveal important rights, access, or accountability issues.

## KC-M06-04 — Constructive engagement

Question: What is the safest constructive engagement response?

A. Publicly name and blame people.  
B. Consult safely, use generalized evidence, request constructive discussion, and follow up.  
C. Avoid engagement entirely.  
D. Send names and details to donors.

Best response: B

Feedback for A: Not quite. Naming and blaming can increase risk and reduce constructive problem-solving.  
Feedback for B: That’s right. Constructive engagement protects people, uses safe evidence, opens discussion, and follows up.  
Feedback for C: Not quite. Avoiding engagement entirely may leave barriers unaddressed.  
Feedback for D: Not quite. Sending names and details can expose people to harm.

## KC-M06-05 — Constructive accountability

Question: Which statement best defines constructive accountability?

A. Avoiding duty-bearers completely.  
B. Publicly blaming people by name.  
C. Using safe evidence, community voice, clear responsibilities, and follow-up.  
D. Asking donors to solve all problems.

Best response: C

Feedback for A: Not quite. Avoidance may prevent responsibilities from being addressed.  
Feedback for B: Not quite. Public blame can create risk and may not solve the problem.  
Feedback for C: That’s right. Constructive accountability combines voice, evidence, responsibility, safety, and follow-up.  
Feedback for D: Not quite. Donors may have a role, but accountability should not be outsourced entirely.

## KC-M06-06 — Adaptive implementation response

Question: What is the most HRBA-aligned response when feedback and participation data show that some groups are being excluded?

A. Continue unchanged.  
B. Remove groups from the plan.  
C. Ask about barriers, adapt safely, document the decision, and report back.  
D. Blame participants.

Best response: C

Feedback for A: Not quite. Continuing unchanged may deepen exclusion.  
Feedback for B: Not quite. Removing groups can hide the problem instead of addressing barriers.  
Feedback for C: That’s right. HRBA-aligned adaptation is evidence-informed, participatory, documented, communicated, and risk-aware.  
Feedback for D: Not quite. Blaming participants ignores barriers and power relations.

## KC-M06-07 — Adaptation principle

Question: Which statement best reflects safe adaptation?

A. Never change once implementation starts.  
B. Change secretly to save time.  
C. Use safe feedback and evidence to improve delivery and explain decisions.  
D. Blame participants when activities do not work.

Best response: C

Feedback for A: Not quite. Implementation often requires safe and justified adaptation.  
Feedback for B: Not quite. Adaptation should be documented and communicated where appropriate.  
Feedback for C: That’s right. Adaptation is part of learning and accountability when it is safe, justified, documented, and explained.  
Feedback for D: Not quite. HRBA asks what barriers exist and how practice can improve.

## KC-M06-08 — Safe vs risky documentation

Sorting focus: Sort documentation practices into safer or risky categories.

Safer practices include: collect only what is needed, anonymize where possible, protect access, seek informed consent, use aggregated notes where enough, follow safe referral/confidentiality procedures.

Risky practices include: collect names “just in case,” store identifiable complaints openly, share photos publicly without strong consent and risk review, copy safeguarding details into training notes, circulate raw complaint logs.

Feedback for safer choices: Good choice. Safer documentation minimizes harm, protects identity, limits access, and collects only what is necessary.  
Feedback for risky choices: Not quite. This practice may expose people or sensitive information. Choose a safer documentation method.

## KC-M06-09 — Minimum necessary data

Question: Which statement best reflects minimum necessary documentation?

A. Collect everything in case useful later.  
B. Collect only information needed for a clear purpose and protect it.  
C. Avoid all documentation.  
D. Share widely so everyone learns.

Best response: B

Feedback for A: Not quite. Collecting everything can increase harm and privacy risk.  
Feedback for B: That’s right. Minimum necessary documentation protects people while still supporting learning and accountability.  
Feedback for C: Not quite. Some documentation is needed for learning, accountability, and responsible action.  
Feedback for D: Not quite. Sharing widely can expose people and sensitive information.


## Assessment data map

| Assessment/tool | Required saved data | Optional saved data | Do not save |
|---|---|---|---|
| Participation check | Completion status | Selected answer | Names or real meeting details |
| Inclusive delivery check | Completion status | Selected responses | Identifiable vulnerable people |
| Feedback process check | Completion status | Selected answer | Real complaints or complainant details |
| Constructive engagement decision | Completion status | Selected answer | Real actor names or political details |
| Adaptation decision | Completion status | Selected answer | Raw project data or sensitive feedback |
| Safe/risky documentation sorting | Completion status | Selected categories | Real records, photos, case notes |
| Minimum necessary data check | Completion status | Selected answer | Raw documentation files |
| Tool activities | Completion status if completed in platform | Private fields if saved | Uploads, complaint logs, safeguarding/referral records, identifiable photos |
