# Module 6 Safety, Accessibility, and Data Rules

## Safety principle

Module 6 has a moderate-to-high safety level because implementation can involve participation records, feedback, complaints, safeguarding, referrals, identifiable photos, operational adaptation decisions, and documentation.

The module must help learners practice HRBA implementation safely without exposing people, communities, staff, organizations, complaints, safeguarding records, photos, or confidential operational information.

## Safety rules from source workbook

| Safety rule | Where addressed | Learner-facing wording | Pass condition | Repetition-reduction decision | Feedback/documentation privacy boundary |
| --- | --- | --- | --- | --- | --- |
| No real names or identifiable people | All reflections/tools | Use broad categories or fictional examples. Do not enter names or details that could identify a person. | No tool field requests names; helper text present. | Mention briefly before tools, not every text block. | Applies to all implementation data. |
| No real complaint details | Feedback lesson and tools | Do not enter real complaints, complainant names, safeguarding details, or case information in this course. | Feedback tool uses channel/process improvement only. | One visible reminder before L6.3 tool and safety statement. | Complaints require organizational procedures, not course spaces. |
| No safeguarding/protection records | L6.3, L6.6 | Sensitive issues should follow your organization’s safe referral, confidentiality, and escalation procedures. | No upload/request for case files or referral records. | Safety statement plus documentation checklist reminder. | Very high sensitivity data not uploaded. |
| No real officials/authorities/partners named | L6.4 | Use role categories, not names of officials, institutions, partners or sensitive actors. | Engagement reflection asks for roles only. | Single reminder before reflection/decision scenario. | Avoids civic-space risk. |
| Data minimization | L6.5, L6.6 | Collect only what is needed for a clear purpose and protect it. | Sorting and checklist test minimum necessary principle. | Repeated in L6.6 only. | Implementation data privacy boundary. |
| Synthetic data only for chart | L6.5 | The chart is fictional and for learning only. Do not upload real attendance or disaggregated data. | Chart values fixed; no data upload. | One reminder in chart block. | Avoids exposing implementation records. |
| Consent and visibility | L6.6 | Do not share learner/tool outputs outside the intended learning space unless explicit consent and safe summary rules apply. | Tool outputs private by default. | Summary note in documentation lesson. | Raw evidence/private records not shared. |
| Peer exchange excluded | Module 6 community layer | Peer exchange is not required for this self-paced module. | No peer exchange block in required build. | Not repeated in learner flow. | Avoids unsafe disclosure. |
| Legal-advice boundary | All module; L6.4/L6.6 where relevant | This course supports HRBA learning and safe practice. It does not provide legal advice or ask you to diagnose legal violations. | Disclaimer appears in README/build handoff; not overused in learner flow. | Avoid overloading; include in course support/disclaimer area. | No legal diagnosis requested. |
| Sensitive media/photos | Assets and documentation | Do not upload photos or documents showing recognizable people, case details, complaint text, or confidential records. | No upload requirement; asset prompts prohibit faces/readable sensitive text. | Asset-generation prompts include safety rules. | Media not required for learner completion. |

## Do not request

Never ask learners to submit:

- names of people, staff, officials, organizations, or communities;
- real complaints;
- complainant details;
- safeguarding or protection records;
- referral records;
- identifiable photos;
- staff or beneficiary lists;
- confidential operational records;
- political or civic-space-sensitive details;
- raw organizational data;
- uploads.

## Safe alternatives

Use:

- fictional examples;
- synthetic participation/feedback data;
- broad categories;
- role descriptions;
- non-identifying implementation examples;
- structured choices;
- optional private notes with safety helper text;
- private portfolio summaries.

## Feedback and documentation privacy boundary

Use this learner-facing message before feedback/documentation tools:

> Do not enter real complaints, complainant names, safeguarding details, referral information, photos, or identifying records. Focus on improving the feedback process or documentation practice, not recording case details.

## Minimum necessary documentation rule

Use in Lesson 6.6:

> Document only what is needed for a clear purpose, protect it, and avoid exposing people to harm.

## Privacy rules

| Data type | Default visibility |
|---|---|
| Tool outputs | Private by default |
| Optional reflections | Private by default |
| Feedback-loop notes | Private by default |
| Adaptation decision notes | Private by default |
| Documentation checklist | Private by default |
| Assessment completion | Learner/system only |
| Assessment score/response | Formative only; no certificate effect |
| Portfolio summaries | Learner private portfolio only |
| Admin analytics | Aggregated only, no raw notes/details |

## Accessibility and low-bandwidth QA

| QA item | Where checked | Requirement | Pass condition | Status | Notes |
| --- | --- | --- | --- | --- | --- |
| Keyboard access | All interactions | MCQ, multi-response, matching, sorting, tabs, accordions, checklists and tool fields work by keyboard. | All interactive blocks have keyboard/tap alternative. | Pass | Mandatory. |
| Screen-reader labels | All tools and inputs | All fields, buttons and options have clear labels. | No unlabeled controls. | Pass | Use semantic form labels. |
| Visible focus | All interactive blocks | Focus state visible and not color-only. | Visible outline/highlight on interactive elements. | Pass | Meets accessibility baseline. |
| Alt text | All images | Every image has meaningful alt text or is marked decorative if non-essential. | Asset register includes alt text. | Pass | Alt text and text alternatives approved for all visual assets. |
| Text alternatives | All diagrams/charts | Process diagrams, feedback loops, chart and accordion visuals include text equivalents. | Text alternative included in storyboard/build handoff. | Pass | Essential learning remains text-accessible. |
| Non-drag alternatives | Matching/sorting | Drag interactions have tap/keyboard/list alternatives. | Matching and sorting include non-drag alternative. | Pass | Required for mobile/screen readers. |
| Accessible chart | L6.5 | Chart has data table and explanation; no color-only meaning. | Data table alternative required. | Pass | Synthetic values only. |
| Mobile readability | All lessons | Single-column layout, readable text, large tap targets. | All activities specified as mobile-friendly. | Pass | Course player spec alignment. |
| Low bandwidth | All lessons/assets | Essential learning works without images/video/downloads. | Text alternatives and in-platform tools available. | Pass | No essential streaming media. |
| Reduced motion | All interactions | Avoid unnecessary animation; respect reduced-motion setting. | No required animation beyond simple reveals. | Pass | Important for process/tabs. |
| PDF/worksheet accessibility | Worksheets | All PDFs must be tagged or have in-platform alternative. | Every worksheet has in-platform alternative. | Pass | Accessible in-platform alternatives required for all worksheet assets. |
| Table/matrix readability | Checklists/tools | Tables/matrices convert to stacked cards on mobile. | Tool fields are stacked cards/short forms. | Pass | Avoid wide tables in learner view. |

## AI/data restriction

Raw reflections, optional notes, feedback-loop notes, adaptation notes, documentation notes, worksheet entries, and portfolio content should not be sent to AI services. If AI is later used for safe summaries, use structured non-sensitive tags or participant-approved safe summaries only.

## Safe helper text

Use before any optional text field or tool output:

> Keep this safe and general. Do not include names, real complaints, complainant details, safeguarding records, referral details, identifiable photos, staff or beneficiary lists, political details, confidential operational records, raw organizational data, or uploads.
