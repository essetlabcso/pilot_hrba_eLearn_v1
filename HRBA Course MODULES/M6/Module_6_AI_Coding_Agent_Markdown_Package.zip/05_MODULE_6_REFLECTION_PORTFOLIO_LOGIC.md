# Module 6 Reflection and Portfolio Logic

## Portfolio principle

Module 6 produces private implementation-practice tools. These outputs help the learner keep HRBA alive during delivery through participation, inclusion, accountability, constructive engagement, adaptation, and safe documentation. They are private by default, not graded, not certificate-linked, and not visible externally by default.

## Main Module 6 portfolio/tool outputs

1. Participation improvement checklist
2. Inclusive delivery reflection note
3. Feedback loop improvement note
4. Constructive engagement reflection
5. Adaptation decision note
6. Safe documentation checklist

## Portfolio behavior table

| Tool/reflection | Placement | Required status | Visibility | Save behavior | Skip behavior | Portfolio implication | Proof implication | Certificate implication | Safety rule |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Participation improvement checklist | L6.1 | Required interaction | Private by default | Optional portfolio save | Can complete without saving | Optional portfolio item | None | None | Use general activity; no names |
| Inclusive delivery reflection note | L6.2 | Optional | Private by default | Optional save | Skip allowed | Optional portfolio item | None | None | Do not identify vulnerable individuals/groups |
| Feedback loop improvement note | L6.3 | Required interaction | Private by default | Optional portfolio save | Complete tool; save optional | Optional portfolio item | None | None | Do not enter real complaints or sensitive details |
| Duty-bearer engagement reflection | L6.4 | Optional | Private by default | Optional save | Skip allowed | Optional portfolio item | None | None | Use role categories; no actor names |
| Adaptation decision note | L6.5 | Required interaction | Private by default | Optional portfolio save | Complete tool; save optional | Optional portfolio item | None | None | Use synthetic/general signals only |
| Safe documentation checklist | L6.6 | Required interaction | Private by default | Optional portfolio save | Complete tool; save optional | Optional portfolio item | None | None | No names, records, cases, photos, referrals |
| Module completion | End of module | Required completion of lessons/checks | Platform progress only | Automatic progress status | Not skippable after enrolled | No portfolio requirement | None | Certificate depends only on final course test 80%+ | No sensitive data |

## Final Module 6 portfolio checkpoint

The main integrated checkpoint is the **HRBA implementation practice note**.

### Saved fields

- participation improvement selected;
- inclusion/access barrier and practical adjustment;
- feedback-loop improvement action;
- constructive engagement approach;
- adaptation decision and rationale;
- safe documentation choice;
- risk or harm-prevention note;
- optional private note.

### Safety helper text

Use before any optional text field:

> Keep this safe and general. Do not include names, real complaints, complainant details, safeguarding records, referral details, identifiable photos, staff or beneficiary lists, political details, confidential operational records, raw organizational data, or uploads.

## Save behavior

When the learner saves a Module 6 output:

```text
save:
  module_id = M06
  output_type
  structured selections
  optional private note if entered
  timestamp

do_not_save:
  names
  real complaint details
  complainant names
  safeguarding/protection records
  referral records
  identifiable photos
  staff or beneficiary lists
  political details
  confidential operational records
  raw organizational data
  uploaded files
```

## Deterministic synthesis logic

| Rule ID | Input | Output |
|---|---|---|
| `M6_SYN_01` | participation checklist | Add to “How I will keep participation alive” |
| `M6_SYN_02` | inclusive delivery note | Add to “Access barrier and practical adjustment” |
| `M6_SYN_03` | feedback loop improvement | Add to “How I will close the feedback loop” |
| `M6_SYN_04` | constructive engagement reflection | Add to “How I can engage responsible actors safely” |
| `M6_SYN_05` | adaptation decision note | Add to “How I will adapt safely using feedback/evidence” |
| `M6_SYN_06` | safe documentation checklist | Add to “Minimum necessary documentation and protection choices” |
| `M6_SYN_07` | optional private notes | Include only in private export; never in safe-share summary |
| `M6_SYN_08` | skipped saves | Show “Not saved yet — you can return later,” without penalty |

## Carry-forward logic

| Later module | How Module 6 portfolio data is reused |
|---|---|
| Module 7 — HRBA in MEAL and Evidence Use | Use participation, feedback, adaptation, and documentation notes to design safer indicators, evidence sources, and feedback loops. |
| Module 8 — Accountability and Learning | Use feedback-loop and report-back improvements to strengthen accountability and learning practice. |
| Module 9 — Course Closing and 90-Day Action Plan | Use selected implementation improvements as candidates for a 90-day HRBA action plan. |

## Visibility rules

| User type | Can see Module 6 portfolio content? |
|---|---|
| Participant | Yes, their own private portfolio |
| Course facilitator | No by default; only safe aggregate or consent-based summary if enabled |
| CSO focal person | No individual notes by default |
| Peer participant | No |
| Donor or external partner | No |
| Admin dashboard | Aggregate tags only, no private notes |
| AI service | No raw reflections, implementation notes, worksheet entries, or private notes |
