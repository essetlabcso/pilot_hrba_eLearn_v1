# Module 3 Asset Placeholders and Alt Text

## Asset rule

Do not invent final asset filenames or paths. Use approved filenames where listed. If a file is missing, render a placeholder component using the approved filename reference and log the missing asset in the build evidence pack.

## Visual style

Use CSO Learning Hub / DEC visual identity:

- primary blue: `#3B99D4`
- accent green: `#91C852`
- deep navy: `#0F172A`
- light background: `#F9FAFB`
- white cards
- dark text: `#111827`
- subtle borders: `#E5E7EB`
- rounded corners
- soft shadows

Visuals should feel Ethiopian/East African, local CSO, modest, participatory, respectful, and professional without feeling corporate or extractive.

## Asset register

| Asset ID | Placement | Type | Required? | Approved filename | Alt text requirement |
|---|---|---|---:|---|---|
| A-M03-001 | Module 3 intro | Module header image | Optional | `module-3-hrba-principles.jpg` | Local CSO team discussing HRBA principles during a practical planning session. |
| A-M03-002 | M03-L01-B01 | Lesson image | Optional | `m03-participation-meeting.jpg` | CSO facilitator listening to community members during a consultation meeting. |
| A-M03-003 | M03-L01-B03 | Diagram | Recommended | `m03-four-tests-participation.svg` | Diagram showing four tests of meaningful participation: inclusive, informed, safe, influential. Full text alternative required. |
| A-M03-004 | M03-L01-B05 | Worksheet PDF | Recommended | `participation-quality-checklist.pdf` | Participation quality checklist worksheet with fields for strengths, missing groups, one improvement, and report-back. |
| A-M03-005 | M03-L02-B02 | Labeled graphic | Recommended | `m03-exclusion-pathway.svg` | Pathway diagram showing where exclusion can occur: information, access, voice, decision, benefit, feedback. |
| A-M03-006 | M03-L02-B03 | Case image | Optional | `m03-inclusive-training-case.jpg` | Training setting used to discuss inclusion barriers; avoid stereotyping and include text alternative. |
| A-M03-007 | M03-L02-B04 | Worksheet PDF | Recommended | `inclusion-barrier-scan.pdf` | Inclusion barrier scan worksheet with privacy/safety note and accessible fields. |
| A-M03-008 | M03-L03-B01 | Process diagram | Recommended | `m03-accountability-loop.svg` | Accountability loop diagram with five steps: inform, listen, respond, act, report back. Full text alternative required. |
| A-M03-009 | M03-L03-B03 | Case image | Optional | `m03-feedback-box-case.jpg` | Feedback box in a modest CSO setting. Use only as illustrative image. |
| A-M03-010 | M03-L03-B05 | Worksheet PDF | Recommended | `feedback-loop-improvement-note.pdf` | Feedback loop improvement note worksheet. Include warning not to enter real complaints or names. |
| A-M03-011 | M03-L04-B01 | Diagram | Recommended | `m03-capacity-bridge.svg` | Capacity bridge diagram connecting rights-holder, duty-bearer, and CSO capacity. |
| A-M03-012 | M03-L04-B02 | Lesson image | Optional | `m03-empowerment-agency.jpg` | Community members and CSO facilitator preparing questions together; use respectful wording. |
| A-M03-013 | M03-L04-B04 | Worksheet PDF | Recommended | `capacity-support-note.pdf` | Capacity support note worksheet with fields for rights-holder capacity, duty-bearer capacity, CSO capacity, action, and risk. |
| A-M03-014 | M03-L05-B03 | Scenario image | Optional | `m03-standards-carefully.jpg` | CSO staff reviewing standards and project notes carefully; avoid implying legal advice. |
| A-M03-015 | M03-L05-B04 | Worksheet PDF | Recommended | `safe-standards-use-checklist.pdf` | Safe standards-use checklist worksheet. Include disclaimer that it is not legal advice. |
| A-M03-016 | M03-L06-B02 | Scenario image | Optional | `m03-safe-storytelling-decision.jpg` | CSO team reviewing a story draft with privacy and consent in mind; no faces or identifiable details. |
| A-M03-017 | M03-L06-B03 | Worksheet PDF | Recommended | `do-no-harm-quick-scan.pdf` | Do-no-harm quick scan worksheet. Accessible PDF and printable version required. |

## Asset implementation rules

- Every image/SVG must include alt text.
- Complex diagrams need full text alternatives.
- PDF worksheets must also have in-platform field versions.
- Do not use photos that identify vulnerable people or sensitive situations.
- Avoid text-heavy images; all essential text must also exist as HTML text.
- If assets are missing, render placeholder cards using the approved filename reference.
