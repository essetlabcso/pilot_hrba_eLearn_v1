# Module 3 Reflection and Portfolio Logic

## Portfolio principle

Module 3 portfolio outputs are practical HRBA principle notes. They are private by default, not graded, not certificate-linked, and not externally visible unless a separate approved sharing/consent process is introduced later.

The module can group saved outputs under:

# My HRBA Principles Practice Notes

## Module 3 portfolio/tool moments

| Screen | Output | Purpose | Required for learning? | Certificate effect | Visibility |
|---|---|---|---:|---:|---|
| M03-L01-B05 | Participation quality checklist | Test participation quality before implementation | Recommended / platform policy | No | Private |
| M03-L02-B04 | Inclusion barrier scan | Identify barriers and one design change | Recommended / platform policy | No | Private |
| M03-L03-B05 | Feedback loop improvement note | Strengthen feedback and report-back practice | Recommended / platform policy | No | Private |
| M03-L04-B04 | Capacity support note | Identify rights-holder, duty-bearer, and CSO capacity support actions | Recommended / platform policy | No | Private |
| M03-L04-B05 | Avoiding dependency reflection | Reflect on power-aware support | Optional | No | Private |
| M03-L05-B04 | Safe standards-use checklist | Use standards carefully without legal advice | Recommended / platform policy | No | Private |
| M03-L06-B03 | Do-no-harm quick scan | Identify risks and safer alternatives | Recommended / platform policy | No | Private |
| M03-L06-B05 | One safer change reflection | Identify one safer change for CSO practice | Optional | No | Private |

## Safety helper text

Use this before any optional text or tool field:

> Keep this safe and general. Do not include names, real cases, active complaints, safeguarding details, legal disputes, political details, confidential documents, beneficiary lists, or raw organizational data.

For the standards-use lesson, use the stronger legal-learning boundary:

> This activity is for learning and project-quality reflection only. It is not legal advice. Do not use it to diagnose real legal violations, record real cases, or enter names, complaints, confidential records, safeguarding details, political details, or legal allegations. For legal questions, consult qualified, up-to-date legal advice.

## Tool fields

### Participation quality checklist

Save if learner chooses:

- general activity title;
- checklist responses;
- participation strengths;
- missing groups or voices;
- one improvement before implementation;
- report-back plan;
- timestamp;
- module ID: M03.

Do not save names, real communities, politically sensitive actors, or confidential details.

### Inclusion barrier scan

Save if learner chooses:

- general activity;
- intended participants or beneficiaries;
- information barriers;
- access barriers;
- safety or social barriers;
- language or literacy barriers;
- disability-related barriers;
- gender or age-related barriers;
- one design change;
- timestamp;
- module ID: M03.

Use broad group categories only.

### Feedback loop improvement note

Save if learner chooses:

- current feedback channel;
- who can access it;
- who may be excluded;
- review process;
- response communication process;
- one improvement;
- timestamp;
- module ID: M03.

Do not save real complaints, complainant names, active cases, or safeguarding details.

### Capacity support note

Save if learner chooses:

- general issue;
- rights-holder capacity to strengthen;
- duty-bearer capacity to strengthen;
- CSO capacity needed;
- practical support action;
- risk to avoid;
- timestamp;
- module ID: M03.

Use strengths-based language and general descriptions.

### Safe standards-use checklist

Save if learner chooses:

- checklist responses;
- reliability concern flag;
- responsibility clarity flag;
- evidence sufficiency flag;
- risk/advice flag;
- timestamp;
- module ID: M03.

Do not save legal allegations, legal case details, names, complaints, or confidential records.

### Do-no-harm quick scan

Save if learner chooses:

- risk flags;
- identifiable information flag;
- backlash/stigma flag;
- data necessity flag;
- consent clarity flag;
- safer alternative flag;
- response plan flag;
- timestamp;
- module ID: M03.

Do not save active case details or raw stories.

## Deterministic synthesis logic

| Rule ID | Input | Output |
|---|---|---|
| `M3_SYN_01` | Participation checklist improvement | Add to “Participation improvement to try” |
| `M3_SYN_02` | Inclusion barrier design change | Add to “Inclusion barrier to reduce” |
| `M3_SYN_03` | Feedback loop improvement | Add to “Accountability practice to strengthen” |
| `M3_SYN_04` | Capacity support action | Add to “Capacity support action” |
| `M3_SYN_05` | Safe standards checklist risk/advice flag | Add to “Standards-use caution” |
| `M3_SYN_06` | Do-no-harm risk/safer alternative flag | Add to “Safety adjustment needed” |
| `M3_SYN_07` | Optional private reflections | Include only in private export; never in safe-share summary |
| `M3_SYN_08` | Skipped optional reflections | Show “Not saved yet — you can return later,” without penalty |

## Example safe generated summary

> In Module 3, I identified one participation improvement, one inclusion barrier to reduce, one accountability practice to strengthen, one capacity support action, one standards-use caution, and one do-no-harm adjustment. These are private learning notes that can support later project design, MEAL, and action planning.

## Carry-forward logic

| Later module | How Module 3 portfolio/tool outputs are reused |
|---|---|
| Module 4 — Rights-Holders, Duty-Bearers, Power, and Exclusion | Use participation, inclusion, and capacity notes to deepen actor and power analysis. |
| Module 5 — Applying HRBA in Project Design | Use participation, barrier, feedback, and capacity outputs as design quality checks. |
| Module 6 — Implementation and Partnerships | Use accountability, standards, and do-no-harm outputs to improve implementation safeguards. |
| Module 7 — HRBA in MEAL and Evidence Use | Use feedback loop and do-no-harm outputs to shape safer evidence and accountability systems. |
| Module 9 — Course Closing and 90-Day Action Plan | Use selected improvement actions as inputs to the final 90-day HRBA action plan. |

## Visibility rules

| User type | Can see Module 3 portfolio/tool outputs? |
|---|---|
| Participant | Yes, their own private outputs |
| Course facilitator | No by default; only safe aggregate or consent-based summary if enabled |
| CSO focal person | No individual notes by default |
| Peer participant | No |
| Donor or external partner | No |
| Admin dashboard | Aggregate tags only, no private notes |
| AI service | No raw reflections, worksheet entries, or private notes |
