# Module 3 Block Storyboard

## Module identity

| Field | Final entry |
|---|---|
| Course title | Applying the Human Rights-Based Approach in CSO Practice |
| Module title | Module 3: HRBA Principles in Practice |
| Recommended duration | 90–110 minutes |
| Approved lesson count | 6 |
| Approved learner-facing block count | 37 blocks plus module header/overview in the course-player shell |
| Main portfolio/tool outputs | Participation quality checklist; inclusion barrier scan; feedback loop improvement note; capacity support note; safe standards-use checklist; do-no-harm quick scan; optional safer-change reflection |
| Certificate rule | Module 3 checks are formative only. Certificate remains tied to final course test score of 80% or above. |
| Privacy rule | Tool outputs, optional notes, and reflection outputs are private by default. |

## Lesson summary

| Lesson | Title | Screens/blocks | Learning purpose |
|---|---|---:|---|
| 3.1 | Participation and Inclusion | 6 | Improve participation quality and inclusion before decisions are finalized |
| 3.2 | Equality and Non-Discrimination | 6 | Scan activities for barriers that may exclude people or reinforce unequal access |
| 3.3 | Accountability and Transparency | 6 | Strengthen feedback loops, answerability, and report-back practices |
| 3.4 | Empowerment and Capacity Development | 6 | Identify capacity support actions for rights-holders, duty-bearers, and CSOs |
| 3.5 | Legality and Human Rights Standards | 6 | Use human-rights standards carefully without giving or requesting legal advice |
| 3.6 | Do-No-Harm and Safe Practice | 7 | Identify privacy, backlash, fatigue, misinformation, and other risks before acting |

## Detailed storyboard table

| Screen ID | Section | Screen title | Block type | Learning purpose | Learner action | Completion rule | Data saved | Privacy rule | Accessibility / low-bandwidth rule | Asset requirement |
|---|---|---|---|---|---|---|---|---|---|---|
| M03-L01-B01 | 3.1 Participation and Inclusion | A consultation that looked participatory | Scenario Hook | Engage and diagnose token participation | Read fictional scenario | Viewed | Viewed status | Fictional only | Text-first; image optional; alt text required | m03-participation-meeting.jpg |
| M03-L01-B02 | 3.1 Participation and Inclusion | Participation is more than attendance | Text Micro-Lesson | Explain meaningful participation | Read explanation | Viewed | Viewed status | No personal data | Text-first | None |
| M03-L01-B03 | 3.1 Participation and Inclusion | Four tests of meaningful participation | Tabs | Reveal participation tests | Open four tabs | All tabs opened or accessible text list viewed | Viewed tabs | No personal data | Keyboard accessible tabs; text fallback | m03-four-tests-participation.svg |
| M03-L01-B04 | 3.1 Participation and Inclusion | Improve the participation plan | Decision Activity | Apply participation tests | Choose best option | Select and view feedback | Completion; response optional | No real local actors | Keyboard/tap options | None |
| M03-L01-B05 | 3.1 Participation and Inclusion | Participation quality checklist | Tool Activity / Checklist | Apply participation quality checklist | Complete or download checklist | View tool; save optional by policy | Private tool output if saved | Private by default | Accessible in-platform form + PDF | participation-quality-checklist.pdf |
| M03-L01-B06 | 3.1 Participation and Inclusion | Token or meaningful participation? | Knowledge Check | Check understanding | Answer MCQ | Answer and view feedback | Completion; response optional | No personal data | Accessible MCQ | None |
| M03-L02-B01 | 3.2 Equality and Non-Discrimination | Equality is not treating everyone exactly the same | Statement | Clarify equality/non-discrimination | Read statement | Viewed | Viewed status | No personal data | Statement not color-only | None |
| M03-L02-B02 | 3.2 Equality and Non-Discrimination | Where exclusion can happen | Labeled Graphic | Show exclusion points | Open six markers | All markers opened or text alternative viewed | Viewed markers | No personal data | Full text alternative | m03-exclusion-pathway.svg |
| M03-L02-B03 | 3.2 Equality and Non-Discrimination | A training that excluded people without intending to | Case Study | Practice barrier recognition | Read case; reveal barriers | Viewed and reveal opened | Viewed status | Fictional only | Text-first; image optional | m03-inclusive-training-case.jpg |
| M03-L02-B04 | 3.2 Equality and Non-Discrimination | Inclusion barrier scan | Tool Activity | Apply barrier scan | Complete or download tool | View tool; save optional by policy | Private tool output if saved | Private by default | Accessible form + PDF | inclusion-barrier-scan.pdf |
| M03-L02-B05 | 3.2 Equality and Non-Discrimination | Barrier or solution? | Sorting Activity | Classify barriers/solutions | Sort six items | All sorted and feedback viewed | Completion; attempts optional | No personal examples | Non-drag alternative | None |
| M03-L02-B06 | 3.2 Equality and Non-Discrimination | Non-discrimination in practice | Knowledge Check | Check interpretation | Answer MCQ | Answer and view feedback | Completion; response optional | No personal data | Accessible MCQ | None |
| M03-L03-B01 | 3.3 Accountability and Transparency | The accountability loop | Process | Explain accountability loop | Open five steps | All steps opened or text list viewed | Viewed status | No complaint details | Process text alternative | m03-accountability-loop.svg |
| M03-L03-B02 | 3.3 Accountability and Transparency | Transparency builds trust | Text Micro-Lesson | Clarify transparency and confidentiality | Read | Viewed | Viewed status | No personal data | Text-first | None |
| M03-L03-B03 | 3.3 Accountability and Transparency | A feedback box is not enough | Case Study / Multiple Response | Identify feedback weaknesses | Select weaknesses | Feedback viewed | Completion; response optional | No real complaints | Accessible multiple response | m03-feedback-box-case.jpg |
| M03-L03-B04 | 3.3 Accountability and Transparency | Match the accountability action | Matching Activity | Match problems to stronger practices | Match five pairs | All matched and feedback viewed | Completion; attempts optional | No real complaint data | Keyboard/tap matching | None |
| M03-L03-B05 | 3.3 Accountability and Transparency | Feedback loop improvement note | Tool Activity | Improve feedback loop | Complete or download tool | View tool; save optional by policy | Private tool output if saved | Private by default | Accessible form + PDF | feedback-loop-improvement-note.pdf |
| M03-L03-B06 | 3.3 Accountability and Transparency | Closing the loop | Knowledge Check | Check accountability concept | Answer MCQ | Answer and view feedback | Completion; response optional | No personal data | Accessible MCQ | None |
| M03-L04-B01 | 3.4 Empowerment and Capacity Development | Empowerment is not speaking for people forever | Accordion | Reveal capacities | Open four panels | All panels opened or text list viewed | Viewed panels | No personal data | Keyboard accessible accordion | m03-capacity-bridge.svg |
| M03-L04-B02 | 3.4 Empowerment and Capacity Development | From delivering awareness to strengthening agency | Case Example | Show empowerment shift | Read case | Viewed | Viewed status | Respectful fictional example | Text-first; image optional | m03-empowerment-agency.jpg |
| M03-L04-B03 | 3.4 Empowerment and Capacity Development | What capacity is being strengthened? | Sorting Activity | Classify capacity support actions | Sort six items | All sorted and feedback viewed | Completion; attempts optional | No sensitive data | Non-drag alternative | None |
| M03-L04-B04 | 3.4 Empowerment and Capacity Development | Capacity support note | Tool Activity | Apply capacity support analysis | Complete or download tool | View tool; save optional by policy | Private tool output if saved | Private by default | Accessible form + PDF | capacity-support-note.pdf |
| M03-L04-B05 | 3.4 Empowerment and Capacity Development | Avoiding dependency | Private Reflection | Reflect on power-aware support | Write optional note or continue | Save or skip | Optional private note | Private only | Safety helper before note | None |
| M03-L04-B06 | 3.4 Empowerment and Capacity Development | Empowerment in HRBA | Knowledge Check | Check empowerment concept | Answer MCQ | Answer and view feedback | Completion; response optional | No personal data | Accessible MCQ | None |
| M03-L05-B01 | 3.5 Legality and Human Rights Standards | Legality means grounding action in standards | Text Micro-Lesson | Explain legality principle | Read | Viewed | Viewed status | No personal data | Plain language; no legal advice | None |
| M03-L05-B02 | 3.5 Legality and Human Rights Standards | Important boundary | Statement / Disclaimer | Set legal-advice boundary | Acknowledge disclaimer | Viewed / acknowledged | Disclaimer viewed | No personal data | Distinct but not alarming | None |
| M03-L05-B03 | 3.5 Legality and Human Rights Standards | Using standards carefully | Scenario / Reveal | Practice safer standards use | Read and reveal weak/strong statements | Reveal viewed | Viewed status | Fictional only | Text alternative for image | m03-standards-carefully.jpg |
| M03-L05-B04 | 3.5 Legality and Human Rights Standards | Safe standards-use checklist | Checklist | Apply safe standards-use check | Complete checklist or download | View tool; save optional by policy | Private tool output if saved | Private by default | Accessible checklist + PDF | safe-standards-use-checklist.pdf |
| M03-L05-B05 | 3.5 Legality and Human Rights Standards | What legality means for CSOs | Knowledge Check | Check legality principle | Answer MCQ | Answer and view feedback | Completion; response optional | No legal claims | Accessible MCQ | None |
| M03-L05-B06 | 3.5 Legality and Human Rights Standards | Use standards responsibly | Key Takeaway | Consolidate standards use | Read | Viewed | Viewed status | No personal data | Text-first | None |
| M03-L06-B01 | 3.6 Do-No-Harm and Safe Practice | Do-no-harm is an HRBA discipline | Safety Statement | Explain do-no-harm | Read | Viewed | Viewed status | No personal data | Calm safety callout | None |
| M03-L06-B02 | 3.6 Do-No-Harm and Safe Practice | A risky community story | Decision Scenario | Apply safe storytelling judgment | Choose best option | Select and view feedback | Completion; response optional | Fictional only | Keyboard/tap decision | m03-safe-storytelling-decision.jpg |
| M03-L06-B03 | 3.6 Do-No-Harm and Safe Practice | Do-no-harm quick scan | Checklist | Apply risk scan | Complete checklist or download | View tool; save optional by policy | Private tool output if saved | Private by default | Accessible checklist + PDF | do-no-harm-quick-scan.pdf |
| M03-L06-B04 | 3.6 Do-No-Harm and Safe Practice | Safer or riskier practice? | Sorting Activity | Classify safety practices | Sort six items | All sorted and feedback viewed | Completion; attempts optional | No personal examples | Non-drag alternative | None |
| M03-L06-B05 | 3.6 Do-No-Harm and Safe Practice | One safer change | Private Reflection | Reflect on safer change | Write optional note or continue | Save or skip | Optional private note | Private only | Safety helper before note | None |
| M03-L06-B06 | 3.6 Do-No-Harm and Safe Practice | Best do-no-harm action | Knowledge Check | Check do-no-harm concept | Answer MCQ | Answer and view feedback | Completion; response optional | No sensitive data | Accessible MCQ | None |
| M03-L06-B07 | 3.6 Do-No-Harm and Safe Practice | Module 3 summary | Module Summary | Summarize and transition | Read summary | Viewed | Module completion status | No personal data | Text-first | None |
