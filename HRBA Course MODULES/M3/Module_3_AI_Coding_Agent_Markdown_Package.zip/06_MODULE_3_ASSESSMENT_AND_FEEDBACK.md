# Module 3 Assessment and Feedback Map

## Module 3 assessment rule

All Module 3 checks are **formative only**. They help participants practice applying HRBA principles as decision checks.

Module 3 checks do **not**:

- issue a certificate;
- unlock a certificate;
- replace the final course test;
- rank the participant;
- rank the CSO;
- require sensitive information;
- require uploads;
- require real cases, complaint records, safeguarding details, legal allegations, or confidential organizational data.

The course certificate remains linked to the **final course test with a score of 80% or above**.

## Assessment sequence

| Assessment ID | Placement | Assessment type | Purpose | Certificate effect |
|---|---|---|---|---:|
| KC-M03-01 | M03-L01-B06 | MCQ | Identify meaningful participation | No |
| ACT-M03-01 | M03-L01-B05 | Checklist tool | Apply participation quality checks | No |
| KC-M03-02 | M03-L02-B06 | MCQ | Interpret non-discrimination in practice | No |
| ACT-M03-02 | M03-L02-B04 | Tool activity | Scan for inclusion barriers | No |
| KC-M03-03 | M03-L03-B06 | MCQ | Identify accountability action | No |
| ACT-M03-03 | M03-L03-B05 | Tool activity | Improve feedback loop | No |
| KC-M03-04 | M03-L04-B06 | MCQ | Identify empowerment practice | No |
| ACT-M03-04 | M03-L04-B04 | Tool activity | Identify capacity support action | No |
| KC-M03-05 | M03-L05-B05 | MCQ | Interpret legality principle safely | No |
| ACT-M03-05 | M03-L05-B04 | Checklist | Apply safe standards-use checklist | No |
| KC-M03-06 | M03-L06-B06 | MCQ | Identify do-no-harm action | No |
| ACT-M03-06 | M03-L06-B03 | Checklist | Apply do-no-harm quick scan | No |

## Feedback rules

Use:

- “That’s right.”
- “Good choice.”
- “Not quite.”

Do not use:

- “Incorrect”
- “Wrong”
- “Failed”
- “Pass/fail”
- “Your CSO is weak”
- “Your organization is non-compliant”
- “This affects your certificate”

# MCQ and decision feedback

## M03-L01-B04 — Improve the participation plan

Best response: B

Feedback for A: Not quite. Photos can show that an event happened, but they do not make participation meaningful or influential.  
Feedback for B: That’s right. HRBA participation is early, inclusive, informed, safe, and able to influence decisions.  
Feedback for C: Not quite. Local leaders may be important, but relying only on leaders can exclude affected groups and quieter voices.  
Feedback for D: Not quite. Participation takes planning, but cancelling it removes a core HRBA principle.

## KC-M03-01 — Token or meaningful participation?

Best response: C

Feedback for A: Not quite. Signatures after a plan is finalized may show awareness or attendance, but they do not show influence.  
Feedback for B: Not quite. Leaders may be useful, but meaningful participation should ask who else is affected and who may be missing.  
Feedback for C: That’s right. Meaningful participation can influence decisions and includes report-back to participants.  
Feedback for D: Not quite. A photo can support documentation, but it is not the same as rights-holders shaping decisions.

## KC-M03-02 — Non-discrimination in practice

Best response: B

Feedback for A: Not quite. Same treatment can still exclude people when barriers differ.  
Feedback for B: That’s right. HRBA requires attention to different barriers and fair access.  
Feedback for C: Not quite. Convenience should not decide who is included.  
Feedback for D: Not quite. Safe feedback can help a CSO identify exclusion and improve practice.

## KC-M03-03 — Closing the loop

Best response: C

Feedback for A: Not quite. Feedback that is stored but not reviewed does not close the accountability loop.  
Feedback for B: Not quite. Visibility is not the same as accountability.  
Feedback for C: That’s right. Accountability requires response and reporting back, not only collection.  
Feedback for D: Not quite. Feedback may need careful handling, but avoiding it removes an important accountability pathway.

## KC-M03-04 — Empowerment in HRBA

Best response: B

Feedback for A: Not quite. Technical knowledge matters, but empowerment should not remove rights-holder voice and influence.  
Feedback for B: That’s right. Empowerment strengthens agency, participation, and capacity.  
Feedback for C: Not quite. HRBA often requires constructive engagement with responsible actors where safe and appropriate.  
Feedback for D: Not quite. Distribution alone may be useful, but empowerment also builds capacity, voice, and influence.

## KC-M03-05 — What legality means for CSOs

Best response: B

Feedback for A: Not quite. CSO staff can use HRBA standards as learning and design guidance without becoming lawyers.  
Feedback for B: That’s right. Legality helps ground action responsibly while recognizing when expert advice is needed.  
Feedback for C: Not quite. HRBA uses standards carefully; it is not a license for unsupported accusations.  
Feedback for D: Not quite. HRBA is grounded in rights and standards, but those standards must be used responsibly.

## M03-L06-B02 — A risky community story

Best response: C

Feedback for A: Not quite. A powerful story can still expose someone to harm.  
Feedback for B: Not quite. Consent should be meaningful and risk-aware; publishing all identifying details may still be unsafe.  
Feedback for C: That’s right. Safe storytelling balances voice, dignity, consent, and risk.  
Feedback for D: Not quite. Avoiding all stories is unnecessary when safer, consent-based, anonymized, or composite approaches are possible.

## KC-M03-06 — Best do-no-harm action

Best response: B

Feedback for A: Not quite. More data is not always safer or better.  
Feedback for B: That’s right. Do-no-harm requires necessity, risk assessment, consent, and safer alternatives.  
Feedback for C: Not quite. Names should only be collected when necessary, safe, proportionate, and clearly explained.  
Feedback for D: Not quite. Avoidance is not the only safe option. CSOs can still listen while using safer methods.

# Sorting and matching feedback

## M03-L02-B05 — Barrier or solution?

Correct map:

| Item | Best category |
|---|---|
| Venue has stairs only | Barrier |
| Invitation shared only through leaders | Barrier |
| Meeting time adjusted after women participants give feedback | Solution |
| Simple language and local language explanation | Solution |
| No transport consideration for remote participants | Barrier |
| Anonymous feedback option | Solution |

Best-response feedback: Good choice. Inclusion improves when CSOs notice practical barriers and redesign participation, information, access, and feedback.

Weaker-response feedback: Not quite. Think about whether the item makes participation or benefit harder, or whether it reduces a barrier.

## M03-L03-B03 — A feedback box is not enough

Expected response: all listed weaknesses are relevant.

Feedback if several relevant options selected: That’s right. A feedback mechanism is only useful if people can access it, trust it, understand it, and see that the CSO responds.

Feedback if only one option selected: Not quite. One issue may be visible first, but this example has several weaknesses: access, trust, literacy, confidentiality, response, and reporting back.

## M03-L03-B04 — Match the accountability action

Correct pairs:

| Accountability problem | Stronger practice |
|---|---|
| People do not know selection criteria | Share simple eligibility information |
| Feedback is collected but not reviewed | Assign responsibility and review schedule |
| Complaints may expose people | Provide confidential channel and protection guidance |
| Communities do not know what changed | Report back in accessible way |
| Staff fear blame | Use learning-focused internal review |

Best-response feedback: Good choice. Strong accountability needs information, safe channels, responsibility, action, and reporting back.

Weaker-response feedback: Not quite. Look for the practice that directly fixes the accountability weakness.

## M03-L04-B03 — What capacity is being strengthened?

Correct map:

| Action | Best category |
|---|---|
| Training community facilitators to explain feedback channels | CSO capacity |
| Supporting women participants to prepare questions for a public service meeting | Rights-holder capacity |
| Helping a local office improve response tracking | Duty-bearer capacity |
| Creating accessible information materials | CSO capacity |
| Supporting youth groups to analyze barriers and propose solutions | Rights-holder capacity |
| Helping a service provider understand inclusion obligations | Duty-bearer capacity |

Best-response feedback: Good choice. HRBA often strengthens several capacities together. The key is to be clear whose capacity is being strengthened and why.

Weaker-response feedback: Not quite. Ask whether the action mainly strengthens the people claiming rights, the actor responsible to respond, or the CSO supporting the process.

## M03-L06-B04 — Safer or riskier practice?

Correct map:

| Practice | Best category |
|---|---|
| Asking for full names in a sensitive feedback form | Riskier |
| Using anonymized categories when names are not needed | Safer |
| Posting identifiable photos without clear consent | Riskier |
| Explaining how feedback will be used | Safer |
| Sharing raw complaint data in a public report | Riskier |
| Using a fictionalized case for learning | Safer |

Best-response feedback: Good choice. Do-no-harm often means reducing unnecessary exposure while preserving learning and accountability.

Weaker-response feedback: Not quite. Ask whether the practice increases exposure or reduces risk.

# Tool auto-feedback

| Tool | Auto-feedback |
|---|---|
| Participation quality checklist | If several items are “Not yet,” choose one improvement before proceeding with implementation. |
| Inclusion barrier scan | Focus first on barriers that could prevent people from participating safely or benefiting fairly. |
| Feedback loop improvement note | Prioritize improvements that increase trust, accessibility, confidentiality, and response. |
| Capacity support note | Strong HRBA action often supports both rights-holder agency and duty-bearer responsiveness. |
| Safe standards-use checklist | If several items are “Not yet,” pause and seek support before making strong public claims. |
| Do-no-harm quick scan | If any item raises concern, pause, adapt, and seek support before proceeding. |

## Assessment data map

| Assessment/tool | Required saved data | Optional saved data | Do not save |
|---|---|---|---|
| MCQs and decisions | Completion status | Selected responses for learner feedback only | Public ranking, certificate score, sensitive details |
| Sorting/matching | Completion status | Attempts/selected pairs for learning analytics only | Personal examples |
| Tool activities | Completion status if platform requires | Private structured portfolio output if learner saves | Names, complaints, cases, legal allegations, safeguarding details |
| Reflections | None if skipped | Optional private note if learner saves | Sensitive details, real cases, raw stories |
