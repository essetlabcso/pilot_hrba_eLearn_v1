# Module 3 Safety, Accessibility, and Data Rules

## Safety principle

Module 3 has moderate-to-high sensitivity because it includes participation, feedback, inclusion, standards-use, legal boundaries, storytelling, and do-no-harm. It must be safe by default.

## Do not request

Never ask learners to submit:

- names of people, staff, officials, organizations, or communities;
- real case details;
- active complaint details;
- safeguarding or protection information;
- beneficiary lists;
- personal data;
- legal allegations or legal case details;
- internal reports;
- confidential documents;
- political or civic-space-sensitive details;
- raw organizational data;
- identifiable community stories;
- uploads.

## Safe alternatives

Use:

- fictional examples;
- general activity descriptions;
- broad group categories;
- non-identifying descriptions;
- structured choices;
- optional private notes with safety helper text;
- portfolio/tool summaries rather than raw evidence.

## Legal-learning boundary

Display before standards-use activities:

> This activity is for learning and project-quality reflection only. It is not legal advice. Do not use it to diagnose real legal violations, record real cases, or enter names, complaints, confidential records, safeguarding details, political details, or legal allegations. For legal questions, consult qualified, up-to-date legal advice.

## Privacy rules

| Data type | Default visibility |
|---|---|
| Knowledge-check completion | Learner/system only |
| Tool outputs | Learner private portfolio only if saved |
| Optional notes | Learner private portfolio only |
| Checklist responses | Learner private portfolio only if saved |
| Module completion | System status |
| Module scores | Formative only; no certificate effect |

## Certificate rule

- Module 3 checks are formative only.
- Module 3 does not issue certificates.
- Certificate eligibility remains tied to the final course test score of **80% or above**.

## AI/data restriction

Raw reflections, worksheet entries, optional notes, and portfolio/tool content should not be sent to AI services. If AI is later used for safe summaries, use structured non-sensitive tags or participant-approved safe summaries only.

## Accessibility requirements

| Requirement | Rule |
|---|---|
| Keyboard access | Required for all interactive blocks |
| Tap-first mobile | Required for all interactions |
| Screen-reader labels | Required for buttons, radio buttons, checkboxes, tabs, cards, inputs, and forms |
| Non-drag alternative | Required for sorting and matching |
| Text alternative | Required for diagrams, images, process visuals, and SVGs |
| Mobile stack | Required for cards, diagrams, forms, and checks |
| No color-only meaning | Required for feedback, status, selected states, and warnings |
| Plain language | Required throughout |
| Optional text fields | Must include safety helper text |
| Low-bandwidth fallback | Required for all media and visuals |
| Visible focus states | Required for all controls |
| Reduced motion | Avoid unnecessary animation and respect reduced-motion settings |

## Low-bandwidth rules

The module must be usable without:

- streaming video;
- high-resolution images;
- drag-heavy interactions;
- PDF download dependency;
- external embeds.

Where assets are heavy, provide:

- lightweight SVG;
- compressed image;
- text alternative;
- in-platform worksheet fields;
- printable/downloadable option only as supplement.

## General safety helper text

Use before optional text/tool fields:

> Keep this safe and general. Do not include names, real cases, active complaints, safeguarding details, legal disputes, political details, confidential documents, beneficiary lists, or raw organizational data.

## Do-no-harm helper text

Use in Lesson 3.6:

> Use general activity descriptions only. Do not enter active case details, names, protection information, complaint details, confidential records, or raw stories.
