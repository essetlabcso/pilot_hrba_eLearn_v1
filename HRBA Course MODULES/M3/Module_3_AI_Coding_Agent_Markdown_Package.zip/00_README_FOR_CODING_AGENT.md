# Module 3 AI Coding Agent Package — README

## Package purpose

This package contains the clean implementation content for **Module 3: HRBA Principles in Practice** in the course **Applying the Human Rights-Based Approach (HRBA) in CSO Practice**.

Use this package as the source of truth for building Module 3 in the CSO Learning Hub course player or related repo implementation.

## Package files

1. `00_README_FOR_CODING_AGENT.md` — build rules, file map, and no-drift instructions.
2. `01_MODULE_3_OVERVIEW.md` — module purpose, outcomes, route, section flow, portfolio and certificate rules.
3. `02_MODULE_3_SCREEN_BY_SCREEN_CONTENT.md` — exact learner-facing content for Module 3 screens/blocks.
4. `03_MODULE_3_BLOCK_STORYBOARD.md` — screen-by-screen storyboard with block type, learner action, completion, data, privacy, accessibility, and assets.
5. `04_MODULE_3_INTERACTION_LOGIC.md` — deterministic behavior and pseudo-logic.
6. `05_MODULE_3_REFLECTION_PORTFOLIO_LOGIC.md` — Module 3 private portfolio/tool logic and carry-forward rules.
7. `06_MODULE_3_ASSESSMENT_AND_FEEDBACK.md` — formative checks, answers, option-level feedback, and tool feedback.
8. `07_MODULE_3_DESIGN_AND_VISUAL_SPEC.md` — visual and interaction design rules.
9. `08_MODULE_3_SAFETY_ACCESSIBILITY_DATA_RULES.md` — safety, privacy, legal boundary, accessibility, low-bandwidth, and data rules.
10. `09_MODULE_3_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md` — approved asset filenames, placeholders, and alt text.
11. `10_MODULE_3_BUILD_ACCEPTANCE_CRITERIA.md` — implementation QA checks.
12. `11_MODULE_3_CODE_AGENT_HANDOFF_PROMPT.md` — copy/paste-ready coding-agent prompt.

## Binding implementation rules

- Build only the learner-facing Module 3 course experience.
- Do not include QA history, evidence packs, source inventories, change logs, approval locks, reviewer notes, or production-process records in the learner-facing platform.
- Do not expose screen IDs, block IDs, source IDs, citations, evidence IDs, or implementation metadata to learners.
- Preserve the approved six-lesson Module 3 sequence:
  1. Participation and Inclusion
  2. Equality and Non-Discrimination
  3. Accountability and Transparency
  4. Empowerment and Capacity Development
  5. Legality and Human Rights Standards
  6. Do-No-Harm and Safe Practice
- Build the 37 approved learner-facing blocks from the production workbook, plus the module header/overview as the course-player shell requires.
- Keep all Module 3 checks formative only.
- Certificate eligibility remains tied only to the final course test with a score of **80% or above**.
- Do not request names, real cases, active complaints, safeguarding/protection details, beneficiary lists, confidential records, legal case details, political details, raw organizational data, or uploads.
- Portfolio/tool outputs are private by default and not visible externally unless a separate approved sharing/consent process is introduced later.
- Do not send raw reflections, worksheet entries, optional notes, or portfolio content to AI services.
- Use “Not quite” instead of “Incorrect.”
- Use “That’s right” or “Good choice” for best responses.
- Do not present the legality lesson as legal advice.
- Use the approved legal-learning disclaimer before standards-use activities.
- Worksheets must have both downloadable/printable and in-platform accessible options.
- All interactions must be keyboard accessible, tap-friendly, screen-reader readable, and usable in low-bandwidth settings.
- Do not invent asset filenames. Use the approved filenames listed in the asset register; if files are missing, render a placeholder component using the approved filename reference.
