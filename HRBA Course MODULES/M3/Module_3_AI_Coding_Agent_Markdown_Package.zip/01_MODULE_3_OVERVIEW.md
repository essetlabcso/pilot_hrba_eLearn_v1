# Module 3 Overview

## Course

**Applying the Human Rights-Based Approach (HRBA) in CSO Practice**

## Module title

**Module 3: HRBA Principles in Practice**

## Module role

Module 3 is a substantive HRBA practice module. It helps local and grassroots CSO participants use HRBA principles as practical decision-making checks in everyday project, service, participation, feedback, standards-use, and safety decisions.

## Recommended duration

**90–110 minutes**

## Target participants

Local and grassroots CSO staff, volunteers, focal persons, project/program staff, MEAL staff, managers, and partner/facilitator users.

## K/S/M/E route

Knowledge + Skill/Judgment component from a mixed capacity gap; course-addressable.

## Primary learner shift

From:

> “HRBA principles are abstract values.”

To:

> “HRBA principles are practical checks that help CSOs improve participation, inclusion, accountability, empowerment, standards use, and safety before decisions are finalized.”

## Module learning outcomes

By the end of Module 3, participants should be able to:

1. apply meaningful participation tests to a general CSO activity;
2. identify barriers that may create exclusion or unequal access;
3. strengthen feedback, answerability, and report-back practices;
4. identify capacity support actions for rights-holders, duty-bearers, and CSOs;
5. use human rights standards carefully without giving or requesting legal advice;
6. identify do-no-harm risks before data collection, storytelling, advocacy, reporting, or participation activities;
7. save practical, private HRBA principle notes or tool outputs where platform functionality supports portfolio saving.

## Approved lesson sequence

1. **3.1 Participation and Inclusion**
2. **3.2 Equality and Non-Discrimination**
3. **3.3 Accountability and Transparency**
4. **3.4 Empowerment and Capacity Development**
5. **3.5 Legality and Human Rights Standards**
6. **3.6 Do-No-Harm and Safe Practice**

## Main practical outputs

- Participation quality checklist
- Inclusion barrier scan
- Feedback loop improvement note
- Capacity support note
- Safe standards-use checklist
- Do-no-harm quick scan
- Optional private “one safer change” reflection

## Assessment rule

All Module 3 checks are formative only. They support practice and review. They do not issue a certificate, unlock a certificate, rank participants, or rank CSOs.

## Certificate rule

Certificate eligibility remains tied to the final course test with a score of **80% or above**.

## Practical proof / portfolio rule

Practical tools may save to the learner’s private portfolio where platform functionality supports it. They are not required for the certificate and are not externally visible by default.

## Safety level

Moderate-to-high. Participation, feedback, inclusion, standards-use, and do-no-harm may invite sensitive information if not constrained.

## Legal-advice boundary

Use this disclaimer before legality/standards activities:

> This activity is for learning and project-quality reflection only. It is not legal advice. Do not use it to diagnose real legal violations, record real cases, or enter names, complaints, confidential records, safeguarding details, political details, or legal allegations. For legal questions, consult qualified, up-to-date legal advice.
