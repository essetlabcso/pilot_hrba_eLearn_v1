# Copy/Paste Prompt for Coding Agent — Module 3

You are implementing **Module 3: HRBA Principles in Practice** for the CSO Learning Hub course **Applying the Human Rights-Based Approach (HRBA) in CSO Practice**.

Use this Markdown package as the controlled source of truth. Do not use the original production workbook directly unless specifically instructed. Build the learner-facing Module 3 course-player experience only.

## Plan first

Before editing code, produce a short implementation plan that identifies:

1. routes/components/files you will update;
2. how you will represent the six Module 3 lessons and 37 approved learner-facing blocks;
3. how you will implement scenarios, tabs, labeled graphics, process blocks, accordion panels, sorting, matching, decision activities, checklist/tools, reflections, and MCQs;
4. how downloadable and in-platform tool alternatives will work;
5. how private portfolio/tool saving will work;
6. how certificate logic will remain untouched;
7. how accessibility and low-bandwidth requirements will be met;
8. any missing assets and how placeholder components will be used.

Do not proceed with code until the plan is clear.

## Source files in this package

Use these files:

- `01_MODULE_3_OVERVIEW.md`
- `02_MODULE_3_SCREEN_BY_SCREEN_CONTENT.md`
- `03_MODULE_3_BLOCK_STORYBOARD.md`
- `04_MODULE_3_INTERACTION_LOGIC.md`
- `05_MODULE_3_REFLECTION_PORTFOLIO_LOGIC.md`
- `06_MODULE_3_ASSESSMENT_AND_FEEDBACK.md`
- `07_MODULE_3_DESIGN_AND_VISUAL_SPEC.md`
- `08_MODULE_3_SAFETY_ACCESSIBILITY_DATA_RULES.md`
- `09_MODULE_3_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`
- `10_MODULE_3_BUILD_ACCEPTANCE_CRITERIA.md`

## Required implementation

Implement Module 3 with:

1. approved title: **HRBA Principles in Practice**;
2. approved six-lesson sequence;
3. 37 approved learner-facing blocks plus module header/overview in the course-player shell;
4. exact learner-facing content from `02_MODULE_3_SCREEN_BY_SCREEN_CONTENT.md`;
5. formative checks and feedback from `06_MODULE_3_ASSESSMENT_AND_FEEDBACK.md`;
6. deterministic logic from `04_MODULE_3_INTERACTION_LOGIC.md`;
7. private portfolio/tool behavior from `05_MODULE_3_REFLECTION_PORTFOLIO_LOGIC.md`;
8. visual design rules from `07_MODULE_3_DESIGN_AND_VISUAL_SPEC.md`;
9. safety/accessibility rules from `08_MODULE_3_SAFETY_ACCESSIBILITY_DATA_RULES.md`;
10. asset references from `09_MODULE_3_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`.

## Hard constraints

Do not:

- expose screen IDs, block IDs, source IDs, evidence IDs, QA notes, or implementation metadata to learners;
- include source inventories, evidence packs, change logs, approval locks, or review history;
- use “Incorrect,” “Wrong,” “Failed,” or pass/fail language;
- imply Module 3 checks affect the certificate;
- issue or unlock certificates from Module 3;
- request names, real cases, active complaints, safeguarding details, beneficiary lists, confidential records, political details, legal allegations, raw organizational data, or uploads;
- send raw reflections, worksheet entries, optional notes, or portfolio/tool content to AI services;
- make worksheets download-only;
- use drag-and-drop-only interactions;
- invent asset filenames;
- present standards-use content as legal advice;
- add public sharing of private portfolio/tool outputs.

Must:

- use “Not quite” for weaker responses;
- use “That’s right” or “Good choice” for best responses;
- keep all Module 3 checks formative;
- state certificate eligibility remains tied to final course test score of 80% or above;
- include the approved legal-learning disclaimer before standards-use activities;
- keep portfolio/tool outputs private by default;
- provide downloadable and in-platform worksheet/tool options;
- ensure keyboard, tap, screen-reader, and low-bandwidth support;
- use DEC/CSO Learning Hub colors and premium card-based course-player design.

## Acceptance criteria

Use `10_MODULE_3_BUILD_ACCEPTANCE_CRITERIA.md` as the final QA checklist. The implementation is not complete until every acceptance check passes.

## Evidence pack required after implementation

After completing the work, provide:

1. summary of implementation;
2. files changed;
3. routes/screens affected;
4. components created or updated;
5. data/schema changes, if any;
6. role/permission changes, if any;
7. certificate logic confirmation;
8. safety/privacy confirmation;
9. accessibility and low-bandwidth confirmation;
10. asset handling summary;
11. tests/checks run and results;
12. known gaps or missing assets;
13. manual verification steps.

## Final verification

Verify at minimum:

- Module 3 route loads;
- all six lessons appear in order;
- all 37 approved blocks are reachable;
- tabs/accordions/process/labeled graphic states are keyboard accessible;
- sorting and matching have non-drag alternatives;
- all checklist/tools have in-platform and download options;
- private tool/portfolio saving uses the existing private portfolio mechanism or safe placeholder state;
- MCQs and decision activities show specified feedback;
- feedback uses “Not quite,” “That’s right,” and “Good choice” as specified;
- no Module 3 activity triggers certificate logic;
- approved legal-learning disclaimer appears before standards-use activities;
- no sensitive fields or uploads are requested;
- missing assets render as placeholders using approved references.
