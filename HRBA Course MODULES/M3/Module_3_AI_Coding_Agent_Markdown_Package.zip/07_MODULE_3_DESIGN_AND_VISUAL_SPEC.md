# Module 3 Design and Visual Interaction Specification

## Module title

**Module 3: HRBA Principles in Practice**

## Design purpose

Module 3 should feel like a practical decision-support learning experience. It should help participants apply HRBA principles to realistic CSO decisions without becoming a dense principles lecture or legal manual.

The module should feel:

- practical;
- grounded in local CSO work;
- respectful and safe;
- action-oriented;
- calm when discussing risk;
- premium and guided.

## Visual identity

| Use | Color |
|---|---|
| Primary action / active progress | `#3B99D4` |
| Positive accent / completion / growth | `#91C852` |
| Deep heading / navigation text | `#0F172A` |
| Main text | `#111827` |
| Secondary text | `#6B7280` |
| Background | `#F9FAFB` |
| Card background | `#FFFFFF` |
| Border | `#E5E7EB` |
| Warning / safety accent | `#F97316` |
| Critical safety warning only | `#EF4444` |

## Global visual system

Use:

- light page background;
- white content cards;
- generous spacing;
- soft shadows;
- rounded corners;
- clear headings;
- short paragraphs;
- DEC blue for progress/actions;
- DEC green for completion and good-practice emphasis;
- orange callouts for safety/legal boundaries;
- no red failure styling for formative feedback.

Avoid:

- legal manual layout;
- long walls of text;
- generic stock imagery;
- identifiable sensitive situations;
- color-only meaning;
- drag-only interactions;
- PDF-only tool completion.

## Course-player layout

Desktop:

- top app bar with course title and module progress;
- left sidebar with six Module 3 lessons;
- centered learning canvas;
- optional right drawer for glossary/resources/private portfolio tracker;
- visible continue/next controls.

Mobile:

- single-column layout;
- navigation collapses to section menu;
- tabs/accordions stack;
- diagrams become text-supported cards;
- large tap targets;
- all tool forms usable on mobile.

## Lesson design rules

| Lesson | Visual / interaction treatment |
|---|---|
| 3.1 Participation and Inclusion | Scenario card, micro-lesson, tabs, decision card, checklist tool, MCQ |
| 3.2 Equality and Non-Discrimination | Statement card, exclusion pathway graphic, case reveal, barrier scan, sorting, MCQ |
| 3.3 Accountability and Transparency | Process loop, micro-lesson, case/multiple response, matching, tool, MCQ |
| 3.4 Empowerment and Capacity Development | Accordion/capacity bridge, case example, sorting, tool, reflection, MCQ |
| 3.5 Legality and Human Rights Standards | Micro-lesson, legal boundary callout, scenario reveal, checklist, MCQ, takeaway |
| 3.6 Do-No-Harm and Safe Practice | Safety statement, decision scenario, quick scan, sorting, private reflection, MCQ, summary |

## Block design patterns

### Scenario card

Use for participation, feedback, standards, and do-no-harm stories.

- short fictional setup;
- clear decision point;
- visible “fictional example” note;
- optional supporting image;
- no real actor names.

### Tabs / accordion

Use for participation tests and capacity categories.

- all tabs/panels keyboard accessible;
- all content available in text fallback;
- completion after all tabs/panels opened or text alternative viewed.

### Labeled graphic / process diagram

Use for exclusion pathway, accountability loop, capacity bridge, and process visuals.

- use source-named SVGs where available;
- provide full text alternative;
- do not embed essential tiny text in images.

### Decision / MCQ card

Use for single-choice formative checks.

- answer options as large selectable cards/radio buttons;
- feedback shown after selection;
- best responses use “That’s right”;
- weaker responses use “Not quite”;
- retry allowed if platform supports it;
- no pass/fail language.

### Sorting / matching

Use for barrier/solution, accountability actions, capacity categories, and safer/riskier practice.

- do not use drag-only behavior;
- provide tap, dropdown, or keyboard-selectable alternative;
- show feedback after each item or after submission;
- allow retry.

### Tool activity / checklist

Use for all practical worksheets.

- show tool purpose;
- show safety/private note;
- provide “Download worksheet” and “Complete in platform” actions;
- support private portfolio save if platform allows;
- essential learning must not depend on PDF download.

### Private reflection panel

Use for avoiding dependency and one safer change.

- clearly optional;
- private-by-default badge;
- safety helper before text field;
- save and skip options;
- no grading.

### Legal disclaimer card

Use in Lesson 3.5 before standards-use activities.

- orange accent line;
- calm protective tone;
- no frightening legal tone;
- must be visibly distinct.

## Interaction states

| State | Design rule |
|---|---|
| Default | White card, readable text, clear CTA |
| Selected | Blue border and selected label |
| Good-practice feedback | Green accent; starts with “That’s right” or “Good choice” |
| Improvement feedback | Soft amber/neutral accent; starts with “Not quite” |
| Saved portfolio/tool | Green accent confirmation; “Saved privately” message |
| Safety/legal boundary | Orange accent; plain-language warning |

## Accessibility requirements

- Keyboard access for all interactions.
- Visible focus states.
- Screen-reader labels for all controls.
- Non-drag alternatives for sorting/matching.
- Text alternatives for all images, SVGs, and diagrams.
- No color-only meaning.
- Mobile-first form layout.
- Reduced-motion friendly.
- Low-bandwidth text pathway.

## Design no-drift rules

The coding agent must not:

- turn Module 3 into a static article;
- remove the six-lesson sequence;
- remove tool activities;
- make worksheets download-only;
- require real examples or uploads;
- use pass/fail language;
- use “Incorrect” feedback;
- imply Module 3 checks affect the certificate;
- invent asset filenames;
- expose screen IDs or evidence IDs to learners;
- use inaccessible drag-only interactions;
- present standards as legal advice;
- add public sharing of private tool/portfolio outputs.

The coding agent must:

- preserve the approved six lessons in order;
- implement the 37 approved blocks;
- keep all checks formative;
- keep portfolio/tool outputs private by default;
- include downloadable and in-platform worksheet options;
- implement text alternatives for all visuals;
- use DEC/CSO Learning Hub visual identity;
- keep the tone practical, locally grounded, safe, and non-legalistic.
