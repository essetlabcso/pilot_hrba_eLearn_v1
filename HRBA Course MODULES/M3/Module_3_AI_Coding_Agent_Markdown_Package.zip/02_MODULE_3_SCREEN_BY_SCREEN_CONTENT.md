# Module 3 Screen-by-Screen Learner-Facing Content

# Module 3: HRBA Principles in Practice

## Module introduction

Welcome to Module 3.

In Module 2, you learned how human rights appear in everyday CSO work. You explored rights dimensions, rights types, and the careful use of human rights standards.

In this module, you will practice using HRBA principles as practical decision-making checks. These principles help your CSO improve how it plans, listens, includes, responds, uses standards, and avoids harm.

You will focus on six principle areas:

1. participation and inclusion;
2. equality and non-discrimination;
3. accountability and transparency;
4. empowerment and capacity development;
5. legality and human rights standards;
6. do-no-harm and safe practice.

This module is not legal training. It is practical learning for safer, more inclusive, and more accountable CSO work.

Your tool outputs and reflections are private by default and do not affect your certificate. Your certificate remains linked to the final course test with a score of 80% or above.

---

# 3.1 Participation and Inclusion

## M03-L01-B01 — A consultation that looked participatory

A CSO is designing a project to improve access to services for people in a low-income area.

The team holds one community meeting. The meeting is attended mostly by older men and a few local leaders. Women, young people, persons with disabilities, and people living far from the meeting place are mostly absent.

The CSO reports that the community was consulted.

But later, several people say the project does not reflect their priorities or barriers.

This lesson asks:

**When does participation become meaningful, and when is it only a checkbox?**

### Safety note

This is a fictional scenario. Do not use real community names, local actor details, or sensitive examples.

### Button

Continue

---

## M03-L01-B02 — Participation is more than attendance

Participation is not only inviting people to a meeting.

In HRBA, participation means that rights-holders can influence decisions that affect them. This includes how problems are defined, which activities are prioritized, how risks are understood, how feedback is handled, and how learning is used.

Participation should be:

- inclusive;
- informed;
- safe;
- meaningful;
- early enough to shape decisions;
- able to influence what changes.

If people are present but cannot influence decisions, participation is weak.

### Key message

Participation is not a photo, signature, or attendance list. It is a way for rights-holders to influence decisions that affect them.

### Button

Continue

---

## M03-L01-B03 — Four tests of meaningful participation

Open each tab to review the four tests of meaningful participation.

### Tab 1 — Inclusive

Are the people most affected represented, including those who face barriers?

Ask:

- who is missing;
- who is usually less heard;
- who may face cost, time, language, disability, safety, or social barriers.

### Tab 2 — Informed

Do people understand the purpose, options, risks, and how their input will be used?

Ask:

- what information people need;
- whether the language is clear;
- whether people understand what can and cannot change.

### Tab 3 — Safe

Can people participate without fear, shame, retaliation, or exposure?

Ask:

- whether some people may fear speaking;
- whether confidentiality is needed;
- whether the setting creates pressure or risk.

### Tab 4 — Influential

Can participant input change decisions, timing, priorities, or methods?

Ask:

- what can still be changed;
- how feedback will affect decisions;
- how the CSO will report back on what changed.

### Completion message

Meaningful participation is inclusive, informed, safe, and influential.

### Button

Continue

---

## M03-L01-B04 — Improve the participation plan

A CSO plans to consult community members only after the project activities have already been approved.

### Question

What would make the process more rights-based?

A. Hold the same meeting but add more photos for reporting.  
B. Invite affected groups earlier, explain choices clearly, ask who is missing, and adjust activities based on feedback.  
C. Ask only local leaders because they know the community.  
D. Cancel participation because it takes time.

Best response: B

Feedback for A: Not quite. Photos can show that an event happened, but they do not make participation meaningful or influential.  
Feedback for B: That’s right. HRBA participation is early, inclusive, informed, safe, and able to influence decisions.  
Feedback for C: Not quite. Local leaders may be important, but relying only on leaders can exclude affected groups and quieter voices.  
Feedback for D: Not quite. Participation takes planning, but cancelling it removes a core HRBA principle.

### Button

Continue

---

## M03-L01-B05 — Participation quality checklist

Use this checklist for one current or future activity. Keep your example general and safe.

Answer **Yes**, **Partly**, or **Not yet**.

### Checklist

1. We know which rights-holders are most affected.
2. We identified who is usually missing from meetings.
3. We chose time and place with accessibility and safety in mind.
4. We explained the purpose of participation clearly.
5. We created a way for quieter groups to speak safely.
6. We can show how participant input influenced decisions.
7. We planned how to report back to participants.

### Fields

- General activity title
- Participation strengths
- Missing groups or voices
- One improvement before implementation
- How we will report back

### Safety helper

Use a general activity description only. Do not enter names, real community details, political details, complaints, safeguarding information, or confidential records.

### Auto-feedback

If several items are **Not yet**, choose one improvement before proceeding with implementation.

### Buttons

Download participation quality checklist  
Complete in platform  
Save privately and continue

---

## M03-L01-B06 — Token or meaningful participation?

This short check is formative and does not affect your certificate.

### Question

Which situation is the strongest example of meaningful participation?

A. A CSO collects signatures after the plan is finalized.  
B. A CSO invites only leaders because they are easier to reach.  
C. A CSO discusses options with affected groups, adapts the plan, and reports back on what changed.  
D. A CSO adds a community photo to the report.

Best response: C

Feedback for A: Not quite. Signatures after a plan is finalized may show awareness or attendance, but they do not show influence.  
Feedback for B: Not quite. Leaders may be useful, but meaningful participation should ask who else is affected and who may be missing.  
Feedback for C: That’s right. Meaningful participation can influence decisions and includes report-back to participants.  
Feedback for D: Not quite. A photo can support documentation, but it is not the same as rights-holders shaping decisions.

### Button

Continue to Lesson 3.2

---

# 3.2 Equality and Non-Discrimination

## M03-L02-B01 — Equality is not treating everyone exactly the same

Equality in HRBA does not always mean giving the same support in the same way to everyone.

People face different barriers.

Some may need:

- information in a different language;
- a physically accessible venue;
- childcare support;
- safer meeting arrangements;
- more time to speak;
- transport consideration;
- different ways to give feedback.

Non-discrimination means identifying and reducing barriers so that people can participate and benefit with dignity.

### Key message

Same treatment can still exclude people when barriers are different.

### Button

Continue

---

## M03-L02-B02 — Where exclusion can happen

Exclusion can happen at many points in a CSO activity, even when nobody intends to exclude.

Open each marker in the pathway.

### Marker 1 — Information

Who hears about the opportunity?

### Marker 2 — Access

Who can physically, digitally, financially, or socially reach it?

### Marker 3 — Voice

Who is comfortable and safe to speak?

### Marker 4 — Decision

Whose input affects choices?

### Marker 5 — Benefit

Who actually benefits?

### Marker 6 — Feedback

Who can complain or suggest change?

### Text alternative

The pathway shows six points where exclusion can occur: information, access, voice, decision, benefit, and feedback. A CSO can reduce exclusion by checking barriers at each point before, during, and after an activity.

### Button

Continue

---

## M03-L02-B03 — A training that excluded people without intending to

A CSO organizes a livelihoods training in a town center from 8:30 a.m. to 4:30 p.m.

The venue has stairs. The invitation is shared through existing cooperative leaders.

The training is useful, but few young mothers attend, no persons with mobility disabilities attend, and some poorer community members say they could not afford transport.

The CSO did not intend to exclude anyone. But the design created barriers.

### Prompt before reveal

What barriers do you notice?

### Reveal feedback

Possible barriers include:

- timing;
- venue accessibility;
- invitation channel;
- transport cost;
- childcare;
- assumptions about who receives information;
- lack of alternative participation options.

### Key message

Inclusion is not only intention. It is also design.

### Button

Continue

---

## M03-L02-B04 — Inclusion barrier scan

Choose one activity your CSO delivers or plans to deliver. You may also use a fictional activity.

Scan for possible barriers using broad categories only.

### Fields

- General activity
- Who is intended to participate or benefit?
- Possible information barriers
- Possible access barriers
- Possible safety or social barriers
- Possible language or literacy barriers
- Possible disability-related barriers
- Possible gender or age-related barriers
- One design change to reduce exclusion

### Safety helper

Use broad group categories only. Avoid naming individuals or collecting sensitive identity details.

### Auto-feedback

Focus first on barriers that could prevent people from participating safely or benefiting fairly.

### Buttons

Download inclusion barrier scan  
Complete in platform  
Save privately and continue

---

## M03-L02-B05 — Barrier or solution?

Sort each item as either a **possible barrier** or an **inclusion solution**.

### Items

1. Venue has stairs only.  
   Best category: Barrier  
   Feedback: Good choice. Physical access can prevent participation or benefit.

2. Invitation shared only through leaders.  
   Best category: Barrier  
   Feedback: Good choice. Some people may never receive information if the invitation channel is narrow.

3. Meeting time adjusted after women participants give feedback.  
   Best category: Solution  
   Feedback: Good choice. Adjusting the time can reduce a participation barrier.

4. Simple language and local language explanation.  
   Best category: Solution  
   Feedback: Good choice. Clear and understandable information supports fair participation.

5. No transport consideration for remote participants.  
   Best category: Barrier  
   Feedback: Good choice. Cost or distance can exclude people even when activities are open.

6. Anonymous feedback option.  
   Best category: Solution  
   Feedback: Good choice. Anonymous feedback can help people raise concerns more safely where appropriate.

### Weaker-response feedback

Not quite. Think about whether the item makes participation or benefit harder, or whether it reduces a barrier.

### Completion message

Inclusion improves when CSOs notice practical barriers and redesign participation, information, access, and feedback.

### Button

Continue

---

## M03-L02-B06 — Non-discrimination in practice

This short check is formative and does not affect your certificate.

### Question

What is the best HRBA interpretation of non-discrimination?

A. Treat everyone exactly the same in every activity.  
B. Identify barriers that different groups face and adjust practice so participation and benefit are fairer.  
C. Invite only the easiest participants to reach.  
D. Avoid collecting any feedback about exclusion.

Best response: B

Feedback for A: Not quite. Same treatment can still exclude people when barriers differ.  
Feedback for B: That’s right. HRBA requires attention to different barriers and fair access.  
Feedback for C: Not quite. Convenience should not decide who is included.  
Feedback for D: Not quite. Safe feedback can help a CSO identify exclusion and improve practice.

### Button

Continue to Lesson 3.3

---

# 3.3 Accountability and Transparency

## M03-L03-B01 — The accountability loop

Accountability is more than collecting feedback. It is a loop.

Open each step.

### Step 1 — Inform

Explain plans, criteria, roles, and limits.

### Step 2 — Listen

Receive feedback, questions, and complaints safely.

### Step 3 — Respond

Acknowledge and analyze what was raised.

### Step 4 — Act

Make changes or explain why change is not possible.

### Step 5 — Report back

Tell people what happened because of their input.

### Key message

Accountability is not complete until people can see that feedback was received, considered, and acted on or explained.

### Button

Continue

---

## M03-L03-B02 — Transparency builds trust

Transparency means people can understand:

- what a CSO is doing;
- why decisions are made;
- who is eligible;
- what support is available;
- what limits exist;
- how to ask questions or raise concerns.

Transparency does not mean sharing everything.

Confidential information, personal data, and sensitive protection issues must remain protected.

Good transparency is clear, useful, and safe.

### Button

Continue

---

## M03-L03-B03 — A feedback box is not enough

A CSO places a feedback box at the project office.

Few community members use it. Some live far away. Some cannot write comfortably. Some do not trust that complaints will be confidential.

The CSO says it has a feedback mechanism, but it rarely receives useful feedback.

### Question

What is weak in this feedback system? Select all that apply.

- Access
- Trust
- Literacy
- Confidentiality
- Response
- Reporting back

Expected response: All are relevant.

Feedback if several relevant options selected: That’s right. A feedback mechanism is only useful if people can access it, trust it, understand it, and see that the CSO responds.

Feedback if only one option selected: Not quite. One issue may be visible first, but this example has several weaknesses: access, trust, literacy, confidentiality, response, and reporting back.

### Safety note

This is fictional. Do not enter real complaints, complainant names, or active cases.

### Button

Continue

---

## M03-L03-B04 — Match the accountability action

Match each accountability problem with a stronger practice.

### Pair 1

Problem: People do not know selection criteria.  
Stronger practice: Share simple eligibility information.

### Pair 2

Problem: Feedback is collected but not reviewed.  
Stronger practice: Assign responsibility and review schedule.

### Pair 3

Problem: Complaints may expose people.  
Stronger practice: Provide confidential channel and protection guidance.

### Pair 4

Problem: Communities do not know what changed.  
Stronger practice: Report back in accessible way.

### Pair 5

Problem: Staff fear blame.  
Stronger practice: Use learning-focused internal review.

### Feedback

Good choice. Strong accountability needs information, safe channels, responsibility, action, and reporting back.

### Weaker-response feedback

Not quite. Look for the practice that directly fixes the accountability weakness.

### Button

Continue

---

## M03-L03-B05 — Feedback loop improvement note

Choose one feedback or accountability process in your CSO. You may also use a fictional example.

Identify one improvement.

### Fields

- Current feedback channel
- Who can access it?
- Who may be excluded?
- How feedback is reviewed
- How responses are communicated
- One improvement to strengthen safety or usefulness

### Safety helper

Do not include real complaints, complainant names, active cases, confidential information, or safeguarding details.

### Auto-feedback

Prioritize improvements that increase trust, accessibility, confidentiality, and response.

### Buttons

Download feedback loop improvement note  
Complete in platform  
Save privately and continue

---

## M03-L03-B06 — Closing the loop

This short check is formative and does not affect your certificate.

### Question

Which action best shows accountability?

A. Collecting feedback and storing it without review.  
B. Sharing photos of community meetings.  
C. Listening to feedback, making a decision, acting where possible, and reporting back.  
D. Avoiding feedback because it may create complaints.

Best response: C

Feedback for A: Not quite. Feedback that is stored but not reviewed does not close the accountability loop.  
Feedback for B: Not quite. Visibility is not the same as accountability.  
Feedback for C: That’s right. Accountability requires response and reporting back, not only collection.  
Feedback for D: Not quite. Feedback may need careful handling, but avoiding it removes an important accountability pathway.

### Button

Continue to Lesson 3.4

---

# 3.4 Empowerment and Capacity Development

## M03-L04-B01 — Empowerment is not speaking for people forever

Empowerment means increasing people’s ability, confidence, information, tools, and opportunity to participate and claim rights.

It also means strengthening the capacity of duty-bearers to respond to responsibilities.

Open each panel.

### Panel 1 — Rights-holder capacity

Awareness, confidence, organization, information, voice, and safe channels.

### Panel 2 — Duty-bearer capacity

Knowledge, systems, resources, responsiveness, coordination, and accountability.

### Panel 3 — CSO capacity

Facilitation, evidence, inclusion, safeguarding, advocacy, and learning.

### Panel 4 — Power-aware support

Avoid creating dependency or speaking over affected people.

### Key message

Empowerment is not only giving information. It is strengthening agency, voice, confidence, and responsiveness.

### Button

Continue

---

## M03-L04-B02 — From delivering awareness to strengthening agency

A CSO organizes awareness sessions on disability inclusion.

A basic activity might only deliver information.

A stronger HRBA activity could also support persons with disabilities and their representative groups to:

- identify barriers;
- speak with service providers;
- request reasonable adjustments;
- monitor whether changes happen.

The goal is not only knowledge transfer. The goal is increased agency and responsiveness.

### Safety note

Use respectful, non-stereotyping language. Do not describe people or groups as passive or helpless.

### Button

Continue

---

## M03-L04-B03 — What capacity is being strengthened?

Sort each action into the main capacity it strengthens: **rights-holder capacity**, **duty-bearer capacity**, or **CSO capacity**.

### Items

1. Training community facilitators to explain feedback channels.  
   Best category: CSO capacity

2. Supporting women participants to prepare questions for a public service meeting.  
   Best category: Rights-holder capacity

3. Helping a local office improve response tracking.  
   Best category: Duty-bearer capacity

4. Creating accessible information materials.  
   Best category: CSO capacity

5. Supporting youth groups to analyze barriers and propose solutions.  
   Best category: Rights-holder capacity

6. Helping a service provider understand inclusion obligations.  
   Best category: Duty-bearer capacity

### Feedback

Good choice. HRBA often strengthens several capacities together. The key is to be clear whose capacity is being strengthened and why.

### Weaker-response feedback

Not quite. Ask whether the action mainly strengthens the people claiming rights, the actor responsible to respond, or the CSO supporting the process.

### Button

Continue

---

## M03-L04-B04 — Capacity support note

Choose one issue from your CSO’s work or use a fictional example.

Identify capacity gaps and support actions.

### Fields

- General issue
- Rights-holder capacity that needs strengthening
- Duty-bearer capacity that needs strengthening
- CSO capacity needed
- One practical support action
- One risk to avoid

### Safety helper

Use general issue descriptions. Do not include names, active cases, sensitive group details, political details, or confidential records.

### Auto-feedback

Strong HRBA action often supports both rights-holder agency and duty-bearer responsiveness.

### Buttons

Download capacity support note  
Complete in platform  
Save privately and continue

---

## M03-L04-B05 — Avoiding dependency

### Private reflection

How can your CSO support communities without making them dependent on the CSO to speak or act on their behalf every time?

### Optional private note

Write a short, broad note.

### Safety helper

Avoid naming individuals or sensitive groups. Keep your note general and private.

### Save message

Your reflection has been saved privately.

### Button

Save or continue

---

## M03-L04-B06 — Empowerment in HRBA

This short check is formative and does not affect your certificate.

### Question

Which activity best reflects empowerment?

A. CSO staff make all decisions because they have technical knowledge.  
B. The CSO supports rights-holders with information, confidence, safe channels, and opportunities to influence decisions.  
C. The CSO avoids duty-bearers completely.  
D. The CSO only distributes materials and closes the project.

Best response: B

Feedback for A: Not quite. Technical knowledge matters, but empowerment should not remove rights-holder voice and influence.  
Feedback for B: That’s right. Empowerment strengthens agency, participation, and capacity.  
Feedback for C: Not quite. HRBA often requires constructive engagement with responsible actors where safe and appropriate.  
Feedback for D: Not quite. Distribution alone may be useful, but empowerment also builds capacity, voice, and influence.

### Button

Continue to Lesson 3.5

---

# 3.5 Legality and Human Rights Standards

## M03-L05-B01 — Legality means grounding action in standards

The legality principle means HRBA is guided by human rights standards, laws, policies, and obligations.

For local CSOs, this does not mean every staff member must become a lawyer.

It means CSOs should understand relevant standards enough to:

- avoid vague claims;
- design responsibly;
- refer people to appropriate support where needed;
- know when updated legal advice is required;
- connect community realities to responsibilities and practical change.

### Button

Continue

---

## M03-L05-B02 — Important boundary

### Legal-learning disclaimer

This activity is for learning and project-quality reflection only. It is not legal advice.

Do not use it to diagnose real legal violations, record real cases, or enter names, complaints, confidential records, safeguarding details, political details, or legal allegations.

For legal questions, consult qualified, up-to-date legal advice.

### Button

I understand — continue

---

## M03-L05-B03 — Using standards carefully

A project officer is preparing a concept note about inclusive education.

They want to say:

> “The local office is violating rights.”

The team has community feedback and access barriers, but has not reviewed relevant standards, institutional responsibilities, or evidence quality.

A safer and stronger HRBA approach would:

- describe the barriers;
- identify relevant rights and responsibilities;
- show evidence carefully;
- recommend constructive actions;
- avoid unsupported accusations.

### Reveal — weak claim

“The local office is violating rights.”

Why this is weak: it may be unsupported, unsafe, too broad, or legally risky if evidence and responsibilities are not clear.

### Reveal — stronger evidence-based statement

“Community feedback suggests that some learners face barriers to accessing inclusive education. The project will review relevant standards, identify responsible actors, document barriers safely, and propose practical adjustments.”

### Feedback

HRBA uses standards carefully, avoids unsupported accusations, and links evidence to responsibilities and practical change.

### Button

Continue

---

## M03-L05-B04 — Safe standards-use checklist

Before using legal or human rights standards in CSO work, check:

1. Do we understand the relevant standard well enough?
2. Are we using current and reliable information?
3. Are we clear about who has responsibility?
4. Do we have safe and sufficient evidence?
5. Have we avoided naming people or actors unnecessarily?
6. Have we considered risks?
7. Do we need legal or technical advice before acting?

### Response options

For each item, choose:

- Yes
- Partly
- Not yet

### Safety helper

This checklist is for learning and project-quality reflection only. Do not enter real legal cases, allegations, complaints, safeguarding details, confidential records, political details, or names.

### Auto-feedback

If several items are **Not yet**, pause and seek support before making strong public claims.

### Buttons

Download safe standards-use checklist  
Complete in platform  
Save privately and continue

---

## M03-L05-B05 — What legality means for CSOs

This short check is formative and does not affect your certificate.

### Question

What is the best practical meaning of the legality principle in this course?

A. Only lawyers can use HRBA.  
B. CSOs should ground their work in relevant rights, laws, policies, and standards, while knowing when to seek expert advice.  
C. CSOs should make strong legal accusations whenever they see a problem.  
D. HRBA does not need standards.

Best response: B

Feedback for A: Not quite. CSO staff can use HRBA standards as learning and design guidance without becoming lawyers.  
Feedback for B: That’s right. Legality helps ground action responsibly while recognizing when expert advice is needed.  
Feedback for C: Not quite. HRBA uses standards carefully; it is not a license for unsupported accusations.  
Feedback for D: Not quite. HRBA is grounded in rights and standards, but those standards must be used responsibly.

### Button

Continue

---

## M03-L05-B06 — Use standards responsibly

HRBA becomes stronger when CSOs connect community realities to relevant standards and responsibilities.

But responsible use requires care.

Use:

- reliable information;
- clear responsibility analysis;
- safe and sufficient evidence;
- careful language;
- updated advice when needed;
- constructive recommendations.

Avoid:

- unsupported claims;
- unnecessary names;
- legal allegations without advice;
- confidential or sensitive details;
- public statements that could create avoidable risk.

### Key takeaway

Use standards to strengthen project quality and accountability, not to create unsafe or unsupported claims.

### Button

Continue to Lesson 3.6

---

# 3.6 Do-No-Harm and Safe Practice

## M03-L06-B01 — Do-no-harm is an HRBA discipline

Do-no-harm means taking a step back before acting and asking whether our project, data collection, advocacy, communication, or partnership could expose people to additional risk.

In HRBA, good intentions do not remove risk.

CSOs need to identify possible harm and choose safer ways to work.

### Possible risks

- privacy exposure;
- backlash or retaliation;
- stigma;
- participation fatigue;
- misinformation;
- unsafe storytelling;
- over-collection of personal data;
- exclusion of quieter or less powerful groups.

### Button

Continue

---

## M03-L06-B02 — A risky community story

A CSO wants to publish a powerful story about a young woman who experienced discrimination while seeking a public service.

The story includes her name, photo, location, and details that could identify her family.

The team believes the story will help advocacy.

### Question

What should the CSO do?

A. Publish quickly because the story is powerful.  
B. Ask for consent once and publish all details.  
C. Assess risks, discuss consent clearly, remove identifying details where needed, and consider a composite or anonymized story.  
D. Avoid all storytelling forever.

Best response: C

Feedback for A: Not quite. A powerful story can still expose someone to harm.  
Feedback for B: Not quite. Consent should be meaningful and risk-aware; publishing all identifying details may still be unsafe.  
Feedback for C: That’s right. Safe storytelling balances voice, dignity, consent, and risk.  
Feedback for D: Not quite. Avoiding all stories is unnecessary when safer, consent-based, anonymized, or composite approaches are possible.

### Button

Continue

---

## M03-L06-B03 — Do-no-harm quick scan

Before an activity, ask:

1. Who could be put at risk by this action?
2. What information could identify someone?
3. Could participation create backlash, stigma, or retaliation?
4. Are we asking for more data than we need?
5. Have we explained purpose and consent clearly?
6. Is there a safer alternative?
7. What will we do if harm or distress appears?

### Response options

For each item, choose:

- No concern identified
- Needs attention
- Not sure

### Safety helper

Use general activity descriptions only. Do not enter active case details, names, protection information, complaint details, confidential records, or raw stories.

### Auto-feedback

If any item raises concern, pause, adapt, and seek support before proceeding.

### Buttons

Download do-no-harm quick scan  
Complete in platform  
Save privately and continue

---

## M03-L06-B04 — Safer or riskier practice?

Sort each practice as **safer** or **riskier**.

### Items

1. Asking for full names in a sensitive feedback form.  
   Best category: Riskier

2. Using anonymized categories when names are not needed.  
   Best category: Safer

3. Posting identifiable photos without clear consent.  
   Best category: Riskier

4. Explaining how feedback will be used.  
   Best category: Safer

5. Sharing raw complaint data in a public report.  
   Best category: Riskier

6. Using a fictionalized case for learning.  
   Best category: Safer

### Feedback

Good choice. Do-no-harm often means reducing unnecessary exposure while preserving learning and accountability.

### Weaker-response feedback

Not quite. Ask whether the practice increases exposure or reduces risk.

### Button

Continue

---

## M03-L06-B05 — One safer change

Think of one activity your CSO does: training, consultation, feedback, data collection, advocacy, storytelling, or reporting.

### Question

What is one safer change you could make?

### Optional private note

Write one short, general idea.

### Safety helper

Keep this general. Do not include real cases, names, active complaints, safeguarding details, political details, confidential records, or raw stories.

### Save message

Your safer-change reflection has been saved privately.

### Button

Save or continue

---

## M03-L06-B06 — Best do-no-harm action

This short check is formative and does not affect your certificate.

### Question

A CSO wants to collect detailed personal stories from vulnerable community members. What should the team do first?

A. Collect as much detail as possible because donors like stories.  
B. Ask whether the information is necessary, assess risks, explain consent, and choose anonymized or less sensitive options where possible.  
C. Collect names so follow-up is easier.  
D. Avoid all community feedback permanently.

Best response: B

Feedback for A: Not quite. More data is not always safer or better.  
Feedback for B: That’s right. Do-no-harm requires necessity, risk assessment, consent, and safer alternatives.  
Feedback for C: Not quite. Names should only be collected when necessary, safe, proportionate, and clearly explained.  
Feedback for D: Not quite. Avoidance is not the only safe option. CSOs can still listen while using safer methods.

### Button

Continue

---

## M03-L06-B07 — Module 3 summary

You have completed Module 3.

In this module, you practiced using HRBA principles as practical decision tools.

You explored:

- meaningful participation;
- inclusion and non-discrimination;
- accountability and transparency;
- empowerment and capacity development;
- legality and human rights standards;
- do-no-harm and safe practice.

These principles will guide the next modules, where you will analyze rights-holders, duty-bearers, power, exclusion, project design, implementation, MEAL, and advocacy.

### Key takeaway

HRBA principles are not abstract labels. They are practical checks that help CSOs make safer, more inclusive, and more accountable decisions.

### Certificate reminder

Module 3 checks are formative. Your certificate is linked to the final course test with a score of 80% or above.

### Button

Continue to Module 4
