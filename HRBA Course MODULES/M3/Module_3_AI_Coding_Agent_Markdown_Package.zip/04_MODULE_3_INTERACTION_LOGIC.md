# Module 3 Interaction Logic

## Global rules

```text
Module 3 checks are formative only.
Certificate eligibility is not calculated in Module 3.
Certificate eligibility remains linked to the final course test with score >= 80%.

Do not expose to learners:
  screen IDs
  block IDs
  source IDs
  evidence IDs
  QA notes
  reviewer notes
  approval metadata
  implementation metadata

Do not request:
  real names
  real community names
  real cases
  active complaints
  safeguarding/protection details
  beneficiary lists
  confidential records
  political/civic-space-sensitive details
  legal allegations
  raw organizational data
  uploads
```

## Module completion logic

```text
Module 3 is complete when:
  all six lessons are visited in order
  all required reveal/tabs/accordion/process/hotspot steps are viewed
  all required decision/check/sorting/matching interactions are completed
  all required feedback has been viewed
  M03-L06-B07 summary is viewed

Tool and reflection outputs:
  may be saved to private portfolio if platform supports it
  should not affect certificate eligibility
  should not be externally visible by default
```

## 3.1 Participation and Inclusion

```text
M03-L01-B03 Four tests tabs:
  tabs = Inclusive, Informed, Safe, Influential
  completion = all tabs opened OR accessible text list viewed

M03-L01-B04 Improve participation plan:
  best_response = B
  if B: show "That’s right..."
  else: show "Not quite..."
  mark completed after feedback viewed

M03-L01-B05 Participation quality checklist:
  response_options = Yes, Partly, Not yet
  fields:
    general_activity_title
    participation_strengths
    missing_groups_or_voices
    one_improvement
    report_back_plan
  save only to private portfolio if learner chooses save
  show auto-feedback if several "Not yet"
  no sensitive inputs required

M03-L01-B06 Token or meaningful participation:
  best_response = C
  show option-level feedback
  no certificate effect
```

## 3.2 Equality and Non-Discrimination

```text
M03-L02-B02 Exclusion pathway:
  markers = Information, Access, Voice, Decision, Benefit, Feedback
  completion = all markers opened OR full text alternative viewed

M03-L02-B03 Training case:
  show case
  ask "What barriers do you notice?"
  reveal analysis when learner clicks reveal
  completion = reveal viewed

M03-L02-B04 Inclusion barrier scan:
  fields:
    activity
    intended_participants_or_beneficiaries
    information_barriers
    access_barriers
    safety_or_social_barriers
    language_or_literacy_barriers
    disability_barriers
    gender_or_age_barriers
    one_design_change
  save only to private portfolio if learner chooses save
  use broad categories only

M03-L02-B05 Barrier or solution:
  correct_map:
    venue_has_stairs_only = Barrier
    invitation_shared_only_through_leaders = Barrier
    meeting_time_adjusted_after_feedback = Solution
    simple_language_and_local_language = Solution
    no_transport_consideration = Barrier
    anonymous_feedback_option = Solution
  allow retry
  non-drag alternative required

M03-L02-B06 Non-discrimination in practice:
  best_response = B
  show option-level feedback
```

## 3.3 Accountability and Transparency

```text
M03-L03-B01 Accountability loop:
  steps = Inform, Listen, Respond, Act, Report back
  completion = all steps opened OR text alternative viewed

M03-L03-B03 Feedback box case:
  expected_selections = Access, Trust, Literacy, Confidentiality, Response, Reporting back
  accept partial but teach that all are relevant
  no real complaint data requested

M03-L03-B04 Matching:
  pairs:
    selection_criteria_unknown -> share_simple_eligibility_information
    feedback_collected_not_reviewed -> assign_responsibility_and_review_schedule
    complaints_may_expose_people -> provide_confidential_channel_and_protection_guidance
    communities_do_not_know_what_changed -> report_back_in_accessible_way
    staff_fear_blame -> use_learning_focused_internal_review
  allow retry
  non-drag alternative required

M03-L03-B05 Feedback loop improvement note:
  fields:
    current_feedback_channel
    who_can_access
    who_may_be_excluded
    how_feedback_is_reviewed
    how_responses_are_communicated
    one_improvement
  save privately only if learner chooses
  never request real complaints or names

M03-L03-B06 Closing the loop:
  best_response = C
  show option-level feedback
```

## 3.4 Empowerment and Capacity Development

```text
M03-L04-B01 Accordion:
  panels = Rights-holder capacity, Duty-bearer capacity, CSO capacity, Power-aware support
  completion = all panels opened OR accessible text list viewed

M03-L04-B03 Capacity sorting:
  correct_map:
    training_community_facilitators = CSO capacity
    women_prepare_questions = Rights-holder capacity
    local_office_response_tracking = Duty-bearer capacity
    accessible_information_materials = CSO capacity
    youth_analyze_barriers = Rights-holder capacity
    service_provider_inclusion_obligations = Duty-bearer capacity
  allow retry
  non-drag alternative required

M03-L04-B04 Capacity support note:
  fields:
    general_issue
    rights_holder_capacity
    duty_bearer_capacity
    cso_capacity
    practical_support_action
    risk_to_avoid
  save privately only if learner chooses
  use general issue descriptions

M03-L04-B05 Avoiding dependency:
  optional_private_note = allowed
  safety helper required
  allow skip

M03-L04-B06 Empowerment in HRBA:
  best_response = B
  show option-level feedback
```

## 3.5 Legality and Human Rights Standards

```text
M03-L05-B02 Disclaimer:
  display approved legal-learning disclaimer
  require acknowledgement or continue before standards activity

M03-L05-B03 Standards scenario:
  show weak claim
  reveal stronger evidence-based statement
  completion = reveal viewed

M03-L05-B04 Safe standards-use checklist:
  response_options = Yes, Partly, Not yet
  checklist_items = understand_standard, reliable_information, responsibility_clear, safe_evidence, avoid_unnecessary_names, risks_considered, advice_needed
  save privately only if learner chooses
  show auto-feedback if several "Not yet"
  never request real cases, allegations, or legal claims

M03-L05-B05 Legality principle:
  best_response = B
  show option-level feedback
```

## 3.6 Do-No-Harm and Safe Practice

```text
M03-L06-B02 Risky community story:
  best_response = C
  show option-level feedback
  do not use real stories or identities

M03-L06-B03 Do-no-harm quick scan:
  response_options = No concern identified, Needs attention, Not sure
  items = risk, identifiable_information, backlash_or_stigma, data_necessity, consent, safer_alternative, response_plan
  save privately only if learner chooses
  show auto-feedback if any item = Needs attention or Not sure

M03-L06-B04 Safer or riskier practice:
  correct_map:
    asking_full_names_sensitive_feedback = Riskier
    anonymized_categories_when_names_not_needed = Safer
    identifiable_photos_without_consent = Riskier
    explaining_feedback_use = Safer
    sharing_raw_complaint_data_publicly = Riskier
    fictionalized_case_for_learning = Safer
  allow retry
  non-drag alternative required

M03-L06-B05 One safer change:
  optional_private_note = allowed
  safety helper required
  allow skip

M03-L06-B06 Best do-no-harm action:
  best_response = B
  show option-level feedback
```

## Feedback logic

```text
For all MCQs / decisions:
  IF selected == best_response:
    feedback starts with "That’s right."
  ELSE:
    feedback starts with "Not quite."

For sorting/matching:
  IF selected == correct category/pair:
    feedback starts with "Good choice."
  ELSE:
    feedback starts with "Not quite."

Do not use:
  Incorrect
  Wrong
  Failed
  Pass/fail
  This affects your certificate
```
