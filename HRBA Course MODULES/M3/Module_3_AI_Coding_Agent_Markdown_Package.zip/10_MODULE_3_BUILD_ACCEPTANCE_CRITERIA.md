# Module 3 Build Acceptance Criteria

## Content structure

| Check | Pass condition |
|---|---|
| Clean content only | Learner-facing build excludes QA history, source inventories, evidence packs, change logs, approval locks, and internal reviewer notes. |
| Approved title | Module title is “HRBA Principles in Practice.” |
| Approved lessons | Six approved lessons appear in order: 3.1–3.6. |
| Approved blocks | The 37 approved learner-facing blocks are represented. |
| Practical principle framing | HRBA principles are presented as practical decision checks, not abstract labels only. |
| Module 2 bridge | Introduction links Module 2 rights recognition to Module 3 principle application. |
| No legal-training drift | Module is practical HRBA learning, not legal training. |

## Assessment and feedback

| Check | Pass condition |
|---|---|
| No early substantive quiz | Module begins with practical orientation and Lesson 3.1 scenario, not a quiz. |
| Checks after teaching | MCQs, decisions, sorting, matching, and tool activities appear after related content. |
| Feedback wording | Weaker responses use “Not quite,” not “Incorrect.” |
| Encouraging correct feedback | Best responses use “That’s right” or “Good choice.” |
| Formative-only rule | No Module 3 check affects certificate eligibility. |
| Certificate rule | Learner copy states certificate is linked to final course test score of 80% or above. |
| Retry allowed | Formative checks allow retry where platform supports it. |

## Portfolio and tools

| Check | Pass condition |
|---|---|
| Participation tool | Participation quality checklist is implemented with downloadable and in-platform options. |
| Inclusion tool | Inclusion barrier scan is implemented with downloadable and in-platform options. |
| Accountability tool | Feedback loop improvement note is implemented with downloadable and in-platform options. |
| Capacity tool | Capacity support note is implemented with downloadable and in-platform options. |
| Standards tool | Safe standards-use checklist is implemented with downloadable and in-platform options. |
| Safety tool | Do-no-harm quick scan is implemented with downloadable and in-platform options. |
| Private by default | Tool outputs and optional notes are private by default. |
| No certificate effect | Tools and portfolio outputs do not affect certificate eligibility. |
| No uploads | Learners are not required to upload files. |

## Safety and data

| Check | Pass condition |
|---|---|
| No sensitive data requests | No screen asks for names, real cases, active complaints, safeguarding details, confidential records, political details, beneficiary lists, raw data, or uploads. |
| Fictional scenarios | Scenario examples are clearly fictional/generic and do not require real disclosure. |
| Legal disclaimer | Approved legal-learning disclaimer appears before standards-use activity. |
| No legal advice | Lesson 3.5 does not diagnose violations, give legal advice, or invite legal allegations. |
| Data minimization | Only necessary structured learning data is saved. |
| No raw reflections to AI | Raw notes, worksheet entries, and portfolio content are not sent to AI services. |
| No public ranking | No activity ranks participants or CSOs. |

## Accessibility and low bandwidth

| Check | Pass condition |
|---|---|
| Keyboard access | All interactions are keyboard accessible. |
| Tap-friendly | All interactions work on mobile. |
| Non-drag alternative | Sorting and matching have tap/dropdown/button alternatives. |
| Screen-reader support | Forms, controls, buttons, feedback, cards, tabs, accordions, and checklists have readable labels. |
| Text alternatives | Diagrams, process graphics, SVGs, and visuals have text alternatives. |
| No color-only meaning | Feedback, warning, status, and selected states use text labels. |
| Mobile layout | Cards, tabs, accordions, timelines/processes, forms, and checks stack cleanly. |
| Low bandwidth | Required learning does not depend on video, heavy media, PDFs, or external embeds. |

## Asset control

| Check | Pass condition |
|---|---|
| No invented filenames | Approved asset filenames are preserved; missing assets remain placeholders. |
| Alt text included | Every asset placeholder includes alt text. |
| Local grounding | Visual direction supports Ethiopian/East African local CSO practice. |
| Brand consistency | DEC/CSO Learning Hub color system is applied where relevant. |

## Final implementation acceptance

Module 3 is accepted when:

1. all six lessons and approved blocks are implemented in order;
2. all required interactions work;
3. feedback appears as specified;
4. all tool outputs and optional notes remain private by default;
5. no sensitive data is requested;
6. certificate logic is not triggered by Module 3;
7. legality content is not presented as legal advice;
8. all accessibility and low-bandwidth requirements are met;
9. asset placeholders are not replaced with invented filenames;
10. learner-facing screens do not show internal metadata.
