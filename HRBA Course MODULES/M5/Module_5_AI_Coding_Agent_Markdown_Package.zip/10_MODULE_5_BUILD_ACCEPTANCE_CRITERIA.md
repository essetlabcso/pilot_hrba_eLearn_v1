# Module 5 Build Acceptance Criteria

## Source acceptance criteria

| Criteria area | Acceptance criterion | Verification method | Pass condition | Status |
| --- | --- | --- | --- | --- |
| Module structure | Module includes the approved six lessons in correct order plus intro and summary. | Inspect course player navigation and workbook mapping. | All lessons present and ordered correctly. | Pass |
| Content quality | Learner-facing text is clear, practical, locally grounded, and not a long manual page. | Review 09_FINAL_CONTENT and implemented screens. | No internal notes, source IDs, reviewer comments or dense manual-like pages. | Pass |
| HRBA accuracy | Situation, problem, objective, activity and risk design align with HRBA, rights-holder/duty-bearer capacity, participation, inclusion, accountability and do-no-harm. | Compare against evidence extraction and source-use plan. | No generic proposal-writing drift. | Pass |
| Ethiopia-local relevance | Examples feel credible for local CSO practice without unsafe political/legal detail. | Review scenarios and visuals. | Fictional/generalized local CSO examples only. | Pass |
| Project-design quality | Module teaches analysis-led project design, not activity-first or donor-template compliance. | Review action map, storyboards and tools. | Every lesson produces a project-design judgment or tool output. | Pass |
| Objective quality | Objective rewrite lab distinguishes activities from desired rights-based change. | Test interaction and feedback. | Correct feedback reinforces change-oriented objective logic. | Pass |
| Risk mitigation quality | Risk lesson covers exclusion, token participation, unsafe data, safeguarding, backlash, expectations and civic-space risk with practical mitigation. | Review L5.6 and risk matrix. | Risk examples are safe and non-sensational. | Pass |
| Legal-advice boundary | Legal/policy lesson includes disclaimer and does not ask for legal violation diagnosis or legal documents. | Review L5.2 before learner input. | Disclaimer visible; no legal-advice output. | Pass |
| Interaction quality | Interactions are purposeful and varied, not decorative. | Review 13_INTERACTION_LOGIC and implementation. | Scenario, process, accordion, checklist, sorting/matching, tabs, rewrite, risk matrix, tools and checks work. | Pass |
| Assessment/certificate | Knowledge checks are formative; certificate is final test only at 80%+. | Review assessment map and implementation logic. | No Module 5 check/tool triggers certificate; certificate depends only on the final course test score of 80% or above. | Pass |
| Proof/portfolio separation | Private tools/portfolio are not practical proof or certificate requirements. | Review reflection/portfolio behavior. | Private by default; no external visibility. | Pass |
| Safety/privacy | No prompt requests names, real cases, legal documents, proposals, confidential records, survivor stories or sensitive actors. | Review all learner input fields. | All input fields have safe-entry guidance. | Pass |
| Asset readiness | Assets use approved filenames, prompts, alt text and low-bandwidth alternatives; approved text-first fallbacks are available when physical files are not present. | Review asset sheets. | No invented filenames; missing assets do not block learning. | Pass |
| Accessibility | Visuals, tools, interactions and assessments meet keyboard, screen-reader, mobile and low-bandwidth rules. | Manual/accessibility QA. | Pass conditions in 22_ACCESSIBILITY_QA met. | Pass |
| Final cleanup | Workbook has filters, frozen headers, wrapped text, readable widths, consistent statuses and no formula errors. | Workbook inspection and formula error scan. | Ready for implementation review/build preparation. | Pass |

## Additional clean-package acceptance checks

| Check | Pass condition |
|---|---|
| Clean content only | Learner-facing build excludes QA history, source inventories, evidence packs, change logs, approval locks, and internal reviewer notes. |
| Approved title | Module title is “Applying HRBA in Project Design.” |
| Approved sequence | Six lessons appear in approved order, with module intro and summary. |
| Correct screen count | 37 learner-facing screens/blocks are represented. |
| Feedback wording | Weaker responses use “Not quite,” not “Incorrect.” |
| Certificate integrity | No Module 5 check, tool, worksheet, lab, or reflection affects certificate eligibility. |
| 80% rule | Learner copy states certificate is linked to final course test score of 80% or above. |
| Portfolio privacy | Tool outputs, project-design drafts, and optional notes are private by default. |
| No sensitive data | No screen asks for names, active cases, complaints, safeguarding details, unsupported legal claims, confidential project documents, donor proposals, political details, uploads, or raw data. |
| Legal-learning boundary | Legal/policy analysis is learning guidance, not legal advice. |
| Project-document boundary | Learners are told not to paste donor proposals, internal plans, legal documents, complaint files, case files, or confidential records. |
| Peer exchange excluded | No required peer exchange or public project-design sharing appears in the build. |
| Accessibility | All interactions are keyboard/tap accessible and screen-reader friendly. |
| Low bandwidth | Essential learning does not depend on heavy media, PDFs, or external embeds. |
| Asset control | Source-named assets are preserved; missing assets remain placeholders. |
| Metadata hidden | Learners do not see screen IDs, block IDs, source IDs, QA notes, or implementation metadata. |
