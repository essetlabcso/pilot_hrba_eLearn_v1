# Module 5 Reflection and Portfolio Logic

## Portfolio principle

Module 5 produces private project-design practice tools. These outputs help the learner move from activity-first ideas to rights-based design. They are private by default, not graded, not certificate-linked, and not visible externally by default.

## Main Module 5 portfolio/tool outputs

1. HRBA situation analysis note
2. Legal/policy scan
3. Rights-based problem statement
4. Rights-based objective improvement
5. HRBA activity design package
6. Risk and mitigation checklist

## Portfolio behavior table

| Tool/reflection ID | Placement | Required status | Visibility | Save behavior | Skip behavior | Portfolio implication | Proof implication | Certificate implication | Safety rule |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| REF-M05-01 | L5.1 assumption-check reflection | Optional encouraged | Private by default | May save privately or skip | Skip allowed | May inform private portfolio note | None | None | Use generalized examples; no names or sensitive project/community details. |
| TOOL-M05-01 | L5.1 HRBA situation analysis note | Required to view; save optional if platform supports | Private by default | Save to private portfolio or mark complete | Can mark complete with safe/generalized sample | Private learning support | None | None | No active cases, names, legal claims, or confidential records. |
| TOOL-M05-02 | L5.2 legal/policy scan | Required to view; save optional | Private by default | Save or mark complete after disclaimer | Can mark complete without saving | Private learning support | None | None | Learning only, not legal advice; no legal documents or violation diagnosis. |
| REF-M05-03 | L5.3 problem framing reflection | Optional encouraged | Private by default | May save privately or skip | Skip allowed | Private learning note | None | None | Avoid blaming or identifying real communities or actors. |
| TOOL-M05-04 | L5.3 HRBA problem analysis worksheet | Required to view; save optional | Private by default | Save or mark complete | Can use fictional example | Private learning support | None | None | No sensitive local tensions, complaint files, or real legal cases. |
| TOOL-M05-05 | L5.4 rights-based objective draft | Required to view; save optional | Private by default | Save or mark complete | Can use sample objective | Private learning support | None | None | Do not paste donor proposal or confidential project text. |
| TOOL-M05-06 | L5.5 HRBA activity design note | Required to view; save optional | Private by default | Save or mark complete | Can use fictional/generalized activity package | Private learning support | None | None | Use broad actor categories; no real advocacy targets or sensitive groups. |
| TOOL-M05-07 | L5.6 HRBA risk and mitigation checklist | Required to view; save optional | Private by default | Save or mark complete | Can use fictional/generalized activity | Private learning support | None | None | No survivor stories, active cases, safeguarding details, or political/civic-space details. |

## Final Module 5 portfolio checkpoint

The main integrated checkpoint is the **HRBA project design package**.

### Saved fields

- broad project issue;
- affected rights-holder groups;
- excluded groups or barriers;
- rights/principles involved;
- duty-bearer or responsible actor categories;
- root causes and capacity gaps;
- legal/policy reference notes using safe broad wording;
- rights-based problem statement;
- draft/improved objective;
- HRBA-aligned activity package;
- risk and mitigation choices;
- optional private note.

### Safety helper text

Use before any optional text field:

> Keep this safe and general. Do not include names, active cases, complaint files, safeguarding details, unsupported legal claims, confidential project documents, donor proposals, political details, raw organizational data, or uploads.

## Save behavior

When the learner saves a Module 5 output:

```text
save:
  module_id = M05
  output_type
  structured selections
  optional private note if entered
  timestamp

do_not_save:
  names
  active case details
  complaint files
  safeguarding/protection details
  legal documents
  donor proposals
  internal project plans
  confidential records
  political details
  raw organizational data
  uploaded files
```

## Deterministic synthesis logic

| Rule ID | Input | Output |
|---|---|---|
| `M5_SYN_01` | situation analysis note | Add to “Rights-based understanding of the issue” |
| `M5_SYN_02` | legal/policy scan | Add to “Standards/policy questions to consider safely” |
| `M5_SYN_03` | problem statement | Add to “Rights-based problem framing” |
| `M5_SYN_04` | objective lab | Add to “Improved HRBA objective” |
| `M5_SYN_05` | activity design package | Add to “HRBA-aligned activities and participation/accountability features” |
| `M5_SYN_06` | risk checklist | Add to “Project design risks and mitigation actions” |
| `M5_SYN_07` | optional private notes | Include only in private export; never in safe-share summary |
| `M5_SYN_08` | skipped saves | Show “Not saved yet — you can return later,” without penalty |

## Carry-forward logic

| Later module | How Module 5 portfolio data is reused |
|---|---|
| Module 6 — Implementation and Adaptive Practice | Use activities, risks, and mitigation actions to guide implementation choices. |
| Module 7 — HRBA in MEAL and Evidence Use | Use objectives, risks, and information gaps to design safer indicators and feedback loops. |
| Module 8 — Accountability and Learning | Use participation/accountability features and risk mitigations to strengthen feedback and learning practice. |
| Module 9 — Course Closing and 90-Day Action Plan | Use the improved objective, activity package, and mitigation action as candidates for a 90-day HRBA action plan. |

## Visibility rules

| User type | Can see Module 5 portfolio content? |
|---|---|
| Participant | Yes, their own private portfolio |
| Course facilitator | No by default; only safe aggregate or consent-based summary if enabled |
| CSO focal person | No individual notes by default |
| Peer participant | No |
| Donor or external partner | No |
| Admin dashboard | Aggregate tags only, no private notes |
| AI service | No raw reflections, project-design drafts, worksheet entries, or private notes |
