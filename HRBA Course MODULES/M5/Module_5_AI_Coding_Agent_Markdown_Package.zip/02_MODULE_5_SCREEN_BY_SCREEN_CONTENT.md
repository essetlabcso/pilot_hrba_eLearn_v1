# Module 5 Screen-by-Screen Learner-Facing Content

# Module 5: Applying HRBA in Project Design

## Module introduction

Welcome to Module 5.

In earlier modules, you explored rights, HRBA principles, rights-holders, duty-bearers, power, and exclusion. This module turns those ideas into project design practice.

You will learn how to analyze a problem through a rights lens, use standards carefully, draft stronger objectives, choose activities that strengthen rights-holder agency and duty-bearer responsiveness, and identify risks before implementation begins.

### Safety reminder

Use fictionalized, anonymized, or generalized examples. Do not paste donor proposals, internal plans, legal documents, complaint files, safeguarding details, political details, confidential records, or raw organizational data.

### Certificate reminder

Module 5 tools and checks are formative. Your certificate is linked to the final course test with a score of 80% or above.


# L5.0 Module Intro

## M5-S0-01 — Applying HRBA in Project Design

Welcome to Module 5. In earlier modules, you explored rights, HRBA principles, rights-holders, duty-bearers, power, and exclusion. This module turns those ideas into project design practice. You will learn how to analyze a problem through a rights lens, use standards carefully, draft stronger objectives, choose activities that strengthen rights-holder agency and duty-bearer responsiveness, and identify risks before implementation begins.

### Learner action / configuration

Viewed; module intro appears before Lesson 5.1.

### Feedback / completion message

None.

### Practical output

None

### Safety note

No sensitive data requested.

### Accessibility note

Alt text required. Keep intro text visible on mobile.

### Asset reference

module-5-hrba-project-design.jpg

### Button

Continue

---


# 5.1 HRBA Situation Analysis

## M5-S1-01 — A project idea that needs deeper analysis

A local CSO wants to design a project on low school attendance among adolescent girls. The first draft says: “Girls are not attending school because families do not value education.” The team plans awareness sessions for parents. Before finalizing, one staff member asks: “What if the issue is not only attitude? What about distance, safety, disability access, menstrual hygiene, household workload, school costs, language, discrimination, or weak response from duty-bearers?” HRBA situation analysis helps the team avoid shallow assumptions.

### Learner action / configuration

Viewed. Use as opening scenario for Lesson 5.1.

### Feedback / completion message

None.

### Practical output

None

### Safety note

Use fictional scenario. Do not imply a specific community.

### Accessibility note

Alt text: CSO team reviewing a project idea with notes and a simple community map.

### Asset reference

project-design-team-reviewing-school-issue.jpg

### Button

Continue

---

## M5-S1-02 — What makes situation analysis rights-based?

A rights-based situation analysis does more than describe a problem. It asks who is affected, whose rights are involved, who faces barriers, who has responsibility, what power relations shape the issue, what information is missing, and what risks may arise from action or inaction. It helps CSOs move from quick assumptions to a more careful understanding of dignity, access, participation, accountability, and exclusion.

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

No sensitive data requested.

### Accessibility note

Short paragraph; use plain language.

### Button

Continue

---

## M5-S1-03 — Six questions for HRBA situation analysis

Use these six questions before turning a problem into a project design.

### Learner action / configuration

Process steps: 1. What is happening? Describe the issue in practical terms. 2. Who is affected? Identify rights-holders, including groups most likely to be excluded. 3. Which rights or principles are involved? Consider dignity, equality, participation, access, safety, information, accountability. 4. Who has responsibility? Identify relevant duty-bearers and other responsible actors. 5. Why is the problem happening? Look at barriers, power, resources, norms, systems, and accountability gaps. 6. What risks should we consider? Identify risks to communities, staff, data, participation, and civic space.

### Feedback / completion message

After all steps are viewed, show: A strong project begins with careful analysis, not quick assumptions.

### Practical output

P12 — HRBA situation analysis note

### Safety note

For learner tool, ask for general issue only.

### Accessibility note

Provide full text alternative below process visual.

### Asset reference

hrba-situation-analysis-six-questions.svg

### Button

Continue

---

## M5-S1-04 — Apply the six questions

Choose one issue your CSO works on. Use broad, safe descriptions only. Complete a short HRBA situation analysis note.

### Learner action / configuration

Fields: Issue; affected rights-holder groups; groups most likely to be excluded; relevant rights/principles; possible duty-bearers/responsible actors; likely root causes/barriers; risks to consider before action.

### Feedback / completion message

Save to portfolio. Remind learners this is a learning tool, not a public report.

### Practical output

P12 — HRBA situation analysis note

### Safety note

Do not include names of individuals, active cases, politically sensitive details, or confidential documents.

### Accessibility note

Worksheet must be printable, mobile-friendly, and screen-reader readable.

### Asset reference

hrba-situation-analysis-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M5-S1-05 — Check your assumptions

What is one assumption your CSO might make too quickly when designing a project? What additional question should you ask before deciding activities?

### Learner action / configuration

Private reflection; optional portfolio save.

### Feedback / completion message

None.

### Practical output

Assumption-check reflection

### Safety note

Keep examples generalized.

### Accessibility note

Reflection box should be optional but encouraged.

### Buttons

Save privately
Skip for now
Continue

---

## M5-S1-06 — What does HRBA situation analysis add?

Which question is most important in a rights-based situation analysis?

### Learner action / configuration

Options: A. How quickly can we start activities? B. Who is affected, who is excluded, who has responsibility, and what barriers or risks shape the issue? C. Which donor template is shortest? D. How can we avoid speaking with the community? Best response: B.

### Feedback / completion message

That’s right: Yes. HRBA analysis connects affected people, exclusion, responsibility, barriers, and risk. Not quite: Not quite. Speed and templates matter, but HRBA design starts with deeper analysis.

### Practical output

KC-M05-01

### Safety note

No sensitive data.

### Accessibility note

Accessible MCQ; clear feedback.

### Button

Submit and view feedback

---


# 5.2 Legal and Policy Analysis

## M5-S2-01 — Using standards carefully

HRBA uses human rights standards, laws, policies, and institutional responsibilities to guide project design. But local CSOs do not need to become legal experts to begin applying HRBA. The practical task is to identify which standards, policies, or responsibilities are relevant, avoid unsupported claims, and know when updated legal or technical advice is needed.

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

Avoid giving legal advice. Frame as learning and referral to updated guidance.

### Accessibility note

Plain language; avoid dense legal terminology.

### Button

Continue

---

## M5-S2-02 — What to look for in a basic legal/policy scan

A simple scan can help a CSO connect a project issue to relevant standards and responsibilities.

### Learner action / configuration

Panels: 1. Relevant right or principle — What dignity, equality, participation, safety, access, or accountability issue is involved? 2. Relevant public responsibility — Which institution or actor may have a role? 3. Relevant policy or plan — Is there a local, sector, national, or organizational policy connected to the issue? 4. Participation requirement — Are affected people supposed to be consulted or informed? 5. Accountability route — Where can feedback, complaint, referral, or dialogue happen safely? 6. Need for expert advice — Is the issue too technical or sensitive for the CSO to interpret alone?

### Feedback / completion message

After all panels are opened: A basic scan helps design responsibly. It does not replace legal advice.

### Practical output

P13 — Basic legal/policy scan

### Safety note

Clearly include informational-not-legal-advice framing.

### Accessibility note

Accordion content must be accessible to screen readers.

### Asset reference

legal-policy-scan-accordion-icons.svg

### Button

Continue

---

## M5-S2-03 — Safe standards-use checklist

Before using legal or policy language in a project design, check whether the wording is accurate, necessary, safe, and useful.

### Learner action / configuration

Checklist items: I can explain the standard in simple language. I know whether this is a law, policy, guideline, principle, or organizational commitment. I am not making claims beyond what I know. I have avoided naming sensitive actors unnecessarily. I know when to seek updated legal/technical advice. I can explain how the standard improves participation, inclusion, accountability, or access.

### Feedback / completion message

Completion after learner checks items.

### Practical output

Safe standards-use checklist

### Safety note

Do not encourage risky confrontation or unsupported legal claims.

### Accessibility note

Checklist should be downloadable and printable.

### Asset reference

safe-standards-use-checklist.pdf

### Button

Submit and view feedback

---

## M5-S2-04 — From vague claim to safer project language

Weak wording: “The local office is violating rights and must be pressured.” Safer project-design wording: “Community members report barriers in accessing the service. The project will support affected groups to document barriers safely, understand relevant responsibilities, and engage appropriate actors through constructive dialogue and feedback channels.” The second version is more useful for project design because it names the issue, protects participants, and focuses on safe engagement.

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

Avoid naming real institutions in sensitive way.

### Accessibility note

Use callout card; not too text-heavy.

### Button

Continue

---

## M5-S2-05 — Complete a basic legal/policy scan

Choose one project issue. Complete a basic scan using safe, general language.

### Learner action / configuration

Fields: Issue; relevant rights/principles; possible public responsibility; relevant policy/standard to verify; participation/accountability implication; what we need to confirm; who we could consult for updated guidance.

### Feedback / completion message

Save to portfolio.

### Practical output

P13 — Legal/policy scan

### Safety note

Do not ask learners to cite confidential or politically sensitive details.

### Accessibility note

Fillable worksheet; provide text alternative.

### Asset reference

legal-policy-scan-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M5-S2-06 — Careful use of standards

Which statement is the safest and most accurate use of legal/policy analysis in project design?

### Learner action / configuration

Options: A. Use strong legal accusations even when evidence is unclear. B. Avoid all reference to rights, laws, or policies. C. Identify relevant standards and responsibilities carefully, use verified information, and seek updated advice when needed. D. Copy legal language without explaining it to communities. Best response: C.

### Feedback / completion message

That’s right: Good. HRBA uses standards carefully, practically, and safely. Not quite: Not quite. Standards matter, but they must be used accurately and responsibly.

### Practical output

KC-M05-02

### Safety note

No sensitive data.

### Accessibility note

Accessible MCQ.

### Button

Submit and view feedback

---


# 5.3 Problem Analysis Through a Rights Lens

## M5-S3-01 — The problem statement is too narrow

A draft project problem says: “Community members do not use the health post because they lack awareness.” The team plans awareness sessions. But a rights lens asks: Is the service physically accessible? Are women, persons with disabilities, young people, or minority language speakers treated respectfully? Are costs, distance, opening hours, stigma, information gaps, or weak feedback systems creating barriers? A rights lens helps the CSO avoid blaming people for barriers they did not create.

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

Fictional scenario only.

### Accessibility note

Alt text: CSO staff reviewing community access barriers on paper.

### Asset reference

rights-lens-health-post-scenario.jpg

### Button

Continue

---

## M5-S3-02 — Symptom, cause, or rights issue?

Sort each statement into the category it best represents.

### Learner action / configuration

Categories: Symptom; Possible root cause/barrier; Rights/accountability issue. Items: “Girls are absent from school.” → Symptom. “School route is unsafe during rainy season.” → Root cause/barrier. “Students with disabilities cannot enter classrooms.” → Rights/accountability issue. “Community members do not attend meetings.” → Symptom. “Meeting times clash with women’s unpaid care work.” → Root cause/barrier. “No accessible feedback channel exists for excluded groups.” → Rights/accountability issue.

### Feedback / completion message

Feedback: HRBA problem analysis separates what is visible from deeper barriers, responsibilities, and accountability gaps.

### Practical output

Problem framing practice

### Safety note

Use generic examples.

### Accessibility note

Tap-first sorting alternative required.

### Button

Submit and view feedback

---

## M5-S3-03 — From needs problem to rights-based problem

Needs-based framing often says what is missing: training, materials, services, awareness, funds. Rights-based framing goes further. It asks what rights, barriers, duties, power relations, and accountability gaps are involved. Example: Needs framing: “Women lack livelihood skills.” Rights-based framing: “Women face unequal access to livelihood opportunities because of mobility restrictions, unpaid care burdens, limited information, weak market linkages, and limited voice in local economic decisions.”

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

Avoid stereotyping; present barriers as contextual examples, not universal claims.

### Accessibility note

Use two-column comparison card.

### Button

Continue

---

## M5-S3-04 — Reframe your problem statement

Take one problem your CSO works on and rewrite it using a rights lens.

### Learner action / configuration

Fields: Original problem statement; who is affected; who is most excluded; rights/principles involved; barriers/root causes; accountability/responsibility gaps; safer rights-based problem statement.

### Feedback / completion message

Save to portfolio.

### Practical output

P14 — HRBA problem analysis worksheet

### Safety note

Use safe, general wording. Do not include sensitive allegations or real names.

### Accessibility note

Worksheet must support long text and plain-language prompts.

### Asset reference

hrba-problem-analysis-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M5-S3-05 — What changed in your problem statement?

After reframing the issue, what became clearer: affected groups, barriers, responsibilities, participation gaps, or risk?

### Learner action / configuration

Private reflection.

### Feedback / completion message

None.

### Practical output

Problem reframing reflection

### Safety note

Generalized reflection only.

### Accessibility note

Optional save to portfolio.

### Buttons

Save privately
Skip for now
Continue

---

## M5-S3-06 — Rights-based problem framing

Which problem statement is strongest from an HRBA perspective?

### Learner action / configuration

Options: A. People are poor because they do not work hard enough. B. The community lacks support. C. Women and youth face barriers to accessing livelihood opportunities because of information gaps, mobility constraints, limited participation in decisions, and weak accountability from relevant actors. D. The project will train 200 people. Best response: C.

### Feedback / completion message

That’s right: Yes. It names affected groups, barriers, participation/accountability issues, and a direction for design. Not quite: Not quite. HRBA avoids blaming communities and goes beyond activity descriptions.

### Practical output

KC-M05-03

### Safety note

No sensitive data.

### Accessibility note

Accessible MCQ.

### Button

Submit and view feedback

---


# 5.4 Defining Rights-Based Objectives

## M5-S4-01 — Objectives should describe the change you seek

A strong rights-based objective does not only say what the project will deliver. It describes what should improve for rights-holders and, where relevant, what should improve in duty-bearer responsiveness, participation, inclusion, accountability, or access. The objective should be realistic, clear, and connected to the problem analysis.

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

No sensitive data.

### Accessibility note

Use short text with example card.

### Button

Continue

---

## M5-S4-02 — Weak or stronger objective?

Match each objective to the best feedback.

### Learner action / configuration

Pairs: “Conduct three community trainings.” → Activity, not objective. “Improve access to inclusive community feedback channels for women, youth, and persons with disabilities in the target area.” → Stronger rights-based objective. “Raise awareness among beneficiaries.” → Too vague and beneficiary-framed. “Strengthen the capacity of community representatives and local service actors to identify and respond to access barriers.” → Stronger; includes rights-holders and duty-bearer responsiveness. “Empower everyone.” → Too broad to guide design or measurement.

### Feedback / completion message

Feedback: Objectives should be specific enough to guide activities, indicators, and learning.

### Practical output

Objective quality practice

### Safety note

Use generic examples.

### Accessibility note

Keyboard-accessible matching.

### Button

Continue

---

## M5-S4-03 — Four checks for rights-based objectives

Use these four checks before approving an objective.

### Learner action / configuration

Steps: 1. Rights-holder change — Does it describe what improves for affected people? 2. Inclusion — Does it name groups facing barriers where relevant? 3. Accountability/responsiveness — Does it include responsible actors, systems, or feedback where relevant? 4. Measurability — Can the change be observed, discussed, or measured safely?

### Feedback / completion message

After steps: A good objective is both rights-aware and practical.

### Practical output

Objective quality checklist

### Safety note

No sensitive data.

### Accessibility note

Provide text alternative for process.

### Asset reference

rights-based-objective-checks.svg

### Button

Continue

---

## M5-S4-04 — Improve an objective

Rewrite one existing objective or draft a new one using the four checks.

### Learner action / configuration

Fields: Draft objective; rights-holder change; inclusion focus; accountability/responsiveness element; safe evidence idea; improved rights-based objective.

### Feedback / completion message

Save to portfolio.

### Practical output

P15 — Rights-based objective draft

### Safety note

Avoid politically risky language and unsupported legal claims.

### Accessibility note

Fillable worksheet; examples included.

### Asset reference

rights-based-objective-builder.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M5-S4-05 — Is your objective realistic?

What would make your objective realistic for a small/local CSO: scope, time, partnerships, budget, staffing, community trust, or duty-bearer engagement?

### Learner action / configuration

Private reflection.

### Feedback / completion message

None.

### Practical output

Objective feasibility reflection

### Safety note

No sensitive data.

### Accessibility note

Optional save.

### Buttons

Save privately
Skip for now
Continue

---

## M5-S4-06 — Objective or activity?

Which statement is mostly an activity, not an objective?

### Learner action / configuration

Options: A. Conduct two training sessions for community volunteers. B. Increase meaningful participation of women and youth in community project planning decisions. C. Improve access to safe feedback channels for excluded groups. D. Strengthen duty-bearer responsiveness to community-identified service barriers. Best response: A.

### Feedback / completion message

That’s right: Yes. Training is an activity. The other options describe desired changes. Not quite: Not quite. Look for statements that describe what the project does, not what changes.

### Practical output

KC-M05-04

### Safety note

No sensitive data.

### Accessibility note

Accessible MCQ.

### Button

Submit and view feedback

---


# 5.5 Designing HRBA Activities

## M5-S5-01 — Activities should match the rights-based problem

Activities are not automatically rights-based because they happen in a community. They become more rights-based when they respond to the analysis, involve affected people, reduce barriers, strengthen capacity, support accountability, and manage risk.

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

No sensitive data.

### Accessibility note

Statement card with DEC blue/green accent.

### Button

Continue

---

## M5-S5-02 — Six types of HRBA-aligned activities

Explore activity types that can strengthen rights-based change.

### Learner action / configuration

Tabs: 1. Awareness and information — Help rights-holders understand issues, services, rights, and options in accessible ways. 2. Participation and dialogue — Create safe spaces where affected people influence decisions. 3. Capacity strengthening — Build skills of rights-holders, CSOs, and responsible actors. 4. Service access and referral support — Help people navigate services without replacing duty-bearer responsibilities. 5. Accountability and feedback — Strengthen complaint, response, transparency, and learning systems. 6. Evidence and advocacy — Use safe evidence to engage decision-makers constructively.

### Feedback / completion message

Completion after all tabs opened.

### Practical output

Activity design menu

### Safety note

Include safe advocacy framing.

### Accessibility note

Tabs must be screen-reader readable.

### Asset reference

hrba-activity-types-tabs.svg

### Button

Continue

---

## M5-S5-03 — Choose better activities

Scenario: Your rights-based problem analysis shows that women with disabilities are excluded from community livelihood activities because meeting venues are inaccessible, information is shared late, facilitators are not trained on inclusion, and feedback channels are not accessible. Which activity package is strongest?

### Learner action / configuration

Options: A. Conduct one general awareness training and close the activity. B. Provide materials to selected participants without changing participation design. C. Consult women with disabilities, adapt venue and communication, train facilitators, set accessible feedback options, and engage relevant service actors on responsibilities. D. Delay all activities until every barrier is solved. Best response: C.

### Feedback / completion message

That’s right: Strong. It addresses participation, accessibility, capacity, feedback, and responsibility. Not quite: Review the problem analysis and choose activities that respond to barriers and accountability gaps.

### Practical output

Decision practice

### Safety note

Use fictional example. Avoid implying all women with disabilities have same needs.

### Accessibility note

Accessible scenario with radio buttons.

### Button

Submit and view feedback

---

## M5-S5-04 — Design one HRBA-aligned activity package

Use one objective from Lesson 5.4. Select activities that match the rights-based problem and objective.

### Learner action / configuration

Fields: Objective; activity 1; how affected people participate; inclusion/accessibility adjustment; duty-bearer/responsible actor engagement; accountability/feedback element; safety/risk mitigation; expected evidence of progress.

### Feedback / completion message

Save to portfolio.

### Practical output

P16 — HRBA activity design note

### Safety note

No sensitive details; use broad actor categories.

### Accessibility note

Fillable tool; printable low-bandwidth version.

### Asset reference

hrba-activity-design-template.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M5-S5-05 — What makes the activity rights-based?

Look at the activity package you drafted. What makes it rights-based: participation, inclusion, accountability, capacity strengthening, duty-bearer engagement, or risk management?

### Learner action / configuration

Private reflection.

### Feedback / completion message

None.

### Practical output

Activity quality reflection

### Safety note

Generalized reflection only.

### Accessibility note

Optional save.

### Buttons

Save privately
Skip for now
Continue

---

## M5-S5-06 — Signs of HRBA-aligned activities

Which features suggest that an activity is HRBA-aligned? Select all that apply.

### Learner action / configuration

Options: A. Affected people help shape the activity. B. The activity only counts attendance. C. Barriers faced by excluded groups are considered. D. Feedback and response mechanisms are included. E. Risks and do-no-harm are considered. Correct answers: A, C, D, E.

### Feedback / completion message

That’s right: Yes. HRBA-aligned activities strengthen participation, inclusion, accountability, and safety. Partial/incorrect: Attendance can be useful but is not enough to show rights-based practice.

### Practical output

KC-M05-05

### Safety note

No sensitive data.

### Accessibility note

Accessible multiple response.

### Button

Submit and view feedback

---


# 5.6 Risk Assessment and Mitigation

## M5-S6-01 — Design should reduce risk before implementation begins

HRBA does not mean pushing communities or CSOs into unsafe action. It means designing with care. Project design should identify risks related to exclusion, safeguarding, backlash, data, confidentiality, civic space, conflict sensitivity, staff safety, and unrealistic expectations before activities begin.

### Learner action / configuration

Viewed.

### Feedback / completion message

None.

### Practical output

None

### Safety note

Safety-sensitive content. Use balanced language.

### Accessibility note

Orange safety callout; not alarmist.

### Button

Continue

---

## M5-S6-02 — Common HRBA project design risks

Review common risks that may appear during HRBA project design.

### Learner action / configuration

Markers: 1. Exclusion risk — Some groups are left out because of language, disability, timing, location, gender norms, poverty, age, or information gaps. 2. Participation risk — People are asked to speak without safety, consent, or influence. 3. Data risk — Sensitive information is collected without need, consent, anonymization, or secure handling. 4. Advocacy/civic-space risk — Engagement with duty-bearers or public issues creates avoidable risk. 5. Safeguarding risk — Activities expose children or vulnerable adults to harm or disclosure. 6. Expectation risk — Communities are promised more than the CSO can deliver.

### Feedback / completion message

Completion after all markers opened.

### Practical output

Risk awareness

### Safety note

Avoid prompting disclosure of actual cases.

### Accessibility note

Provide text alternative.

### Asset reference

common-hrba-project-design-risks.svg

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M5-S6-03 — Risk or mitigation?

Sort each item as a risk or a mitigation action.

### Learner action / configuration

Categories: Risk; Mitigation. Items: Collecting names of people reporting discrimination → Risk. Using anonymized examples in training → Mitigation. Holding meetings at times women cannot attend → Risk. Providing multiple safe feedback options → Mitigation. Publishing photos without consent → Risk. Explaining clearly what the project can and cannot do → Mitigation. Asking people to speak publicly about sensitive harms → Risk. Using private, voluntary, consent-based participation options → Mitigation.

### Feedback / completion message

Feedback: Strong HRBA design identifies risk and builds safer alternatives before implementation.

### Practical output

Risk/mitigation practice

### Safety note

Do not request real data.

### Accessibility note

Tap/keyboard alternative.

### Button

Submit and view feedback

---

## M5-S6-04 — Complete a risk and mitigation checklist

Review one planned activity from Lesson 5.5 and identify risks and safer alternatives.

### Learner action / configuration

Fields: Planned activity; who could be affected; exclusion risk; participation/safety risk; data/confidentiality risk; civic-space or backlash risk; expectation risk; mitigation actions; what should not be collected or shared; who should review the risk before implementation.

### Feedback / completion message

Save to portfolio.

### Practical output

P17 — HRBA risk and mitigation checklist

### Safety note

High caution: learners must use fictionalized/general examples and avoid active cases.

### Accessibility note

Printable; text-first; plain-language.

### Asset reference

hrba-risk-mitigation-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M5-S6-05 — Safer project design decision

A CSO plans to collect video stories from survivors of violence to show the seriousness of an issue. What is the safest first response?

### Learner action / configuration

Options: A. Record and publish the stories quickly because they are powerful. B. Avoid any evidence use forever. C. Stop and redesign the evidence approach: assess risk, avoid identifiable survivor stories, seek specialized safeguarding guidance, use anonymized or aggregate evidence where appropriate, and prioritize consent and safety. D. Ask staff to collect stories secretly. Best response: C.

### Feedback / completion message

That’s right: Yes. Safety, consent, anonymization, and specialized guidance are essential. Not quite: This is high-risk evidence. Powerful stories can create harm if collected or shared unsafely.

### Practical output

KC-M05-06

### Safety note

Do not solicit personal stories. Use fictional scenario.

### Accessibility note

Accessible scenario; no graphic imagery.

### Button

Submit and view feedback

---

## M5-S6-06 — Module 5 summary

In this module, you practiced applying HRBA to project design. You analyzed a situation through rights, responsibility, power, exclusion, and risk. You completed a basic legal/policy scan, reframed a problem statement, drafted a rights-based objective, designed HRBA-aligned activities, and completed a risk and mitigation checklist. In the next module, you will move from design into implementation: participation, inclusion, feedback, adaptation, and safe documentation during project delivery.

### Learner action / configuration

Viewed; Next CTA: Continue to Module 6.

### Feedback / completion message

None.

### Practical output

Module 5 completion

### Safety note

No sensitive data.

### Accessibility note

Include summary cards for each practical output.

### Button

Continue

---


## Module 5 next step

In Module 6, you will move from design into practical HRBA implementation. Your situation analysis, legal/policy scan, problem framing, objective, activity design, and risk mitigation work can help you implement with stronger participation, accountability, inclusion, and adaptive learning.

### Button

Continue to Module 6
