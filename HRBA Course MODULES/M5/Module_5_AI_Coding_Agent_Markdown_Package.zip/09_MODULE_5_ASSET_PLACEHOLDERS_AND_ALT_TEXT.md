# Module 5 Asset Placeholders and Alt Text

## Asset rule

Do not invent final asset filenames or paths. Use approved source-named assets where listed. If a file is missing, use a placeholder component with the approved filename reference.

## Visual style

Use CSO Learning Hub / DEC visual identity:

- primary blue: `#3B99D4`
- accent green: `#91C852`
- deep navy: `#0F172A`
- light background: `#F9FAFB`
- white cards
- dark text: `#111827`
- subtle borders: `#E5E7EB`
- rounded corners
- soft shadows

## Asset register

| Asset ID | Filename / asset | Type | Placement | Purpose | Style / filename | Alt text | Low-bandwidth alternative | Safety/privacy note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-M05-001 | module-5-hrba-project-design.jpg | Module header image | Module intro | Set visual identity for project design module | module-5-hrba-project-design.jpg | Local CSO team reviewing a project design plan around a table. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-002 | project-design-team-reviewing-school-issue.jpg | Scenario image | L5.1 | Show project idea needing deeper analysis | project-design-team-reviewing-school-issue.jpg | CSO team reviewing notes about barriers affecting school attendance. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-003 | hrba-situation-analysis-six-questions.svg | Diagram | L5.1 process | Visualize six HRBA situation analysis questions | hrba-situation-analysis-six-questions.svg | Diagram showing six questions for HRBA situation analysis. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-004 | hrba-situation-analysis-worksheet.pdf | Worksheet PDF | L5.1 tool | Portfolio tool for situation analysis | hrba-situation-analysis-worksheet.pdf | N/A; worksheet title and fields readable. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-005 | legal-policy-scan-accordion-icons.svg | Icon set | L5.2 accordion | Support legal/policy scan panels | legal-policy-scan-accordion-icons.svg | Icons representing legal/policy scan elements. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-006 | safe-standards-use-checklist.pdf | Checklist PDF | L5.2 checklist | Downloadable standards-use checklist | safe-standards-use-checklist.pdf | N/A | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-007 | legal-policy-scan-worksheet.pdf | Worksheet PDF | L5.2 tool | Portfolio tool for basic scan | legal-policy-scan-worksheet.pdf | N/A | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-008 | rights-lens-health-post-scenario.jpg | Scenario image | L5.3 | Visualize problem framing through rights lens | rights-lens-health-post-scenario.jpg | CSO staff reviewing barriers to health-post access on paper. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-009 | needs-vs-rights-problem-framing.svg | Comparison diagram | L5.3 | Compare needs-based and rights-based framing | needs-vs-rights-problem-framing.svg | Two cards comparing needs-based and rights-based problem framing. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-010 | hrba-problem-analysis-worksheet.pdf | Worksheet PDF | L5.3 tool | Problem reframing tool | hrba-problem-analysis-worksheet.pdf | N/A | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-011 | rights-based-objective-checks.svg | Process diagram | L5.4 process | Show four objective quality checks | rights-based-objective-checks.svg | Four checks for rights-based objectives. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-012 | rights-based-objective-builder.pdf | Worksheet PDF | L5.4 tool | Objective drafting tool | rights-based-objective-builder.pdf | N/A | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-013 | hrba-activity-types-tabs.svg | Tab/icon diagram | L5.5 tabs | Show six activity types | hrba-activity-types-tabs.svg | Six activity types for HRBA-aligned design. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-014 | hrba-activity-design-template.pdf | Worksheet PDF | L5.5 tool | Activity package design tool | hrba-activity-design-template.pdf | N/A | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-015 | common-hrba-project-design-risks.svg | Labeled graphic | L5.6 graphic | Show common risks | common-hrba-project-design-risks.svg | Diagram showing common HRBA project design risks. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-016 | hrba-risk-mitigation-checklist.pdf | Checklist PDF | L5.6 tool | Risk and mitigation checklist | hrba-risk-mitigation-checklist.pdf | N/A | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |
| A-M05-017 | module-5-portfolio-output-cards.svg | Summary visual | Module summary | Show completed outputs | module-5-portfolio-output-cards.svg | Cards listing Module 5 practical outputs. | Essential content must also appear as text or accessible in-platform form; image/PDF not required to learn. | No recognizable faces, no readable sensitive text, no confidential documents, no political signage, no invented logos; avoid poverty/suffering imagery and stereotypes. |

## Asset implementation rules

- Every image/SVG must include alt text.
- Complex diagrams need text alternatives.
- PDF/DOCX/XLSX tools must also have in-platform field versions where feasible.
- Do not use photos that identify vulnerable people or sensitive situations.
- Do not show readable donor proposals, legal documents, internal plans, real logos, political signage, or confidential records.
- Avoid text-heavy images; all essential text must also exist as HTML text.
- If assets are missing, render placeholder cards using the approved filename reference.
