# Module 5 Overview

## Course

**Applying the Human Rights-Based Approach (HRBA) in CSO Practice**

## Module title

**Module 5: Applying HRBA in Project Design**

## Module role

Module 5 is a substantive HRBA project-design practice module. It helps participants move from activity-first project ideas to rights-based design grounded in situation analysis, legal/policy awareness, root causes, participation, inclusion, accountability, realistic objectives, activity choices, and risk mitigation.

## Recommended duration

**100–120 minutes**

## Primary audience

Local and grassroots CSO staff, project officers, MEAL staff, programme coordinators, organizational focal persons, and CSO leaders involved in project design.

## Main learner shift

From:

> “We need to write activities quickly.”

To:

> “We need to understand the rights issue, affected groups, exclusion, responsibilities, root causes, legal/policy context, objective quality, activity logic, and risks before finalizing project design.”

## Module learning outcomes

By the end of Module 5, participants should be able to:

1. use safe HRBA situation-analysis questions before jumping to activities;
2. use legal and policy references carefully as learning and design guidance, not legal advice;
3. reframe a weak problem statement through a rights lens;
4. draft or improve a rights-based objective;
5. choose activities that strengthen rights-holder agency and duty-bearer responsiveness;
6. identify key HRBA project design risks and safe mitigation actions;
7. save or download private Module 5 project-design tools without affecting certificate eligibility.

## Approved lesson sequence

1. **Module intro**
2. **HRBA Situation Analysis**
3. **Legal and Policy Analysis**
4. **Problem Analysis Through a Rights Lens**
5. **Defining Rights-Based Objectives**
6. **Designing HRBA Activities**
7. **Risk Assessment and Mitigation**

## Main portfolio/tool outputs

- HRBA situation analysis note
- Legal/policy scan
- Rights-based problem statement
- Rights-based objective improvement
- HRBA activity design package
- Risk and mitigation checklist

## Assessment rule

All Module 5 checks are formative only. They support practice and review. They do not issue a certificate, unlock a certificate, rank participants, or rank CSOs.

## Certificate rule

Certificate eligibility remains tied to the final course test with a score of **80% or above**.

## Safety level

Moderate to high because project design can touch legal/policy analysis, power and exclusion, evidence, safeguarding, civic-space, and confidential project documents.

## Privacy rule

Tool outputs, optional notes, project-design drafts, worksheet entries, and reflection outputs are private by default.

## Sensitive data rule

Do not ask learners to provide names, active cases, complaint files, safeguarding details, unsupported legal claims, confidential project documents, donor proposals, political details, raw organizational data, or uploads.
