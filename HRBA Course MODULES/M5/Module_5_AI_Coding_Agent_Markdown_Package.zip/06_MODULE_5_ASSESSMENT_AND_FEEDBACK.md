# Module 5 Assessment and Feedback Map

## Module assessment rule

All Module 5 checks are **formative only**. They help participants practice HRBA project-design thinking and prepare for later modules.

Module 5 checks do **not**:

- issue a certificate;
- unlock a certificate;
- replace the final course test;
- rank the participant;
- rank the CSO;
- require sensitive information;
- require document uploads;
- require real donor proposals, legal documents, complaint files, safeguarding information, or confidential project data.

The course certificate remains linked to the **final course test with a score of 80% or above**.

## Assessment sequence

| Assessment ID | Lesson | Block ID | Type | Question/prompt | Options/expected | Best/correct answer | Feedback | Status | Certificate implication | Accessibility note | Safety note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KC-M05-01 | 5.1 | M05-L01-B06 | MCQ | Which question is most important in a rights-based situation analysis? | Use baseline options in block storyboard / interaction config. | That’s right: B | HRBA analysis connects affected people, exclusion, responsibility, barriers, and risk. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | No sensitive data. |
| KC-M05-02 | 5.2 | M05-L02-B06 | MCQ | Which statement is the safest and most accurate use of legal/policy analysis? | Use baseline options in block storyboard / interaction config. | That’s right: C | Use standards carefully, practically, and safely; seek updated advice when needed. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | Not legal advice. |
| KC-M05-03 | 5.3 | M05-L03-B06 | MCQ | Which problem statement is strongest from an HRBA perspective? | Use baseline options in block storyboard / interaction config. | That’s right: C | Strong framing names affected groups, barriers, participation/accountability issues. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | Avoid blaming or identifying real communities. |
| KC-M05-04 | 5.4 | M05-L04-B06 | MCQ | Which statement is mostly an activity, not an objective? | Use baseline options in block storyboard / interaction config. | That’s right: A | Training is an activity; objectives describe desired changes. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | No sensitive data. |
| KC-M05-05 | 5.5 | M05-L05-B06 | Multiple Response | Which features suggest an activity is HRBA-aligned? | Use baseline options in block storyboard / interaction config. | That’s right: A,C,D,E | Participation, inclusion, feedback, and risk management indicate HRBA alignment. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | No sensitive data. |
| KC-M05-06 | 5.6 | M05-L06-B05 | Scenario Decision | What is the safest first response to collecting survivor video stories? | Use baseline options in block storyboard / interaction config. | That’s right: C | Safety, consent, anonymization, and specialized guidance are essential. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | Do not solicit personal stories. |
| PRA-M05-01 | 5.1 | M05-L01-B04 | Tool Activity | Complete HRBA situation analysis note. | Use baseline options in block storyboard / interaction config. | Completion-based, not scored. | Encourages deeper analysis before design. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | Use generalized examples. |
| PRA-M05-02 | 5.2 | M05-L02-B05 | Tool Activity | Complete basic legal/policy scan. | Use baseline options in block storyboard / interaction config. | Completion-based, not scored. | Reinforces safe standards use. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | No legal advice; avoid sensitive claims. |
| PRA-M05-03 | 5.3 | M05-L03-B04 | Tool Activity | Reframe a problem statement. | Use baseline options in block storyboard / interaction config. | Completion-based, quality reviewed only if submitted later. | Shifts from needs/activity framing to rights-based framing. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | Avoid active cases or names. |
| PRA-M05-04 | 5.4 | M05-L04-B04 | Tool Activity | Improve an objective using HRBA checks. | Use baseline options in block storyboard / interaction config. | Completion-based. | Clarifies change, inclusion, accountability, measurability. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | Avoid unsupported legal claims. |
| PRA-M05-05 | 5.5 | M05-L05-B04 | Tool Activity | Design HRBA-aligned activity package. | Use baseline options in block storyboard / interaction config. | Completion-based. | Links activities to analysis, participation, inclusion, feedback, risk. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | Use broad actor categories. |
| PRA-M05-06 | 5.6 | M05-L06-B04 | Tool Activity | Complete risk and mitigation checklist. | Use baseline options in block storyboard / interaction config. | Completion-based. | Controls project design risks before implementation. | Formative only | No module assessment issues certificate; certificate requires final course test score of 80% or above. | Keyboard/tap/screen-reader accessible; clear labels and non-color-only feedback. | High caution; no sensitive details. |


# Repaired learner-facing feedback patterns

## KC-M05-01 — HRBA situation analysis focus

Question: Which question is most important in a rights-based situation analysis?

A. Which activity can we implement fastest?  
B. Who is affected or excluded, what rights/principles are involved, who has responsibility, what root causes and barriers exist, and what risks should be considered?  
C. Which budget line is easiest to spend?  
D. Which message will sound strongest in a proposal?

Best response: B

Feedback for A: Not quite. Speed matters, but HRBA design should not begin with the fastest activity.  
Feedback for B: That’s right. HRBA situation analysis connects affected people, exclusion, rights, responsibility, barriers, root causes, and risk.  
Feedback for C: Not quite. Budget planning matters later, but the first design question is not which line is easiest to spend.  
Feedback for D: Not quite. Strong proposal language should come from careful analysis, not replace it.

## KC-M05-02 — Safe legal/policy analysis

Question: Which statement is the safest and most accurate use of legal/policy analysis?

A. The course should help learners make legal findings about real violations.  
B. Learners should upload legal documents and donor proposals for review.  
C. Legal and policy references can guide better project-design questions, but this activity is not legal advice and real decisions require updated qualified support.  
D. Legal and policy analysis should be skipped because it is too sensitive.

Best response: C

Feedback for A: Not quite. This course is for learning and project-design support, not making legal findings.  
Feedback for B: Not quite. Do not upload legal documents, donor proposals, complaint files, or confidential project documents.  
Feedback for C: That’s right. Standards and policies can guide better questions, but this course does not provide legal advice.  
Feedback for D: Not quite. Legal and policy awareness can be useful when handled carefully and safely.

## KC-M05-03 — Rights-based problem statement

Question: Which problem statement is strongest from an HRBA perspective?

A. “Families do not care about girls’ education.”  
B. “We will conduct awareness sessions for parents.”  
C. “Adolescent girls in the target area face overlapping barriers to school participation, including safety, cost, household workload, disability access, information gaps, and weak response mechanisms.”  
D. “The project will train 200 people.”

Best response: C

Feedback for A: Not quite. This blames families and may hide structural barriers.  
Feedback for B: Not quite. This is an activity, not a problem statement.  
Feedback for C: That’s right. It names affected rights-holders, barriers, participation/access issues, and response gaps without blame.  
Feedback for D: Not quite. This is an output target, not a rights-based problem statement.

## KC-M05-04 — Activity versus objective

Question: Which statement is mostly an activity, not an objective?

A. “Conduct three training sessions for community volunteers.”  
B. “Improve safe and inclusive participation of adolescent girls in school-related decision-making.”  
C. “Strengthen accessible feedback and response mechanisms for excluded groups.”  
D. “Increase duty-bearer responsiveness to identified barriers.”

Best response: A

Feedback for A: That’s right. Conducting trainings is an activity. Objectives describe the change the project wants to support.  
Feedback for B: Not quite. This describes a desired change in participation, so it is closer to an objective.  
Feedback for C: Not quite. This describes a change in accountability practice, so it is closer to an objective.  
Feedback for D: Not quite. This describes a desired change in responsiveness, so it is closer to an objective.

## KC-M05-05 — HRBA-aligned activities

Question: Which features suggest an activity is HRBA-aligned? Select all that apply.

A. It is based on situation analysis.  
B. It only counts participants reached.  
C. It includes meaningful participation.  
D. It addresses inclusion barriers.  
E. It includes feedback/accountability and risk mitigation.

Best responses: A, C, D, and E

Feedback for A/C/D/E: That’s right. HRBA-aligned activities are grounded in analysis, participation, inclusion, accountability, and risk management.  
Feedback for B: Not quite. Counting participants reached can be useful, but it is not enough to show HRBA alignment.

## KC-M05-06 — Safer project design decision

Scenario: A CSO wants to collect survivor video stories for a campaign.

Question: What is the safest first response?

A. Start filming immediately because stories are powerful.  
B. Ask staff to collect names and detailed case histories.  
C. Pause and assess safety, consent, anonymization, referral pathways, safeguarding, and whether a less risky evidence method can achieve the purpose.  
D. Post the stories publicly after verbal consent only.

Best response: C

Feedback for A: Not quite. Powerful stories can create serious safety, consent, and dignity risks.  
Feedback for B: Not quite. Collecting names and detailed case histories can increase risk and is not needed for this learning activity.  
Feedback for C: That’s right. Safety, consent, anonymization, referral pathways, safeguarding, and less risky evidence options must be considered before any story collection.  
Feedback for D: Not quite. Public posting after verbal consent alone may not protect safety, dignity, or informed consent.


## Assessment data map

| Assessment/tool | Required saved data | Optional saved data | Do not save |
|---|---|---|---|
| Situation analysis check | Completion status | Selected answer | Personal examples, names, real cases |
| Legal/policy check | Completion status | Selected answer | Legal documents, legal claims, confidential records |
| Problem statement check | Completion status | Selected answer | Active cases or names |
| Objective check | Completion status | Selected answer | Donor proposals or confidential project drafts |
| Activity alignment check | Completion status | Selected responses | Sensitive stakeholder details |
| Risk scenario decision | Completion status | Selected response | Survivor stories, case details, safeguarding records |
| Tool activities | Completion status if completed in platform | Private worksheet fields if saved | Uploads, confidential documents, raw project files |
