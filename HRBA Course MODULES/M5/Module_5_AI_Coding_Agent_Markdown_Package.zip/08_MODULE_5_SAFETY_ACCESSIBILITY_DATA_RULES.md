# Module 5 Safety, Accessibility, and Data Rules

## Safety principle

Module 5 has a moderate-to-high safety level because project design can touch legal/policy analysis, power and exclusion, evidence, safeguarding, civic-space, advocacy, donor proposals, and confidential project documents.

The module must help learners practice HRBA design safely without exposing people, communities, organizations, cases, safeguarding records, legal documents, donor proposals, or confidential project information.

## Safety rules from source workbook

| Safety / privacy rule | Where addressed | Learner-facing wording | Pass condition | Repetition-reduction decision | Legal / project-document boundary |
| --- | --- | --- | --- | --- | --- |
| Safe example rule | All scenarios, tools, reflections | Use fictional, generalized, or anonymized examples. Do not include names, active cases, complaint files, safeguarding details, legal claims, or confidential project documents. | Every learner input block includes a short safety cue. | Short reminder appears at point of risk, not before every paragraph. | Project-document uploads are not requested. |
| Legal-learning disclaimer | L5.2 and standards-use checklist | This activity is for learning and project-design support only. It does not provide legal advice. Do not diagnose real legal violations or upload legal documents. For real decisions, use updated guidance and qualified support. | Disclaimer visible before legal/policy scan and checklist. | One full disclaimer in L5.2; shorter reminders later. | Legal advice boundary is explicit. |
| Project-document privacy | L5.4 objective lab; all tools | Do not paste donor proposals, internal plans, legal documents, complaints, case files, or confidential records. Use a sample or generalized example. | No tool asks for uploads or confidential project details. | Repeated only before tools that could invite real project text. | Private tools only by default. |
| No sensitive actors | L5.2, L5.3, L5.5, L5.6 | Use broad actor categories. Do not name real officials, authorities, advocacy targets, complainants, survivors, vulnerable individuals, or sensitive community actors. | No prompt asks for real names. | Use brief reminders in stakeholder/risk related blocks. | No naming real duty-bearers or legal targets. |
| Data minimization | All tools and portfolio outputs | Write only what is needed for learning. Short, safe notes are enough. | Input fields are limited and labels include safe-entry guidance. | No duplicate warnings where a tool has built-in safety labels. | No upload of raw evidence or documents. |
| Survivor and safeguarding evidence | L5.6 risk scenario | Do not collect or share survivor stories, case details, photos, referral records, or safeguarding information in this course. Use simulated, anonymized, aggregate, or consent-based evidence only where appropriate. | Scenario feedback rejects unsafe video-story options. | One clear high-caution warning for L5.6. | No case or legal diagnosis. |
| Peer exchange safety | 16_PEER_EXCHANGE | Peer exchange is not required in this module. If enabled later, share only broad lessons from fictional or anonymized examples. | No required peer-exchange completion. | Deferred to avoid repeated warnings. | Not linked to certificate/proof. |
| Certificate/proof separation | All checks and tools | Module 5 practice tools help you learn. They are not certificate requirements. Course certificate depends only on final test score of 80% or above. | No module checks or tools issue certificates. | Shown in README, summary and build handoff. | No external visibility by default. |

## Do not request

Never ask learners to submit:

- names of people, staff, officials, organizations, or communities;
- active cases;
- complaint files;
- safeguarding or protection details;
- survivor stories or identifiable testimonies;
- legal claims or legal documents;
- donor proposals;
- internal project plans;
- confidential records;
- political details;
- raw organizational data;
- uploads.

## Safe alternatives

Use:

- fictional examples;
- broad work areas;
- generalized problem statements;
- anonymized or sample scenarios;
- structured choices;
- optional private notes with safety helper text;
- private portfolio summaries.

## Legal-learning boundary

Use this learner-facing message in Lesson 5.2 and anywhere legal/policy analysis appears:

> This activity is for learning and project-design support only. It does not provide legal advice. Do not diagnose real legal violations or upload legal documents. For real decisions, use updated guidance and qualified support.

## Project-document privacy boundary

Use this before objective/problem/activity/risk tools:

> Do not paste donor proposals, internal plans, legal documents, complaints, case files, or confidential records. Use a sample or generalized example.

## Privacy rules

| Data type | Default visibility |
|---|---|
| Tool outputs | Private by default |
| Optional reflections | Private by default |
| Project-design drafts | Private by default |
| Assessment completion | Learner/system only |
| Assessment score/response | Formative only; no certificate effect |
| Portfolio summaries | Learner private portfolio only |
| Admin analytics | Aggregated only, no raw notes/drafts |

## Accessibility and low-bandwidth QA

| Accessibility area | Requirement | Where addressed | Pass condition | Implementation note | Status |
| --- | --- | --- | --- | --- | --- |
| Keyboard access | All interactions must be operable by keyboard and tap, with visible focus. | All interactions | Learners can complete each block without a mouse. | Avoid drag-only interactions; provide list/select alternatives. | Pass |
| Screen-reader labels | Inputs, buttons, checklists, tabs, accordions, process steps and matrices require meaningful labels. | Tools and interactions | Screen reader announces purpose, field labels, instructions and feedback. | Use semantic headings and ARIA labels where needed. | Pass |
| Alt text | Every image/diagram needs alt text or text equivalent. | All visuals/assets | Alt text is recorded in asset register and visual storyboard. | No essential meaning only inside image. | Pass |
| Text alternatives | Process diagrams, root-cause tree, objective builder, activity menu, risk matrix and labeled graphics need text equivalents. | L5.1–L5.6 | Full step/card/list text appears below or beside visuals. | Learner can complete module without image downloads. | Pass |
| Non-drag alternatives | Sorting/matching/root-cause interactions must work without drag/drop. | L5.3, L5.4, L5.5 | Alternative checkboxes, dropdowns, buttons or list selections provided. | Mobile tap-first layout preferred. | Pass |
| Accessible tools/PDFs | PDF/worksheet tools must have in-platform accessible alternatives. | All worksheet tools | Learner can complete tool in player without downloading PDF. | PDFs are support resources, not required for completion. | Pass |
| Mobile readability | Tables/matrices convert to stacked cards; text remains readable in one column. | All lessons | No horizontal scrolling for essential content. | Risk matrix and comparison cards stack on mobile. | Pass |
| Low bandwidth | Essential content remains usable without images, video, or large downloads. | All lessons | Text equivalent and in-platform tool always available. | Use images as support, not required learning content. | Pass |
| Reduced motion | Avoid unnecessary animation; respect reduced-motion settings. | Process, tabs, cards | Motion is subtle or disabled where user selects reduced motion. | No auto-play or distracting animation. | Pass |
| Color meaning | Do not rely on color alone for risk, status, or feedback. | Risk matrix, checks, cards | Labels/icons/text explain meaning. | Orange/red caution colors always include text labels. | Pass |
| Plain language | Keep learner-facing language clear and practical. | All content | No dense legal/policy jargon without explanation. | Use glossary/tooltips only for essential terms. | Pass |

## AI/data restriction

Raw reflections, optional notes, project-design drafts, worksheet entries, and portfolio content should not be sent to AI services. If AI is later used for safe summaries, use structured non-sensitive tags or participant-approved safe summaries only.

## Safe helper text

Use before any optional text field or tool output:

> Keep this safe and general. Do not include names, active cases, complaint files, safeguarding details, unsupported legal claims, confidential project documents, donor proposals, political details, raw organizational data, or uploads.
