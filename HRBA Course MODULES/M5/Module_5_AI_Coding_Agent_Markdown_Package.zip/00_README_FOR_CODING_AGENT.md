# Module 5 AI Coding Agent Package — README

## Package purpose

This package contains the clean implementation content for **Module 5: Applying HRBA in Project Design** in the course **Applying the Human Rights-Based Approach (HRBA) in CSO Practice**.

Use this package as the source of truth for building Module 5 in the CSO Learning Hub course player or related repo implementation.

## Package files

1. `00_README_FOR_CODING_AGENT.md` — build rules, file map, no-drift instructions.
2. `01_MODULE_5_OVERVIEW.md` — module purpose, outcomes, duration, learner shift, section flow.
3. `02_MODULE_5_SCREEN_BY_SCREEN_CONTENT.md` — exact learner-facing content and implementation microcopy for all approved screens.
4. `03_MODULE_5_BLOCK_STORYBOARD.md` — screen-by-screen storyboard with block type, learner action, completion, data, privacy, accessibility, and asset requirement.
5. `04_MODULE_5_INTERACTION_LOGIC.md` — deterministic behavior rules and pseudo-logic.
6. `05_MODULE_5_REFLECTION_PORTFOLIO_LOGIC.md` — Module 5 portfolio/tool outputs and carry-forward logic.
7. `06_MODULE_5_ASSESSMENT_AND_FEEDBACK.md` — formative checks, answers, and repaired feedback language.
8. `07_MODULE_5_DESIGN_AND_VISUAL_SPEC.md` — visual and interaction design rules.
9. `08_MODULE_5_SAFETY_ACCESSIBILITY_DATA_RULES.md` — safety, privacy, accessibility, low-bandwidth, and data rules.
10. `09_MODULE_5_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md` — approved asset filenames, placeholders, and alt text.
11. `10_MODULE_5_BUILD_ACCEPTANCE_CRITERIA.md` — implementation QA checks.
12. `11_MODULE_5_CODE_AGENT_HANDOFF_PROMPT.md` — copy/paste-ready coding-agent prompt.

## Binding implementation rules

- Build only the learner-facing Module 5 course experience.
- Preserve the approved title: **Applying HRBA in Project Design**.
- Preserve the approved six-lesson sequence plus module intro and summary.
- Do not include QA history, source inventories, evidence packs, change logs, approval locks, review notes, or production-process records in learner-facing screens.
- Do not expose screen IDs, block IDs, source IDs, citations, or implementation metadata to learners.
- Keep all Module 5 checks, tools, and reflections formative only.
- Certificate eligibility remains tied only to the final course test with a score of **80% or above**.
- Do not request names, active cases, complaint files, safeguarding details, unsupported legal claims, confidential project documents, donor proposals, political details, raw organizational data, or uploads.
- Tool outputs, reflections, worksheet entries, project-design notes, and portfolio content are private by default.
- Do not send raw portfolio/reflection/worksheet/project-design text to AI services.
- Use “Not quite” instead of “Incorrect.”
- Use “That’s right” or “Good choice” for best responses.
- Legal and policy analysis is learning guidance only and must not be presented as legal advice.
- Project design tools must use sample, fictionalized, anonymized, or generalized examples.
- Peer exchange is not part of the required Module 5 flow.
- All tools must have downloadable and in-platform accessible options where feasible.
- All interactions must be keyboard accessible, tap-friendly, screen-reader readable, and usable in low-bandwidth settings.
- Do not invent asset filenames. Use approved source-named assets where listed; otherwise use placeholders.
