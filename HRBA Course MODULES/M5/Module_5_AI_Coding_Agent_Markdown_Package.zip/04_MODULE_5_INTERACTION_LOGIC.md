# Module 5 Interaction Logic

## Global rules

```text
Module 5 checks, tools, and reflections are formative only.
Certificate eligibility is not calculated in Module 5.
Certificate eligibility remains linked to the final course test with score >= 80%.

Do not expose to learners:
  screen IDs
  block IDs
  source IDs
  QA notes
  reviewer notes
  approval metadata
  implementation metadata

Do not request:
  names
  active cases
  complaint files
  safeguarding/protection details
  unsupported legal claims
  legal documents
  donor proposals
  internal plans
  confidential project documents
  political details
  raw organizational data
  uploads
```

## Required completion logic

```text
Module 5 is complete when:
  module intro viewed
  situation-analysis process viewed
  HRBA situation analysis tool viewed or completed
  assumption-check reflection viewed
  situation-analysis MCQ completed
  legal/policy disclaimer viewed
  standards-use checklist reviewed
  legal/policy scan viewed or completed
  legal/policy MCQ completed
  problem analysis process viewed
  problem reframing tool viewed or completed
  root-cause sorting completed
  problem-statement MCQ completed
  objective qualities viewed
  objective lab viewed or completed
  activity-vs-objective check completed
  activity package process viewed
  activity design canvas viewed or completed
  activity alignment check completed
  risk categories viewed
  risk/mitigation sorting completed
  risk checklist viewed or completed
  risk scenario decision completed
  module summary viewed

Tool outputs and reflections may save privately, but private save/download must not affect certificate eligibility.
```

## Interaction map

| Interaction ID | Lesson | Block ID | Type | Prompt/task | Configuration | Feedback behavior | Completion | Retry | Scoring | Certificate | Portfolio/proof | Safety/privacy | Accessibility |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| INT-M05-01 | 5.1 | M05-L01-B03 | Process | View six situation-analysis questions | Six ordered process steps: issue, affected people, rights/principles, responsibility, root causes, risks. | A strong project begins with careful analysis, not quick assumptions. | All steps opened before continue. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Full text alternative. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-02 | 5.1 | M05-L01-B04 | Tool Activity | Complete HRBA situation analysis note | Fields: issue, rights-holder groups, excluded groups, rights/principles, duty-bearers, barriers, risks. | This is a learning tool, not a public report. | Save or mark complete. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Warn against names/sensitive data. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-03 | 5.1 | M05-L01-B06 | MCQ | Identify HRBA situation analysis focus | A-D options; correct B. | Correct/incorrect feedback as written. | Answer attempted. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Accessible MCQ. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-04 | 5.2 | M05-L02-B02 | Accordion | Explore legal/policy scan elements | Six panels. | A basic scan helps design responsibly; it does not replace legal advice. | All panels viewed. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Screen-reader support. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-05 | 5.2 | M05-L02-B03 | Checklist | Confirm safe standards-use checks | Six checklist items. | Use standards accurately, responsibly, and safely. | Checklist viewed/confirmed. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Printable version. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-06 | 5.2 | M05-L02-B05 | Tool Activity | Complete legal/policy scan | Fields: issue, rights/principles, responsibilities, policy/standard to verify, participation/accountability implication, guidance needed. | Save to portfolio. | Save/complete. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Not legal advice; avoid sensitive claims. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-07 | 5.2 | M05-L02-B06 | MCQ | Select safe use of standards | A-D options; correct C. | Correct/incorrect feedback as written. | Answer attempted. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Accessible MCQ. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-08 | 5.3 | M05-L03-B02 | Sorting | Sort symptom/root cause/rights issue | Six items into three categories. | HRBA problem analysis separates visible symptoms from deeper barriers and accountability gaps. | Complete sorting. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Tap-first alternative. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-09 | 5.3 | M05-L03-B04 | Tool Activity | Reframe problem statement | Fields: original statement, affected groups, excluded groups, rights/principles, barriers, accountability gaps, revised statement. | Rights-based framing should avoid blame and include barriers/responsibility. | Save/complete. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Safe general wording only. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-10 | 5.3 | M05-L03-B06 | MCQ | Select strongest rights-based problem statement | A-D options; correct C. | Correct/incorrect feedback as written. | Answer attempted. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Accessible MCQ. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-11 | 5.4 | M05-L04-B02 | Matching | Match objectives to feedback | Five objective statements matched to feedback categories. | Objectives should guide activities, indicators, and learning. | Complete matching. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Keyboard accessible. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-12 | 5.4 | M05-L04-B03 | Process | View four objective checks | Rights-holder change; inclusion; accountability/responsiveness; measurability. | A good objective is rights-aware and practical. | All steps opened. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Text alternative. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-13 | 5.4 | M05-L04-B04 | Tool Activity | Improve objective | Fields: draft objective, change, inclusion, accountability, evidence, improved objective. | Save to portfolio. | Save/complete. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Avoid risky/unsupported claims. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-14 | 5.4 | M05-L04-B06 | MCQ | Distinguish activity from objective | A-D options; correct A. | Training is an activity; other options describe changes. | Answer attempted. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Accessible MCQ. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-15 | 5.5 | M05-L05-B02 | Tabs | Explore six activity types | Six tabs: information, participation/dialogue, capacity, service/referral, accountability/feedback, evidence/advocacy. | Activities should match analysis and reduce barriers. | All tabs opened. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Accessible tabs. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-16 | 5.5 | M05-L05-B03 | Decision Scenario | Choose strongest activity package | Scenario + options A-D; correct C. | C addresses participation, accessibility, capacity, feedback, and responsibility. | Decision submitted. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Avoid stereotypes; fictional case. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-17 | 5.5 | M05-L05-B04 | Tool Activity | Design HRBA activity package | Fields: objective, activities, participation, inclusion, duty-bearer engagement, accountability, safety, evidence. | Save to portfolio. | Save/complete. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Broad actor categories only. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-18 | 5.5 | M05-L05-B06 | Multiple Response | Identify HRBA activity features | A-E options; correct A,C,D,E. | Attendance alone is not enough. | Answer attempted. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Accessible multi-select. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-19 | 5.6 | M05-L06-B02 | Labeled Graphic | Open common risk categories | Six risk markers. | Risk categories should be identified before implementation. | All markers viewed. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | List fallback. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-20 | 5.6 | M05-L06-B03 | Sorting | Sort risk vs mitigation | Eight items into two categories. | Strong HRBA design identifies risk and builds safer alternatives. | Complete sorting. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | Tap/keyboard alternative. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-21 | 5.6 | M05-L06-B04 | Tool Activity | Complete risk and mitigation checklist | Fields: activity, affected people, exclusion risk, participation risk, data risk, civic risk, expectation risk, mitigation, do-not-collect/share, reviewer. | Save to portfolio. | Save/complete. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | High caution: no active cases or sensitive details. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |
| INT-M05-22 | 5.6 | M05-L06-B05 | Scenario Decision | Select safe evidence response | A-D options; correct C. | Safety, consent, anonymization, and specialized guidance are essential. | Decision submitted. | Allow retry for knowledge checks; tool activities can be edited/resaved; viewed interactions do not need retry. | Formative / completion-based only | No certificate implication; course certificate depends only on final course test score of 80% or above. | Private portfolio support only where tool/reflection output is saved; not practical proof. | No solicitation of personal stories. | Keyboard, tap, screen-reader labels, visible focus; non-drag alternative where relevant. |

## Core behavior rules

### Process and step-list behavior

```text
For process blocks:
  every step must be keyboard focusable or visible in accessible text
  mark complete when all steps opened OR full step list viewed
  no animation is required
```

### Accordion and checklist behavior

```text
For accordion/checklist blocks:
  support keyboard and tap
  checklist review may be saved as completion status
  do not collect sensitive data
  legal/policy checklist must show disclaimer before learner action
```

### Sorting and decision behavior

```text
For sorting/decision checks:
  provide non-drag alternatives where sorting is used
  show option-level feedback
  use “That’s right” or “Good choice” for best responses
  use “Not quite” for weaker responses
  do not use pass/fail language
  no certificate effect
```

### Tool and worksheet behavior

```text
For every project-design tool:
  show purpose and fields before the tool
  provide downloadable template where asset exists
  provide in-platform form/table alternative
  allow private save if portfolio is enabled
  allow download if save is not enabled
  do not require uploads
  do not ask for real donor proposals or confidential project text
  do not affect certificate logic
```

### Reflection behavior

```text
For reflections:
  reflection is optional/private
  show safety helper before free-text
  allow skip without penalty
  save only if learner chooses save
  do not send raw reflection to AI
```

### Knowledge check behavior

```text
For MCQ/MRQ/scenario checks:
  formative only
  option-level feedback required
  no pass/fail language
  no certificate effect
  use “Not quite,” not “Incorrect”
  allow retry if platform supports it
```
