# Module 5 Design and Visual Interaction Specification

## Module title

**Module 5: Applying HRBA in Project Design**

## Design purpose

Module 5 should feel like a practical project-design studio, not a static proposal-writing manual. It should guide local and grassroots CSO practitioners through situation analysis, legal/policy awareness, problem framing, objective design, activity design, and risk mitigation.

The visual experience should support careful thinking before action. It should feel structured, safe, premium, practical, and locally grounded.

## Visual identity

| Use | Color |
|---|---|
| Primary action / active progress | `#3B99D4` |
| Positive accent / completion / growth | `#91C852` |
| Deep heading / navigation text | `#0F172A` |
| Main text | `#111827` |
| Secondary text | `#6B7280` |
| Background | `#F9FAFB` |
| Card background | `#FFFFFF` |
| Border | `#E5E7EB` |
| Warning / safety accent | `#F97316` |
| Critical safety warning only | `#EF4444` |

## Source visual interaction controls

| Specification area | Required rule | Module 5 application | Mobile / low-bandwidth behavior | Safety/legal styling | Completion behavior |
| --- | --- | --- | --- | --- | --- |
| Global visual system | Use DEC blue #3B99D4, accent green #91C852, deep navy #0F172A, light background #F9FAFB, white cards, subtle borders, rounded corners, soft shadows. | Applies to all Module 5 lessons, cards, tools, risk matrix and CTAs. | Single-column cards on mobile; reduce decorative elements on low bandwidth. | Use orange caution callouts for risk/legal disclaimers; do not use alarming red except true critical warning. | Visuals do not control completion alone. |
| Module hero | Use warm project-design workshop image with navy overlay and concise promise card. | Module intro uses module-5-hrba-project-design.jpg. | Crop safely on mobile with readable title; text alternative available. | No recognizable faces/logos/readable text. | Viewed. |
| Process behavior | Use process cards for six HRBA situation-analysis questions. | L5.1 process diagram + step list. | Vertical stack on mobile; no animation required. | Safety note before tool input, not every process card. | All steps opened or step list viewed. |
| Legal/policy accordion | Use accordion with short panels and visible legal-learning disclaimer. | L5.2 standards-use scan. | Accordion keyboard accessible; all content available as expanded text if needed. | Disclaimer styled as navy/orange information card, not legal warning panic box. | All panels opened or text fallback viewed. |
| Problem tree behavior | Use root-cause tree as guided card tool, not complex drawing canvas. | L5.3 problem analysis worksheet. | Stacked prompts on mobile; text alternative. | Avoid blaming or naming groups. | Tool viewed/saved or marked complete. |
| Objective rewrite behavior | Use before/after cards and editable text field. | L5.4 objective lab. | Cards stack; input field large enough for mobile. | Project-document privacy reminder before input. | Rewrite submitted or marked complete. |
| Activity menu | Use tabs/cards for HRBA activity types. | L5.5 activity design menu. | Tabs become accordion/cards on mobile. | No real target names; broad actor categories. | Cards viewed and tool activity completed/marked complete. |
| Risk matrix | Use labeled cards or matrix with text labels for likelihood/impact and mitigation. | L5.6 risk and mitigation tool. | Stacked risk categories on mobile; no horizontal table dependency. | High-caution callout for survivor evidence, safeguarding, civic-space and data risks. | Tool viewed/saved or marked complete. |
| Knowledge checks | Use formative MCQ/multiple response/scenario decision with immediate feedback. | All KCs. | Buttons large and keyboard/tap accessible. | Feedback avoids legal conclusions and sensitive details. | Attempted; retry allowed. |
| Summary | Use output card grid; no certificate language that implies module certification. | Module summary. | Stacked cards; text list fallback. | Certificate rule reminder only: final course test 80%+. | Viewed. |

## Section design rules

| Section | Visual / interaction treatment |
|---|---|
| Module intro | Hero/bridge card with project-design workshop image, promise card, and safety reminder |
| 5.1 HRBA Situation Analysis | Scenario hook, micro-lesson, six-question process, situation-analysis tool, reflection, MCQ |
| 5.2 Legal and Policy Analysis | Legal-learning disclaimer, accordion, safe-use checklist, case example, legal/policy scan, MCQ |
| 5.3 Problem Analysis Through a Rights Lens | Comparison cards, root-cause tree/process, problem reframing tool, sorting, MCQ |
| 5.4 Defining Rights-Based Objectives | Objective-quality cards, objective anatomy graphic, objective lab, checklist, MCQ |
| 5.5 Designing HRBA Activities | Scenario, activity package process, comparison, canvas/tool, reflection, MRQ |
| 5.6 Risk Assessment and Mitigation | Risk categories graphic, sorting, checklist/tool, scenario decision, summary |

## Sensitive design rules

- Avoid images that show recognizable beneficiaries, case files, legal documents, donor proposal pages, or confidential project documents.
- Use fictional local CSO planning scenarios.
- Use orange callouts for legal and risk reminders.
- Use red only for true critical release-blocking warnings, not for learner mistakes.
- Project-design tools should feel private and supportive, not evaluative.

## Mobile behavior

On mobile:

- all layouts become single column;
- navigation collapses to drawer/menu;
- process diagrams become stacked step cards;
- matrices become grouped cards;
- tool forms use short grouped sections;
- CTAs are full width;
- all interactions remain keyboard/tap accessible.

## Feedback states

| State | Design rule |
|---|---|
| Best response | Green accent; text begins “That’s right” or “Good choice” |
| Weaker response | Neutral or soft amber accent; text begins “Not quite” |
| Saved portfolio | Green confirmation; “Saved privately” language |
| Safety reminder | Orange accent; calm protective tone |
| Legal disclaimer | Orange caution card with plain-language boundary |
| Risk warning | Orange caution card unless true critical error |

## Design no-drift rules

The coding agent must not:

- turn Module 5 into a static article;
- turn Module 5 into a generic proposal-writing course;
- remove private tool/portfolio options;
- require real donor proposals or project documents;
- use drag-only interactions;
- imply Module 5 tools/checks affect certificate;
- create public peer exchange;
- use “Incorrect” feedback;
- present legal/policy scan as legal advice;
- ask learners to diagnose real violations;
- request uploads;
- invent asset filenames;
- omit text alternatives for essential visuals.
