# Module 8 Reflection and Portfolio Logic

## Portfolio principle

Module 8 produces private action and organizational-practice tools. These outputs help the learner apply HRBA in advocacy, evidence use, regulatory awareness, internal CSO systems, partnerships, and 90-day planning. They are private by default and not certificate-linked.

## Main Module 8 portfolio/tool outputs

1. P23 — Safe advocacy reflection
2. P24 — Evidence-use checklist
3. Regulatory awareness note
4. P25 — Internal HRBA checklist
5. Partnership practice note
6. P26 — 90-Day HRBA Action Plan

## Portfolio behavior table

| Tool/reflection | Placement | Required status | Visibility | Save behavior | Safety rule | Proof implication | Certificate implication | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| P23 — Safe advocacy reflection | 8.1 | Required learning activity; optional portfolio save | Private by default | Auto-save to learner notes/portfolio if platform supports; learner may skip if uncomfortable. | Use broad issue only; no names, locations, officials, complaints, or active disputes. | No proof implication unless later voluntarily summarized; not certificate requirement. | None; module checks formative only. | Approved |
| P24 — Evidence-use checklist | 8.2 | Required checklist; optional portfolio save | Private by default | Save checklist completion and broad notes; no raw evidence upload. | Use synthetic or anonymized evidence categories only. | No proof implication. | None. | Approved |
| Regulatory awareness note | 8.3 | Required learning note; optional portfolio save | Private by default | Save general note; no legal documents or case details. | This is learning only and not legal advice. | No proof implication. | None. | Approved |
| P25 — Internal HRBA checklist | 8.4 | Required rating/checklist; optional portfolio save | Private by default | Save broad ratings and one improvement action. | No staff names, internal disputes, board records, HR files, complaints, or confidential records. | No proof implication. | None. | Approved |
| Partnership practice note | 8.5 | Required practice note; optional portfolio save | Private by default | Save generic partnership quality note. | No real partners, funders, coalition conflicts, or sensitive power dynamics. | No proof implication. | None. | Approved |
| P26 — 90-Day HRBA Action Plan | 8.6 | Required learning output; optional proof only if enabled | Private by default | Save action plan privately; optional proof submission may use safe summary only. | Use roles not names; avoid sensitive advocacy, legal, regulatory, or organizational details. | Optional practical proof separate from certificate if enabled. | Certificate based only on final course test 80%+. | Approved |

## Final Module 8 portfolio checkpoint

The main integrated checkpoint is the **90-Day HRBA Action Plan**.

### Saved fields

- action priority;
- why the action matters;
- first step;
- responsible role or team;
- support needed;
- timeline;
- safety check;
- progress sign;
- optional private note;
- optional safe proof summary if the platform explicitly enables proof submission.

### Safety helper text

Use before any optional text field:

> Keep this safe and general. Do not include names of officials, community members, staff, partners, survivors, complainants, sensitive organizations, active cases, complaint logs, legal documents, board records, partner agreements, community stories, confidential evidence, political details, raw organizational data, or uploads.

## Save behavior

When the learner saves a Module 8 output:

```text
save:
  module_id = M08
  output_type
  structured selections
  optional private note if entered
  timestamp

do_not_save:
  names
  active cases
  complaint logs
  legal documents
  board records
  partner agreements
  community stories
  confidential evidence
  political details
  raw organizational data
  uploaded files
```

## Optional proof behavior

```text
if optional_proof_enabled:
  allow learner to submit a safe non-sensitive summary only
  show reminder to remove names, locations, officials, complaints, legal/regulatory details, partner disputes, and confidential records
  proof is separate from certificate
  certificate still depends on final course test score >= 80%

if optional_proof_not_enabled:
  show save/download private option only
```

## Deterministic synthesis logic

| Rule ID | Input | Output |
|---|---|---|
| `M8_SYN_01` | safe advocacy reflection | Add to “Safe advocacy decision principle” |
| `M8_SYN_02` | evidence-use checklist | Add to “Responsible evidence-use safeguards” |
| `M8_SYN_03` | regulatory awareness note | Add to “When to pause and seek guidance” |
| `M8_SYN_04` | internal HRBA checklist | Add to “Internal practice improvement area” |
| `M8_SYN_05` | partnership practice note | Add to “Partnership accountability improvement” |
| `M8_SYN_06` | 90-day action plan | Add to “Priority HRBA actions for next 90 days” |
| `M8_SYN_07` | optional private notes | Include only in private export; never in safe-share summary |
| `M8_SYN_08` | skipped saves | Show “Not saved yet — you can return later,” without penalty |

## Visibility rules

| User type | Can see Module 8 portfolio content? |
|---|---|
| Participant | Yes, their own private portfolio |
| Course facilitator | No by default; only safe aggregate or consent-based summary if enabled |
| CSO focal person | No individual notes by default |
| Peer participant | No |
| Donor or external partner | No |
| Admin dashboard | Aggregate tags only, no raw notes/action plans |
| AI service | No raw reflections, checklists, action plans, or private notes |
