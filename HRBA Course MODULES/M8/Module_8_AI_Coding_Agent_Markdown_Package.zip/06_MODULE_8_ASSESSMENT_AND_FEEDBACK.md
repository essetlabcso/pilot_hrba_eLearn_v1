# Module 8 Assessment and Feedback Map

## Module assessment rule

All Module 8 checks are **formative only**. They help participants practice safer HRBA advocacy, responsible evidence use, regulatory awareness, internal HRBA practice, rights-based partnerships, and realistic action planning.

Module 8 checks do **not**:

- issue a certificate;
- unlock a certificate;
- replace the final course test;
- rank the participant;
- rank the CSO;
- require sensitive information;
- require document uploads;
- require real advocacy targets, complaint logs, legal documents, board records, partner agreements, community stories, or confidential evidence.

The course certificate remains linked to the **final course test with a score of 80% or above**.

## Assessment sequence

| Item ID | Lesson | Block ID | Type | Question/prompt | Options/items | Best/correct answer | Source feedback | Status | Certificate implication | Accessibility note | Safety note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KC-M08-01 | 8.1 | M08-L01-B07 | MCQ | Which statement best describes HRBA advocacy? | A) Strong public language regardless of risk. B) Rights-holder voice, safe evidence, duty-bearer responsibility, participation and do-no-harm. C) Avoid accountability because it may be sensitive. D) Donor reporting only. | B | HRBA advocacy seeks accountability while protecting people and using evidence responsibly. | Formative | None; final course test only | Accessible MCQ; no real advocacy details. | E-M08-005; E-M08-006 |
| KC-M08-02 | 8.2 | M08-L02-B05 | Multiple response | Which evidence practices are safer and more rights-based? | A) Anonymized summaries. B) Verify information. C) Share identifiable photos. D) Link evidence to duty-bearer responsibility. E) Use rumors. | A, B, D | Safe evidence is verified, relevant, anonymized where needed, and linked to responsibility. | Formative | None | Accessible multi-select; reinforces no raw data. | E-M08-008; E-M08-011 |
| KC-M08-03 | 8.3 | M08-L03-B05 | MCQ | What should a CSO do when an HRBA action may have legal/regulatory implications? | A) Proceed quickly. B) Stop all rights work. C) Check guidance, document, and seek support. D) Upload confidential legal documents. | C | Responsible HRBA practice includes regulatory awareness, documentation, and qualified support where needed. | Formative | None | Non-legal advice; no confidential docs. | E-M08-009 |
| KC-M08-04 | 8.4 | M08-L04-B05 | MCQ | Why does HRBA matter inside a CSO? | A) CSOs must be perfect. B) Internal participation, inclusion, accountability and learning strengthen external work. C) Internal systems are unrelated. D) It is only a donor label. | B | HRBA inside the CSO strengthens credibility, integrity and practice. | Formative | None | Improvement-focused. | E-M08-004; E-M08-013 |
| KC-M08-05 | 8.5 | M08-L05-B05 | MCQ | Which question is most rights-based when planning collective advocacy? | A) Who gets visibility? B) How fast can we act without consultation? C) Whose voice guides the agenda, who carries risk, and how are partners accountable to rights-holders? D) How can we avoid responsibility? | C | HRBA partnerships pay attention to voice, power, risk and accountability. | Formative | None | No real partner disputes. | E-M08-005; E-M08-013 |
| KC-M08-06 | 8.6 | M08-L06-B06 | MCQ | What makes a 90-day HRBA action plan strong? | A) Many vague changes. B) Few realistic actions linked to participation, inclusion, accountability, safety and rights-based practice. C) Confidential uploads. D) Replaces certificate test. | B | A strong plan is focused, realistic, rights-based, safe and trackable. | Formative | None; action plan is not certificate requirement. | Do not conflate proof with certificate. | E-M08-015 |

# Repaired learner-facing formative checks

## KC-M08-01 — Lesson 8.1

### Question

Which statement best describes HRBA advocacy?

A) Strong public language regardless of risk.
B) Rights-holder voice, safe evidence, duty-bearer responsibility, participation and do-no-harm.
C) Avoid accountability because it may be sensitive.
D) Donor reporting only.

Best response: B

Feedback for A: Not quite. Strong public language without risk assessment can expose people or weaken accountability.
Feedback for B: That’s right. HRBA advocacy combines rights-holder voice, safe evidence, duty-bearer responsibility, participation, and do-no-harm.
Feedback for C: Not quite. HRBA does not avoid accountability; it pursues accountability safely and responsibly.
Feedback for D: Not quite. Donor reporting alone is not rights-based advocacy.

## KC-M08-02 — Lesson 8.2

### Question

Which evidence practices are safer and more rights-based?

A) Anonymized summaries.
B) Verify information.
C) Share identifiable photos.
D) Link evidence to duty-bearer responsibility.
E) Use rumors.

Best responses: A, B, and D

Feedback for A: Good choice. Anonymized summaries can protect people while still communicating evidence.
Feedback for B: Good choice. Verifying information supports accuracy and responsible advocacy.
Feedback for C: Not quite. Identifiable photos can create privacy, consent, dignity, and safety risks.
Feedback for D: Good choice. Linking evidence to responsibility helps advocacy stay focused and accountable.
Feedback for E: Not quite. Rumors can create harm and undermine credibility.

## KC-M08-03 — Lesson 8.3

### Question

What should a CSO do when an HRBA action may have legal/regulatory implications?

A) Proceed quickly.
B) Stop all rights work.
C) Check guidance, document, and seek support.
D) Upload confidential legal documents.

Best response: C

Feedback for A: Not quite. Acting quickly without checking guidance can create avoidable legal, regulatory, or safety risk.
Feedback for B: Not quite. Regulatory awareness does not mean stopping rights work. It means acting carefully and responsibly.
Feedback for C: That’s right. When there may be legal or regulatory implications, check current guidance, document decisions, and seek qualified support.
Feedback for D: Not quite. Do not upload confidential legal documents or case details into the course.

## KC-M08-04 — Lesson 8.4

### Question

Why does HRBA matter inside a CSO?

A) CSOs must be perfect.
B) Internal participation, inclusion, accountability and learning strengthen external work.
C) Internal systems are unrelated.
D) It is only a donor label.

Best response: B

Feedback for A: Not quite. HRBA does not require perfection. It supports continuous improvement.
Feedback for B: That’s right. Internal participation, inclusion, accountability, and learning strengthen external rights-based work.
Feedback for C: Not quite. Internal systems shape how a CSO practices dignity, fairness, participation, and accountability.
Feedback for D: Not quite. HRBA should be a way of working, not only a donor label.

## KC-M08-05 — Lesson 8.5

### Question

Which question is most rights-based when planning collective advocacy?

A) Who gets visibility?
B) How fast can we act without consultation?
C) Whose voice guides the agenda, who carries risk, and how are partners accountable to rights-holders?
D) How can we avoid responsibility?

Best response: C

Feedback for A: Not quite. Visibility alone can reproduce unequal power and does not ensure accountability to rights-holders.
Feedback for B: Not quite. Acting quickly without consultation can increase risk and exclude the people most affected.
Feedback for C: That’s right. Rights-based collective advocacy asks whose voice guides the agenda, who carries risk, and how partners remain accountable to rights-holders.
Feedback for D: Not quite. Partnerships should clarify responsibility, not avoid it.

## KC-M08-06 — Lesson 8.6

### Question

What makes a 90-day HRBA action plan strong?

A) Many vague changes.
B) Few realistic actions linked to participation, inclusion, accountability, safety and rights-based practice.
C) Confidential uploads.
D) Replaces certificate test.

Best response: B

Feedback for A: Not quite. Many vague changes are hard to implement and track.
Feedback for B: That’s right. A strong 90-day plan has a few realistic actions linked to participation, inclusion, accountability, safety, and rights-based practice.
Feedback for C: Not quite. Confidential uploads are not needed and can create risk.
Feedback for D: Not quite. The action plan does not replace the final course test or certify the course.

## Assessment data map

| Assessment/tool | Required saved data | Optional saved data | Do not save |
|---|---|---|---|
| Safe advocacy decision/check | Completion status | Selected response | Real targets, names, complaints, disputes |
| Evidence-use sorting/check | Completion status | Selected categories/responses | Raw evidence, photos, stories, names |
| Regulatory awareness check | Completion status | General private note if saved | Legal documents, case details |
| Internal HRBA check/scan | Completion status | Broad rating and improvement if saved | Staff names, HR files, board records, internal disputes |
| Partnership matching/check | Completion status | Generic practice note if saved | Real partner names or disputes |
| 90-day action plan check | Completion status | Private action plan fields if saved | Confidential plans, sensitive advocacy/legal/regulatory details |
