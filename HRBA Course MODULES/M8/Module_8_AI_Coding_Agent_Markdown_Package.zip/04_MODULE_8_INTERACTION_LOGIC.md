# Module 8 Interaction Logic

## Global rules

```text
Module 8 checks, tools, reflections, and action-plan activities are formative only.
Certificate eligibility is not calculated in Module 8.
Certificate eligibility remains linked to the final course test with score >= 80%.

Do not expose to learners:
  screen IDs
  block IDs
  source IDs
  QA notes
  reviewer notes
  approval metadata
  implementation metadata

Do not request:
  names of officials, community members, staff, partners, survivors, complainants, or sensitive organizations
  active cases
  complaint logs
  legal documents
  board records
  partner agreements
  community stories
  confidential evidence
  political details
  raw organizational data
  uploads
```

## Required completion logic

```text
Module 8 is complete when:
  module introduction viewed
  safe advocacy scenario/explainer/safety statement/decision/checklist/reflection/check completed or viewed
  evidence-use scenario/explainer/sorting/checklist/check completed or viewed
  regulatory awareness disclaimer/accordion/note/check completed or viewed
  internal HRBA scenario/explainer/rating/checklist/check completed or viewed
  partnership scenario/explainer/matching/checklist/check completed or viewed
  90-day action-plan scenario/tool/quality check/optional proof guidance/summary completed or viewed

Tool outputs and reflections may save privately, but private save/download or optional proof submission must not affect certificate eligibility.
```

## Interaction map

| Interaction ID | Lesson | Block ID | Type | Learner task | Configuration/items | Best/correct logic | Feedback behavior | Completion | Retry | Certificate | Portfolio/proof | Safety/privacy | Accessibility |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| INT-M08-01 | 8.1 | M08-L01-B04 | Decision Scenario | Choose safest advocacy path | Options A-D around public advocacy before consultation and risk assessment. | Best answer B. | Correct feedback: consult, verify, anonymize, assess risk. Not quite feedback: explain risks of raw exposure, silence, or sharing without consent. | Complete before continue. | Unlimited retry; formative only. | No certificate implication; prepares for final test. | P23 optional private portfolio. | Fictional scenario only. | Keyboard/tap accessible; no drag. |
| INT-M08-02 | 8.1 | M08-L01-B05 | Checklist | Confirm safe advocacy planning items | 8 checklist items. | No score; all items checked. | Completion message: advocacy is stronger when participatory, safe and accountable. | Check all items. | No scoring. | None. | P23 private. | No sensitive details. | Accessible checklist; PDF alternative. |
| INT-M08-03 | 8.2 | M08-L02-B03 | Sorting Activity | Sort evidence items by safe-use category | Categories: safe summary / anonymize or consent / do not share raw. | Each item assigned to safest category. | Category feedback reinforces consent, anonymization, verification and relevance. | Complete sort before continue. | Unlimited retry; formative. | None. | P24 private. | No raw data. | Tap/keyboard alternative required. |
| INT-M08-04 | 8.2 | M08-L02-B04 | Checklist | Assess responsible evidence use | 8 evidence-use checks. | No score. | Completion message: Safe evidence supports accountability without exposing people. | Check all items. | No scoring. | None. | P24 private. | No identifiable photos/stories. | Accessible checklist/PDF. |
| INT-M08-05 | 8.3 | M08-L03-B02 | Accordion | Review regulatory awareness areas | 6 panels: mandate/registration, governance, implementation, finance/reporting, income generation, public communication/advocacy. | All panels opened. | Each panel gives concise non-legal guidance. | Open all panels. | No scoring. | None. | Regulatory awareness note private. | Learning only; not legal advice. | Screen-reader accessible accordion. |
| INT-M08-06 | 8.3 | M08-L03-B04 | Checklist | Review compliance-sensitive practice | 7 compliance-sensitive checks. | No score. | Completion: Pause, verify, document, and seek qualified support where needed. | Check all items. | No scoring. | None. | Regulatory note private. | No confidential docs. | Accessible checklist/PDF. |
| INT-M08-07 | 8.4 | M08-L04-B01 | Labeled Graphic | Explore internal HRBA practice areas | Labels: governance, inclusion, staff/volunteers, feedback, transparency, learning. | All labels opened. | Each label explains internal HRBA dimension. | Open all markers. | No scoring. | None. | P25 private. | No internal conflict details. | Text alternative required. |
| INT-M08-08 | 8.4 | M08-L04-B03 | Rating Tool | Rate internal HRBA practice | 8 items rated 1–5. | Optional interpretation bands. | Feedback bands: choose priority; strengthen consistency; document and sustain. | Complete all ratings. | No scoring for certificate. | None. | P25 private. | No staff names. | Keyboard and screen-reader accessible. |
| INT-M08-09 | 8.5 | M08-L05-B03 | Matching Activity | Match partnership risks to better practices | 5 risk/improvement pairs. | All pairs correctly matched. | Feedback reinforces power, voice, responsibility and safety. | Complete matching. | Unlimited retry. | None. | Partnership note private. | No real partner disputes. | Tap/keyboard alternative. |
| INT-M08-10 | 8.5 | M08-L05-B04 | Checklist | Check partnership readiness | 8 partnership checks. | No score. | Completion: Rights-based partnership requires shared purpose, voice, role clarity and safe evidence rules. | Check all items. | No scoring. | None. | Partnership note private. | Generic only. | Accessible checklist/PDF. |
| INT-M08-11 | 8.6 | M08-L06-B02 | Tool Activity | Draft 90-day action plan | Fields: priority, why it matters, first action, role/team, support, timeline, safety, progress sign. | Completion when required fields have entries. | Feedback: plan is stronger when realistic, safe, and measurable. | Complete 3–5 priorities recommended. | No scoring. | None; not certificate/proof requirement. | P26 private; optional proof if enabled. | Use roles not names; no sensitive details. | Accessible form and downloadable alternative. |
| INT-M08-12 | 8.6 | M08-L06-B03 | Checklist | Review action-plan quality | 8 quality checks. | No score. | Completion: plan is ready when realistic, rights-based, safe, and trackable. | Check all items. | No scoring. | None. | P26 private. | No confidential uploads. | Accessible checklist. |
| INT-M08-13 | 8.6 | M08-L06-B04 | Assignment Link | Optional save/submit action plan | Show upload only if practical proof enabled; otherwise download/save guidance. | No certificate scoring. | Practical proof is optional and separate from certificate. | Viewed or optional submit. | Not graded for certificate. | No certificate implication; optional proof only. | Raw proof private by default. | Remove sensitive details. | Accessible upload guidance. |

## Core behavior rules

### Safe advocacy decision behavior

```text
For safe advocacy decisions:
  use fictional advocacy scenario only
  learner chooses safest path from options
  feedback explains rights-holder voice, evidence, participation, accountability, do-no-harm, and realistic change
  no names, offices, complaints, or active disputes
```

### Evidence-use sorting behavior

```text
For evidence-use sorting:
  provide non-drag alternatives:
    dropdown
    tap-select cards
    keyboard-selectable category buttons
  categories:
    safe summary
    anonymize or get consent before use
    do not share raw or identifying evidence
  show immediate explanatory feedback
  allow retry
  no certificate effect
```

### Regulatory awareness behavior

```text
For regulatory awareness:
  always show disclaimer:
    this is learning and general regulatory awareness, not legal advice
  do not request legal documents, case details, or confidential records
  learner completes a general note about when to pause, check current guidance, document decisions, and seek qualified support
```

### Internal HRBA practice scan behavior

```text
For internal practice scan:
  use broad organizational areas only
  no staff names, HR files, board records, internal disputes, complaints, or confidential records
  learner rates broad areas and chooses one improvement action
  private by default
```

### Partnership behavior

```text
For partnership and collective action:
  no real partner names, funder disputes, coalition conflicts, or sensitive power dynamics
  matching/checklist uses generic partnership risks and better practices
  feedback emphasizes voice, power, risk sharing, role clarity, fair recognition, and accountability
```

### 90-day action plan behavior

```text
For 90-day action plan:
  learner drafts 3–5 realistic actions
  use roles/teams, not personal names
  avoid sensitive advocacy, legal, regulatory, or organizational details
  optional proof summary may be enabled only as separate feature
  action plan does not replace final test or certificate
```

### Knowledge check behavior

```text
For MCQ/MRQ checks:
  formative only
  option-level feedback required
  no pass/fail language
  no certificate effect
  use “Not quite,” not “Incorrect”
  allow retry if platform supports it
```
