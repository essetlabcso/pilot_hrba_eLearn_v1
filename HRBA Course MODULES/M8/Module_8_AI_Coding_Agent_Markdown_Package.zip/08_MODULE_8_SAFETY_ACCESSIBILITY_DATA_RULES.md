# Module 8 Safety, Accessibility, and Data Rules

## Safety principle

Module 8 has a high safety level because advocacy, civic-space, regulatory awareness, partnerships, internal organizational practice, and evidence use can expose people, organizations, partners, complaints, legal concerns, or confidential plans.

The module must help learners act safely, listen to rights-holders, use evidence responsibly, work with partners fairly, strengthen internal systems, and stay accountable after action.

## Safety rules from source workbook

| Safety rule | Where addressed | Learner-facing wording / implementation rule | Pass condition | Repetition-reduction decision | Status |
| --- | --- | --- | --- | --- | --- |
| Use fictional, generalized or anonymized examples | All lessons | Examples and practice are fictional or broad. Do not enter real names or active cases. | No block asks for real advocacy targets, complaints, legal cases, confidential documents, or sensitive actor names. | Keeps safety visible without repeating long warnings on every block. | Approved |
| No legal advice boundary | 8.3 and regulatory notes | This course supports learning and general regulatory awareness. It does not provide legal advice. For specific matters, check updated guidance or seek qualified support. | Visible before regulatory awareness activity and checklist. | Mandatory disclaimer once at start of lesson, then short reminders. | Approved |
| Civic-space and advocacy safety | 8.1, 8.2, 8.5, 8.6 | Use safe sample evidence only. Avoid naming officials, advocacy targets, political actors, journalists, activists, complainants, survivors, children, community members or sensitive actors. | All advocacy and evidence tools use broad categories and synthetic examples. | Short point-of-risk reminders before tools/reflections. | Approved |
| Evidence and story safety | 8.2 | Evidence should be relevant, accurate, consent-aware, anonymized where needed, dignity-preserving, and used for a clear purpose. | No raw stories, photos, complaints, or personal data requested. | Emphasize the right not to share. | Approved |
| Private by default | All reflections/tools | Reflections, checklists, notes and action-plan outputs are private by default unless the learner explicitly chooses safe optional proof submission. | Portfolio/proof behavior follows Annex 12. | No external visibility unless consented safe summary. | Approved |
| Action-plan privacy | 8.6 | Action plans should use roles, not names, and avoid sensitive advocacy details, confidential documents, regulatory cases, or internal conflicts. | Tool fields are safe and general. | Action plan not required for certificate. | Approved |
| Peer exchange not included in required self-paced build | 16_PEER_EXCHANGE_PLAN | Peer exchange is not in required Module 8 flow; future exchange must be moderated and prompt-limited. | Prevents unsafe sharing. | None for certificate/proof. | Approved |

## Do not request

Never ask learners to submit:

- names of officials, community members, staff, partners, survivors, complainants, or sensitive organizations;
- active cases;
- complaint logs;
- legal documents;
- board records;
- HR files;
- partner agreements;
- community stories;
- confidential evidence;
- political details;
- raw organizational data;
- uploads.

## Safe alternatives

Use:

- fictional examples;
- broad issue categories;
- role/team categories instead of names;
- anonymized or synthetic evidence categories;
- structured choices;
- optional private notes with safety helper text;
- safe non-sensitive summaries where optional proof is enabled.

## Regulatory awareness boundary

Use this before regulatory-awareness activities:

> This course supports learning and general regulatory awareness. It does not provide legal advice. For specific matters, check updated guidance or seek qualified support.

## Advocacy and civic-space safety boundary

Use before advocacy/evidence activities:

> Use safe sample evidence only. Avoid naming officials, advocacy targets, political actors, journalists, activists, complainants, survivors, children, community members, partners, or sensitive actors.

## Privacy rules

| Data type | Default visibility |
|---|---|
| Tool outputs | Private by default |
| Optional reflections | Private by default |
| Advocacy/evidence checklists | Private by default |
| 90-day action plan | Private by default unless optional proof is explicitly enabled |
| Assessment completion | Learner/system only |
| Assessment score/response | Formative only; no certificate effect |
| Admin analytics | Aggregated only, no raw notes/action plans |

## Accessibility and low-bandwidth QA

| Accessibility area | Where addressed | Requirement | Pass condition | Status |
| --- | --- | --- | --- | --- |
| Keyboard access | All interactions | All MCQs, checklists, sorting, matching, accordions, labeled graphics, ratings and forms must be keyboard operable. | Keyboard test passes with visible focus order. | Pass |
| Screen-reader labels | All interactions/tools | Each input, option, checklist item, rating item and feedback message has clear label and state. | Screen-reader test confirms item purpose and completion state. | Pass |
| Alt text | All images | Every image includes concise alt text; decorative images are marked appropriately if any. | Alt text present in asset register and implementation handoff. | Pass |
| Text alternatives | Diagrams, grids, matrices, labeled graphics | Each visual has text equivalent, including safe advocacy grid, regulatory cards, internal system graphic, partnership map and action-plan template. | Essential meaning available without image. | Pass |
| Non-drag alternatives | Sorting/matching activities | Provide list-based or tap-select alternative; drag is not the only method. | Usable on keyboard/tap/mobile. | Pass |
| Accessible tools/PDFs | All worksheets | PDF/XLSX tools must have accessible in-platform alternatives; essential learning must not depend on downloads. | Accessible text/form version exists. | Pass |
| Mobile readability | All lessons | Single-column mobile layout; tables/grids convert to cards; buttons full-width or tap-friendly. | Mobile preview passes. | Pass |
| Low-bandwidth fallback | All media/assets | Images support learning but are not essential; provide text equivalents and downloadable lightweight versions. | Learning complete without images/downloads. | Pass |
| Reduced motion | All animations/interactions | Avoid unnecessary animation; provide reduced-motion behavior for cards/transitions. | Reduced motion setting respected. | Pass |

## AI/data restriction

Raw reflections, optional notes, advocacy plans, evidence-use notes, regulatory notes, partnership notes, action-plan drafts, and portfolio content should not be sent to AI services. If AI is later used for safe summaries, use structured non-sensitive tags or participant-approved safe summaries only.

## Safe helper text

Use before any optional text field or tool output:

> Keep this safe and general. Do not include names of officials, community members, staff, partners, survivors, complainants, sensitive organizations, active cases, complaint logs, legal documents, board records, partner agreements, community stories, confidential evidence, political details, raw organizational data, or uploads.
