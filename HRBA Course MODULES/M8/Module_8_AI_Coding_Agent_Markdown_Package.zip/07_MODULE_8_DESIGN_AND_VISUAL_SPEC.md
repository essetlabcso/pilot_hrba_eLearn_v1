# Module 8 Design and Visual Interaction Specification

## Module title

**Module 8: HRBA in Advocacy and Organizational Practice**

## Design purpose

Module 8 should feel like a safe action-planning studio for local CSOs. It helps learners practice advocacy, evidence use, regulatory awareness, internal organizational strengthening, partnership accountability, and 90-day action planning without exposing people or organizations.

The experience should not feel like a political advocacy manual, legal advisory tool, compliance audit, or public campaign builder. It should feel like guided, ethical, locally grounded HRBA practice.

## Visual identity

| Use | Color |
|---|---|
| Primary action / active progress | `#3B99D4` |
| Positive accent / completion / growth | `#91C852` |
| Deep heading / navigation text | `#0F172A` |
| Main text | `#111827` |
| Secondary text | `#6B7280` |
| Background | `#F9FAFB` |
| Card background | `#FFFFFF` |
| Border | `#E5E7EB` |
| Warning / safety accent | `#F97316` |
| Critical safety warning only | `#EF4444` |

## Source visual interaction controls

| Area | Placement | Specification | Implementation behavior | Status |
| --- | --- | --- | --- | --- |
| Global visual system | All module screens | DEC blue #3B99D4, accent green #91C852, deep navy #0F172A, light background #F9FAFB, white cards, dark text #111827, subtle borders #E5E7EB, rounded corners and soft shadows. | Use premium institutional eLearning style, not static manual or generic LMS. | Approved |
| Safety/warning styling | Safety notes and disclaimers | Use orange warning/info callouts for safety and legal/regulatory learning disclaimer; keep concise. | Do not overuse red unless critical; warnings must be screen-reader labeled. | Approved |
| Safe advocacy decision behavior | 8.1 | Decision cards with clear options, immediate feedback and explanation of why safer option is stronger. | No punitive scoring; formative only. | Approved |
| Evidence-use sorting behavior | 8.2 | Sorting interaction with categories and text-list alternative; feedback explains safe use, anonymization and protection. | Avoid drag-only interaction. | Approved |
| Regulatory awareness accordion | 8.3 | Accordion cards with visible non-legal-advice disclaimer; each card uses plain language and points to qualified support for specific matters. | No definitive legal interpretation. | Approved |
| Internal HRBA scan behavior | 8.4 | Labeled graphic plus rating tool; ratings private and improvement-focused. | Avoid shaming or exposing internal problems. | Approved |
| Partnership matching behavior | 8.5 | Matching activity pairs risks with stronger partnership practices; text alternative for screen readers. | No real partner examples. | Approved |
| Action-plan behavior | 8.6 | Stacked-card action-plan fields on mobile; save private; optional proof separate; progress not tied to certificate. | Use roles, not names. | Approved |

## Lesson design rules

| Lesson | Visual / interaction treatment |
|---|---|
| Safe Advocacy | Scenario, micro-lesson, safety statement, decision cards, checklist, private reflection, MCQ |
| Evidence-Based Civic Engagement | Evidence scenario, safe evidence cards, sorting, responsible evidence checklist, MRQ |
| Regulatory Awareness | Disclaimer callout, accordion/cards, regulatory awareness note, MCQ |
| HRBA Inside the CSO | Internal practice scenario, micro-lesson, rating/scan, checklist, MCQ |
| Partnerships and Collective Action | Scenario, micro-lesson, matching, partnership checklist, MCQ |
| 90-Day HRBA Action Plan | Scenario, action-plan form/tool, quality checklist, optional proof guidance, module summary |

## Sensitive design rules

- Do not show real advocacy targets, officials, partner names, legal documents, board records, complaint logs, community stories, or confidential evidence.
- Use fictional or generic CSO practice examples.
- Use orange callouts for safety and regulatory-learning reminders.
- Use green for safe completion; avoid red failure states for learner feedback.
- Visuals should show planning, reflection, and collaboration without identifiable people or sensitive text.

## Mobile behavior

On mobile:

- all layouts become single column;
- decision cards stack vertically;
- sorting/matching use tap/select alternatives;
- rating scans use labeled controls;
- action-plan form becomes grouped cards;
- CTAs are full width;
- all interactions remain keyboard/tap accessible.

## Feedback states

| State | Design rule |
|---|---|
| Best response | Green accent; text begins “That’s right” or “Good choice” |
| Weaker response | Neutral or soft amber accent; text begins “Not quite” |
| Saved portfolio | Green confirmation; “Saved privately” language |
| Safety reminder | Orange accent; calm protective tone |
| Regulatory disclaimer | Orange/blue callout; plain-language boundary |

## Design no-drift rules

The coding agent must not:

- turn Module 8 into a static article;
- turn Module 8 into a political advocacy manual;
- present regulatory awareness as legal advice;
- ask for real advocacy plans, legal documents, complaints, or partner details;
- make tools download-only;
- use drag-only sorting or matching;
- imply Module 8 tools/checks/action plan affect certificate;
- create required public peer exchange;
- use “Incorrect” feedback;
- invent asset filenames;
- omit text alternatives for essential visuals.
