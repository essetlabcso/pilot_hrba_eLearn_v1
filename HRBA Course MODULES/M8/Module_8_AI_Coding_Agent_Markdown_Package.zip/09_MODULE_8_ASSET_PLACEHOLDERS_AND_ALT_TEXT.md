# Module 8 Asset Placeholders and Alt Text

## Asset rule

Do not invent final asset filenames or paths. Use approved source-named assets where listed. If a file is missing, use a placeholder component with the approved filename reference.

## Visual style

Use CSO Learning Hub / DEC visual identity:

- primary blue: `#3B99D4`
- accent green: `#91C852`
- deep navy: `#0F172A`
- light background: `#F9FAFB`
- white cards
- dark text: `#111827`
- subtle borders: `#E5E7EB`
- rounded corners
- soft shadows

## Asset register

| Asset ID | File name | Asset type | Priority | Used in | Prompt / Build Instruction | Alt text / transcript | Accessibility requirement | Safety requirement | Production status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-M08-001 | module-8-advocacy-organizational-practice.jpg | Module header image | High | Module intro | Realistic Ethiopian/East African CSO team in modest planning room reviewing advocacy and organizational action notes; warm natural light; professional but not corporate; no readable text, logos, banners, UI, or exaggerated posing. | CSO team reviewing advocacy and organizational action notes in a modest meeting room. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No real logos, political symbols, protest imagery, or identifiable sensitive documents. | Approved |
| A-M08-002 | safe-advocacy-planning.jpg | Lesson image | High | 8.1 | Small CSO team reviewing anonymized notes, stakeholder cards, and a risk checklist on a table; no readable text. | CSO staff reviewing advocacy notes and risk considerations together. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No names, official emblems, slogans, protest imagery, or conflict visuals. | Approved |
| A-M08-003 | safe-advocacy-icon.svg | Icon set | Medium | 8.1 | Icon set: verify, consult, anonymize, assess risk, respectful message, follow up; DEC blue and green, orange only for risk. | Icon set showing safe advocacy steps. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | Avoid legal or political symbols that imply official advice. | Approved |
| A-M08-004 | safe-advocacy-checklist.pdf | Downloadable checklist | High | 8.1 | One-page checklist with 8 safe advocacy checks, fillable fields, and clear safety disclaimer. | Safe advocacy planning checklist document. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No fields asking names of officials, complainants, or sensitive details. | Approved |
| A-M08-005 | evidence-based-civic-engagement.jpg | Lesson image | Medium | 8.2 | CSO team sorting anonymized evidence cards, feedback summaries, and policy references in a modest workspace; no readable text. | CSO team reviewing evidence summaries and policy references. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No raw complaints, identifying photos, or real data visible. | Approved |
| A-M08-006 | responsible-evidence-use-checklist.pdf | Downloadable checklist | High | 8.2 | One-page checklist on accuracy, relevance, consent, anonymization, risk, rights-holder voice and duty-bearer ask. | Responsible evidence-use checklist. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | Do not encourage raw data sharing. | Approved |
| A-M08-007 | regulatory-awareness-cso.jpg | Lesson image | Medium | 8.3 | CSO staff reviewing general policy documents and governance notes; no readable text, no official emblems. | CSO staff reviewing organizational and regulatory planning notes. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No legal documents or official insignia visible. | Approved |
| A-M08-008 | compliance-sensitive-practice-checklist.pdf | Downloadable checklist | High | 8.3 | Checklist with non-legal-advice disclaimer; prompts mandate, approval, reporting, finance, risk, qualified support and documentation. | Compliance-sensitive practice checklist. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No legal advice and no request for confidential documents. | Approved |
| A-M08-009 | hrba-inside-cso-systems.svg | Labeled graphic | Medium | 8.4 | Six-node system graphic: governance, inclusion, staff/volunteers, feedback, transparency, learning; DEC blue/green. | Diagram showing internal HRBA practice areas inside a CSO. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No sensitive internal conflict details. | Approved |
| A-M08-010 | internal-hrba-practice-scan.pdf | Worksheet | Medium | 8.4 | Rating worksheet with 8 items and reflection field; private by default; no names. | Internal HRBA practice scan worksheet. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No staff names or confidential disputes. | Approved |
| A-M08-011 | partnerships-collective-action.jpg | Lesson image | Medium | 8.5 | Several CSO representatives in a modest meeting mapping roles and shared responsibilities with paper cards; no logos/readable text. | CSO representatives discussing partnership roles and shared responsibilities. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No real partner logos, political posters, or identifiable documents. | Approved |
| A-M08-012 | rights-based-partnership-checklist.pdf | Downloadable checklist | High | 8.5 | Checklist on shared purpose, rights-holder priorities, roles, respect for smaller actors, transparency, risk, evidence rules and feedback. | Rights-based partnership checklist. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No real partner names or disputes. | Approved |
| A-M08-013 | 90-day-action-plan.jpg | Lesson image | Medium | 8.6 | CSO participant or small team drafting a 90-day action plan in modest workspace; no readable text. | CSO team drafting a practical 90-day action plan. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | No personal data or organizational secrets visible. | Approved |
| A-M08-014 | 90-day-hrba-action-plan-template.xlsx | Worksheet/template | High | 8.6 | Fillable action plan with fields: priority, why it matters, first action, role/team, support, timeline, safety, progress sign. | 90-day HRBA action plan template. | Alt text; text alternative; accessible PDF/XLSX where applicable; low-bandwidth fallback. | Use roles not names; avoid sensitive advocacy details. | Approved |

## Asset implementation rules

- Every image/SVG must include alt text.
- Complex diagrams need text alternatives.
- PDF/XLSX tools must also have in-platform field versions where feasible.
- Do not use photos that identify people or sensitive situations.
- Do not show real officials, partner names, community stories, complaint logs, legal documents, board records, political signage, or confidential evidence.
- Avoid text-heavy images; all essential text must also exist as HTML text.
- If assets are missing, render placeholder cards using the approved filename reference.
