# Module 8 Screen-by-Screen Learner-Facing Content

# Module 8: HRBA in Advocacy and Organizational Practice

# Module introduction

## M8-S0-01 — HRBA in Advocacy and Organizational Practice

Welcome to Module 8. This module helps you apply HRBA when your CSO speaks up, uses evidence, works with partners, strengthens internal systems, and plans next steps. The aim is not louder advocacy. The aim is safer, more participatory, more accountable, and more evidence-informed action.

### Learner action / configuration

Viewed; show roadmap and portfolio preview.

### Feedback / completion message

No scoring.

### Practical output

Module 8 portfolio preview

### Safety note

Do not ask for real advocacy details.

### Accessibility note

Alt text and text roadmap.

### Asset reference

module-8-advocacy-organizational-practice.jpg

### Button

Continue

---


# Lesson 8.1 — HRBA and Safe Advocacy

## M8-S1-01 — A risky advocacy shortcut

A local CSO is concerned that people with disabilities are not accessing a public service. Staff want to post a strong public message that names an office and describes complaints. A team member pauses and asks: Have we verified the facts? Have affected people agreed to this approach? Could details create risk? Is there a safer way to seek accountability?

### Learner action / configuration

Scenario with continue button.

### Feedback / completion message

No scoring.

### Safety note

Fictional scenario only.

### Accessibility note

Image alt text and text version.

### Asset reference

safe-advocacy-planning.jpg

### Button

Continue

---

## M8-S1-02 — What makes advocacy rights-based?

Rights-based advocacy is not simply speaking loudly. It starts with rights-holder priorities, safe evidence, clear responsibility, participation, and do-no-harm. Before choosing a message, ask who is affected, who should participate, who has responsibility, what risks exist, and what realistic change is being requested.

### Learner action / configuration

Viewed.

### Feedback / completion message

No scoring.

### Safety note

No sensitive real examples.

### Accessibility note

Short paragraphs.

### Button

Continue

---

## M8-S1-03 — Safe advocacy principle

Safe advocacy does not mean avoiding accountability. It means choosing responsible strategies that protect people while pursuing rights-based change.

### Learner action / configuration

Orange safety callout.

### Feedback / completion message

No scoring.

### Safety note

Avoid confrontational guidance.

### Accessibility note

Screen-reader label: Safety note.

### Asset reference

safe-advocacy-icon.svg

### Button

Continue

---

## M8-S1-04 — Choose a safer advocacy path

A CSO has collected feedback showing barriers for women with disabilities. What should the team do before public advocacy?

### Learner action / configuration

Options A-D; correct: verify issue, remove identifying details, consult affected groups, assess risks, choose safe engagement path.

### Feedback / completion message

Correct feedback reinforces evidence, participation, consent, risk assessment and accountability.

### Practical output

Safe advocacy reflection

### Safety note

No real advocacy targets.

### Accessibility note

Keyboard/tap accessible.

### Button

Submit and view feedback

---

## M8-S1-05 — Safe advocacy planning checklist

Use the checklist to review whether your advocacy idea is clear, participatory, evidence-informed, safe, realistic, accountable, and followed by report-back. Keep your notes private and general.

### Learner action / configuration

8 checklist items; all checked.

### Feedback / completion message

Completion: your advocacy idea is stronger when it is participatory, safe, and accountable.

### Practical output

P23 — Safe advocacy reflection

### Safety note

No names or sensitive details.

### Accessibility note

Accessible checklist and PDF.

### Asset reference

safe-advocacy-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S1-06 — Your safe advocacy reflection

Think of a general advocacy issue your CSO cares about. What would make it more rights-based and safer?

### Learner action / configuration

Private reflection; save optional.

### Feedback / completion message

No scoring.

### Practical output

P23 — Safe advocacy reflection

### Safety note

Private by default; use broad descriptions only.

### Accessibility note

Labeled private field.

### Buttons

Save privately
Skip for now
Continue

---

## M8-S1-07 — Check your understanding

Which statement best describes HRBA advocacy?

### Question

Which statement best describes HRBA advocacy?

A) Strong public language regardless of risk.
B) Rights-holder voice, safe evidence, duty-bearer responsibility, participation and do-no-harm.
C) Avoid accountability because it may be sensitive.
D) Donor reporting only.

Best response: B

Feedback for A: Not quite. Strong public language without risk assessment can expose people or weaken accountability.
Feedback for B: That’s right. HRBA advocacy combines rights-holder voice, safe evidence, duty-bearer responsibility, participation, and do-no-harm.
Feedback for C: Not quite. HRBA does not avoid accountability; it pursues accountability safely and responsibly.
Feedback for D: Not quite. Donor reporting alone is not rights-based advocacy.

### Safety note

No real details.

### Accessibility note

Accessible MCQ.

### Button

Submit and view feedback

---


# Lesson 8.2 — Evidence-Based Civic Engagement

## M8-S2-01 — When evidence helps — and when it harms

Evidence can support accountability, but raw evidence can also expose people. Safe evidence use means checking relevance and accuracy, using consent-aware summaries, removing identifying details, avoiding rumors, and linking evidence to a clear rights-based ask.

### Learner action / configuration

Viewed case.

### Feedback / completion message

No scoring.

### Safety note

Generic evidence only.

### Accessibility note

Text alternative.

### Asset reference

evidence-based-civic-engagement.jpg

### Button

Continue

---

## M8-S2-02 — Useful evidence for civic engagement

Useful evidence can include safe summaries of feedback, service barriers, participation data, meeting notes, anonymized stories, policy references and learning from implementation. The key is relevance, accuracy, ethics and safety.

### Learner action / configuration

Viewed.

### Feedback / completion message

No scoring.

### Safety note

No real data upload.

### Accessibility note

Short text.

### Button

Continue

---

## M8-S2-03 — Use, summarize, or protect?

Sort sample evidence into three actions: safe to use as a summary, use only after anonymizing or consent, or do not share raw. The goal is to protect people while still making visible the issue and the requested change.

### Learner action / configuration

Categories: safe summary / anonymize or consent / do not share raw. Six sample items.

### Feedback / completion message

Feedback by category.

### Practical output

P24 — Evidence-use checklist

### Safety note

Avoid identifiable data.

### Accessibility note

Non-drag alternative.

### Button

Submit and view feedback

---

## M8-S2-04 — Responsible evidence-use checklist

Before using evidence, check: purpose, accuracy, consent, anonymity, relevance, risk, dignity, duty-bearer responsibility, and report-back. Do not use identifiable photos, raw complaints, or personal stories without clear consent and safety review.

### Learner action / configuration

8 checklist items.

### Feedback / completion message

Completion message reinforces safe evidence.

### Practical output

P24 — Evidence-use checklist

### Safety note

No raw data sharing.

### Accessibility note

Accessible PDF alternative.

### Asset reference

responsible-evidence-use-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S2-05 — Safer evidence practices

Which practices are safer and more rights-based?

### Question

Which evidence practices are safer and more rights-based?

A) Anonymized summaries.
B) Verify information.
C) Share identifiable photos.
D) Link evidence to duty-bearer responsibility.
E) Use rumors.

Best responses: A, B, and D

Feedback for A: Good choice. Anonymized summaries can protect people while still communicating evidence.
Feedback for B: Good choice. Verifying information supports accuracy and responsible advocacy.
Feedback for C: Not quite. Identifiable photos can create privacy, consent, dignity, and safety risks.
Feedback for D: Good choice. Linking evidence to responsibility helps advocacy stay focused and accountable.
Feedback for E: Not quite. Rumors can create harm and undermine credibility.

### Safety note

Reject rumors and identifiable photos.

### Accessibility note

Accessible multi-select.

### Button

Submit and view feedback

---


# Lesson 8.3 — Regulatory Awareness and CSO Responsibilities

## M8-S3-01 — Learning only, not legal advice

This lesson supports general regulatory awareness for learning. It does not provide legal advice. For specific questions about your organization, activities, communications, registration, reporting, finance, or legal duties, check updated official guidance or seek qualified support.

### Learner action / configuration

Required disclaimer before regulatory blocks.

### Feedback / completion message

No scoring.

### Safety note

Mandatory boundary.

### Accessibility note

High contrast warning/info style.

### Button

Continue

---

## M8-S3-02 — Regulatory awareness areas

Review six general areas: mandate/registration, governance, implementation, finance/reporting, income generation, and public communication/advocacy.

### Learner action / configuration

Open all panels.

### Feedback / completion message

Panel feedback gives general learning cues.

### Practical output

Regulatory awareness note

### Safety note

No legal advice.

### Accessibility note

Screen-reader accessible accordion.

### Asset reference

regulatory-awareness-cso.jpg

### Button

Continue

---

## M8-S3-03 — Pause, check, document, seek support

A CSO wants to expand public messaging connected to a rights issue. What is the safest next step if regulatory implications are unclear?

### Learner action / configuration

Best response: pause, check current guidance, document decisions, seek qualified support if needed.

### Feedback / completion message

Feedback stresses awareness not fear or silence.

### Practical output

Regulatory awareness note

### Safety note

No legal case diagnosis.

### Accessibility note

Keyboard accessible.

### Button

Submit and view feedback

---

## M8-S3-04 — Compliance-sensitive practice checklist

Use the note to identify where an HRBA action may require checking mandate, approvals, reporting, finance, communications, risk, or qualified support. Keep it general; do not upload legal documents or confidential records.

### Learner action / configuration

7 checklist items; all checked.

### Feedback / completion message

Completion: pause, verify, document and seek support where needed.

### Practical output

Regulatory awareness note

### Safety note

No legal documents or confidential records.

### Accessibility note

Accessible checklist/PDF.

### Asset reference

compliance-sensitive-practice-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S3-05 — When legal/regulatory implications arise

What should a CSO do when an HRBA action may have legal/regulatory implications?

### Question

What should a CSO do when an HRBA action may have legal/regulatory implications?

A) Proceed quickly.
B) Stop all rights work.
C) Check guidance, document, and seek support.
D) Upload confidential legal documents.

Best response: C

Feedback for A: Not quite. Acting quickly without checking guidance can create avoidable legal, regulatory, or safety risk.
Feedback for B: Not quite. Regulatory awareness does not mean stopping rights work. It means acting carefully and responsibly.
Feedback for C: That’s right. When there may be legal or regulatory implications, check current guidance, document decisions, and seek qualified support.
Feedback for D: Not quite. Do not upload confidential legal documents or case details into the course.

### Safety note

Non-legal advice.

### Accessibility note

Accessible MCQ.

### Button

Submit and view feedback

---


# Lesson 8.4 — HRBA Inside the CSO

## M8-S4-01 — HRBA inside the CSO

Explore six internal practice areas: governance, inclusion, staff and volunteers, feedback, transparency, and learning. Rate broad practice areas privately, then choose one realistic improvement for the next 90 days.

### Learner action / configuration

Six markers: governance, inclusion, staff/volunteers, feedback, transparency, learning; open all markers.

### Feedback / completion message

No scoring; each marker explains an internal HRBA practice area.

### Practical output

P25 — Internal HRBA checklist

### Safety note

No internal conflict details.

### Accessibility note

Text alternative.

### Asset reference

hrba-inside-cso-systems.svg

### Button

Continue

---

## M8-S4-02 — Internal practice builds credibility

An organization does not need to be perfect to apply HRBA. It needs practical habits of listening, explaining, documenting, including, protecting and improving.

### Learner action / configuration

Viewed.

### Feedback / completion message

No scoring.

### Safety note

Improvement-focused.

### Accessibility note

Short plain language.

### Button

Continue

---

## M8-S4-03 — Internal HRBA practice scan

Rate broad areas from 1–5 and choose one improvement action.

### Learner action / configuration

8 rating items; completion requires all ratings and one optional improvement note.

### Feedback / completion message

Feedback bands: choose priority; strengthen consistency; document and sustain.

### Practical output

P25 — Internal HRBA checklist

### Safety note

Private; no staff names.

### Accessibility note

Accessible ratings.

### Asset reference

internal-hrba-practice-scan.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S4-04 — One internal improvement

Which internal HRBA practice could your CSO strengthen in the next 90 days?

### Learner action / configuration

Private reflection.

### Feedback / completion message

No scoring.

### Practical output

P25 — Internal HRBA checklist

### Safety note

Private by default.

### Accessibility note

Text field.

### Buttons

Save privately
Skip for now
Continue

---

## M8-S4-05 — Why HRBA matters inside a CSO

Why does HRBA matter inside a CSO?

### Question

Why does HRBA matter inside a CSO?

A) CSOs must be perfect.
B) Internal participation, inclusion, accountability and learning strengthen external work.
C) Internal systems are unrelated.
D) It is only a donor label.

Best response: B

Feedback for A: Not quite. HRBA does not require perfection. It supports continuous improvement.
Feedback for B: That’s right. Internal participation, inclusion, accountability, and learning strengthen external rights-based work.
Feedback for C: Not quite. Internal systems shape how a CSO practices dignity, fairness, participation, and accountability.
Feedback for D: Not quite. HRBA should be a way of working, not only a donor label.

### Safety note

No internal accusations.

### Accessibility note

Accessible MCQ.

### Button

Submit and view feedback

---


# Lesson 8.5 — Partnerships and Collective Action

## M8-S5-01 — The partnership that left people out

Several CSOs plan a joint advocacy action. The agenda is set by the largest partner and smaller community-based groups are asked only to mobilize participants. Who carries the risk and whose voice shapes the agenda?

### Learner action / configuration

Scenario viewed.

### Feedback / completion message

No scoring.

### Safety note

No real partner names.

### Accessibility note

Alt text.

### Asset reference

partnerships-collective-action.jpg

### Button

Continue

---

## M8-S5-02 — What makes partnership rights-based?

Partnerships and collective action should not silence smaller actors, extract community voice, or make the highest-profile organization dominate. Rights-based partnership asks: whose voice guides the agenda, who carries the risk, how decisions are made, how evidence is protected, and how partners report back to rights-holders.

### Learner action / configuration

Viewed.

### Feedback / completion message

No scoring.

### Safety note

No partner disputes.

### Accessibility note

Short text.

### Button

Continue

---

## M8-S5-03 — Partnership risk and better practice

Match common partnership risks with stronger HRBA practices: unclear roles with role clarity, extractive evidence with consent-aware summaries, top-down agenda with rights-holder priorities, unequal visibility with fair recognition, and weak report-back with shared accountability.

### Learner action / configuration

5 risk/improvement pairs.

### Feedback / completion message

Feedback reinforces voice, power and accountability.

### Practical output

Partnership practice note

### Safety note

Generic only.

### Accessibility note

Tap/keyboard accessible.

### Button

Submit and view feedback

---

## M8-S5-04 — Rights-based partnership checklist

Check shared purpose, rights-holder priorities, role clarity, respect for smaller actors, transparency, safe evidence rules, risk sharing and report-back.

### Learner action / configuration

All items checked.

### Feedback / completion message

Completion message.

### Practical output

Partnership practice note

### Safety note

No real partner disputes.

### Accessibility note

Accessible checklist/PDF.

### Asset reference

rights-based-partnership-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S5-05 — Planning collective action

Which question is most rights-based when planning collective advocacy?

### Question

Which question is most rights-based when planning collective advocacy?

A) Who gets visibility?
B) How fast can we act without consultation?
C) Whose voice guides the agenda, who carries risk, and how are partners accountable to rights-holders?
D) How can we avoid responsibility?

Best response: C

Feedback for A: Not quite. Visibility alone can reproduce unequal power and does not ensure accountability to rights-holders.
Feedback for B: Not quite. Acting quickly without consultation can increase risk and exclude the people most affected.
Feedback for C: That’s right. Rights-based collective advocacy asks whose voice guides the agenda, who carries risk, and how partners remain accountable to rights-holders.
Feedback for D: Not quite. Partnerships should clarify responsibility, not avoid it.

### Safety note

No real partner details.

### Accessibility note

Accessible MCQ.

### Button

Submit and view feedback

---


# Lesson 8.6 — Preparing Your 90-Day HRBA Action Plan

## M8-S6-01 — From course learning to action

A CSO team has finished most of the HRBA course. They want to change everything at once. Their facilitator asks them to choose a few realistic actions they can start safely in the next 90 days.

### Learner action / configuration

Viewed.

### Feedback / completion message

No scoring.

### Safety note

No names or confidential plans.

### Accessibility note

Alt text.

### Asset reference

90-day-action-plan.jpg

### Button

Continue

---

## M8-S6-02 — Draft your 90-day HRBA action plan

Choose three to five realistic actions. For each action, write the priority, why it matters, first step, responsible role or team, support needed, timeline, safety check, and progress sign. Use roles, not personal names. Keep the plan private unless your organization chooses to share it.

### Learner action / configuration

Fields: priority, why it matters, first action, responsible role/team, support, timeline, safety, progress sign.

### Feedback / completion message

Feedback: plan is stronger when realistic, safe and measurable.

### Practical output

P26 — 90-Day HRBA Action Plan

### Safety note

Use roles not names; no sensitive details.

### Accessibility note

Accessible in-platform alternative.

### Asset reference

90-day-hrba-action-plan-template.xlsx/pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S6-03 — Action plan quality check

Check focus, rights-holder relevance, inclusion, accountability, safety, realism, ownership by role, and progress sign.

### Learner action / configuration

All items checked.

### Feedback / completion message

Completion: plan is ready when realistic, rights-based, safe, and trackable.

### Practical output

P26 — 90-Day HRBA Action Plan

### Safety note

Private by default.

### Accessibility note

Accessible checklist.

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S6-04 — Save or submit action plan if enabled

If practical proof is enabled, learner may submit a safe, non-sensitive summary. Otherwise they download/save the plan privately.

### Learner action / configuration

No certificate scoring.

### Feedback / completion message

Practical proof optional and separate from certificate.

### Practical output

P26 — 90-Day HRBA Action Plan

### Safety note

Raw proof private; remove sensitive details.

### Accessibility note

Accessible upload guidance.

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M8-S6-05 — What to carry forward

You have practiced safer advocacy, responsible evidence use, regulatory awareness, internal HRBA systems, partnership accountability, and 90-day action planning. The next step is to consolidate your learning, complete the final course test, and decide how your CSO can apply HRBA safely and realistically.

### Learner action / configuration

Viewed; link to final course closing/final test module.

### Feedback / completion message

No scoring.

### Safety note

Do not imply action plan certifies course.

### Accessibility note

Text summary.

### Button

Continue

---


## Module 8 next step

You have practiced safer advocacy, responsible evidence use, regulatory awareness, internal HRBA systems, partnership accountability, and 90-day action planning.

Your next step is to consolidate your course learning and prepare for the final course test. Remember: the 90-day action plan is a practical learning output. It does not replace the final course test or certify course completion.

### Button

Continue to course closing and final test
