# Module 8 Overview

## Course

**Applying the Human Rights-Based Approach (HRBA) in CSO Practice**

## Module title

**Module 8: HRBA in Advocacy and Organizational Practice**

## Module role

Module 8 is a practical action-and-institutional-practice module. It helps participants apply HRBA when their CSO speaks up, uses evidence, works with partners, strengthens internal systems, and prepares a realistic 90-day action plan.

## Recommended duration

**90–120 minutes**

## Primary audience

Local and grassroots CSO staff, programme teams, advocacy and community engagement staff, MEAL/accountability staff, managers, partnership focal persons, and CSO leaders.

## Main learner shift

From:

> “Advocacy means speaking strongly and acting quickly.”

To:

> “Rights-based advocacy and organizational practice require rights-holder voice, safe evidence, participation, accountability, regulatory awareness, internal integrity, fair partnerships, and realistic follow-through.”

## Module learning outcomes

By the end of Module 8, participants should be able to:

1. choose safer, more rights-based advocacy strategies;
2. use evidence responsibly for civic engagement and accountability;
3. recognize when regulatory awareness and qualified support are needed;
4. apply HRBA principles inside CSO governance, systems, and team practice;
5. assess partnerships and collective action using voice, power, risk, role clarity, and accountability;
6. draft a safe, realistic 90-day HRBA action plan;
7. keep portfolio/tool outputs private unless safe optional proof submission is explicitly enabled.

## Approved lesson sequence

1. **Safe Advocacy**
2. **Evidence-Based Civic Engagement**
3. **Regulatory Awareness**
4. **HRBA Inside the CSO**
5. **Partnerships and Collective Action**
6. **90-Day HRBA Action Plan**

## Main portfolio/tool outputs

- P23 — Safe advocacy reflection
- P24 — Evidence-use checklist
- Regulatory awareness note
- P25 — Internal HRBA checklist
- Partnership practice note
- P26 — 90-Day HRBA Action Plan

## Assessment rule

All Module 8 checks are formative only. They support practice and review. They do not issue a certificate, unlock a certificate, rank participants, or rank CSOs.

## Certificate rule

Certificate eligibility remains tied to the final course test with a score of **80% or above**.

## Safety level

High because advocacy, civic-space, regulatory awareness, partner dynamics, internal organizational practice, and evidence use can expose people, organizations, cases, disputes, or sensitive plans.

## Privacy rule

Tool outputs, optional notes, action-plan drafts, checklists, and reflection outputs are private by default.

## Sensitive data rule

Do not ask learners to provide names of officials, community members, staff, partners, survivors, complainants, sensitive organizations, active cases, complaint logs, legal documents, board records, partner agreements, community stories, confidential evidence, political details, raw organizational data, or uploads.
