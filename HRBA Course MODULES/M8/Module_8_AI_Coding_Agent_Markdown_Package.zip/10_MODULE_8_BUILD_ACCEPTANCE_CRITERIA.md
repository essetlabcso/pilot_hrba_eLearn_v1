# Module 8 Build Acceptance Criteria

## Source acceptance criteria

| Criteria area | Acceptance criterion | Status |
| --- | --- | --- |
| Module structure | Six lessons appear in order: Safe Advocacy; Evidence-Based Civic Engagement; Regulatory Awareness; HRBA Inside the CSO; Partnerships and Collective Action; 90-Day HRBA Action Plan. | Pass |
| Learner-facing content | Clear plain language for local CSO participants; no internal IDs, evidence notes, source tables, or implementation comments in learner-facing blocks. | Pass |
| HRBA accuracy | Content is grounded in rights-holder voice, duty-bearer responsibility, participation, accountability, transparency, non-discrimination, empowerment, legality and do-no-harm. | Pass |
| Safe advocacy quality | Advocacy guidance is rights-based, evidence-informed, participatory, accountable and safety-aware; it is not a political advocacy manual. | Pass |
| Evidence-use quality | Evidence-use activities emphasize relevance, verification, consent, anonymization, dignity, purpose limitation and safe summary use. | Pass |
| Regulatory boundary | Regulatory-awareness lesson includes visible non-legal-advice disclaimer and avoids legal diagnosis/advice. | Pass |
| Internal HRBA practice | Internal systems scan covers governance, inclusion, staff/volunteers, feedback, transparency and learning without exposing internal disputes. | Pass |
| Partnership/collective action | Partnership activities address power, role clarity, rights-holder voice, transparency, risk sharing, and report-back. | Pass |
| Action-plan quality | 90-day plan is realistic, safe, role-based, trackable and private by default; it prepares but does not replace course closing/final action-plan consolidation. | Pass |
| Assessment/certificate | All Module 8 checks are formative; certificate is based only on final course test score of 80% or above. | Pass |
| Proof/portfolio separation | Portfolio tools and optional proof are separate from certificate completion; raw proof private by default. | Pass |
| Safety/privacy | No prompts request real names, officials, advocacy targets, legal cases, community stories, safeguarding records, confidential documents, or civic-space risks. | Pass |
| Assets | All expected assets have purpose, filename/status, alt text, low-bandwidth alternative and safety constraints. | Pass |
| Accessibility | Keyboard, screen-reader, alt text, text alternatives, non-drag alternatives, mobile and low-bandwidth rules are specified. | Pass |
| Implementation readiness | Build handoff and coding prompts are deterministic and include plan-first, verification and evidence pack requirements. | Pass |

## Additional clean-package acceptance checks

| Check | Pass condition |
|---|---|
| Clean content only | Learner-facing build excludes QA history, source inventories, evidence packs, change logs, approval locks, and internal reviewer notes. |
| Approved title | Module title is “HRBA in Advocacy and Organizational Practice.” |
| Approved sequence | Six lessons appear in approved order: Safe Advocacy; Evidence-Based Civic Engagement; Regulatory Awareness; HRBA Inside the CSO; Partnerships and Collective Action; 90-Day HRBA Action Plan. |
| Correct screen count | 33 learner-facing screens/blocks are represented. |
| Feedback wording | Weaker responses use “Not quite,” not “Incorrect.” |
| Certificate integrity | No Module 8 check, tool, worksheet, checklist, action plan, optional proof, or reflection affects certificate eligibility. |
| 80% rule | Learner copy states certificate is linked to final course test score of 80% or above. |
| Portfolio privacy | Tool outputs, checklists, action-plan drafts, and optional notes are private by default. |
| No sensitive data | No screen asks for officials, community members, staff, partners, survivors, complainants, sensitive organizations, active cases, complaint logs, legal documents, board records, partner agreements, community stories, confidential evidence, political details, uploads, or raw data. |
| Regulatory boundary | Regulatory-awareness content is learning and general awareness only, not legal advice. |
| Advocacy safety | Advocacy guidance is evidence-informed, participatory, accountable, do-no-harm, and safety-aware. |
| Optional proof separation | Optional proof, if enabled, is separate from certificate and must use safe non-sensitive summaries only. |
| Peer exchange excluded | No required peer exchange or public sharing appears in the build. |
| Accessibility | All interactions are keyboard/tap accessible and screen-reader friendly. |
| Low bandwidth | Essential learning does not depend on heavy media, PDFs, uploads, or external embeds. |
| Asset control | Source-named assets are preserved; missing assets remain placeholders. |
| Metadata hidden | Learners do not see screen IDs, block IDs, source IDs, QA notes, or implementation metadata. |
