# Module 4 Asset Placeholders and Alt Text

## Asset rule

Do not invent final asset filenames or paths. Use approved source-named assets where listed. If a file is missing, use a placeholder component with the approved filename reference.

## Visual style

Use CSO Learning Hub / DEC visual identity:

- primary blue: `#3B99D4`
- accent green: `#91C852`
- deep navy: `#0F172A`
- light background: `#F9FAFB`
- white cards
- dark text: `#111827`
- subtle borders: `#E5E7EB`
- rounded corners
- soft shadows

## Asset register

| Asset ID | Filename | Type | Placement | Purpose | Style/specification | Alt text | Safety/privacy note | Accessibility / low-bandwidth |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-M04-001 | module-4-power-exclusion-header.jpg | Image | Module intro | Module hero showing stakeholder mapping | Warm documentary-style, local CSO team mapping stakeholders, no identifiable faces/logos/text. | CSO team reviewing a stakeholder map during a planning session. | No recognizable faces, no readable sensitive text. | Alt text and text alternative. |
| A-M04-002 | rights-holder-identification-community-map.jpg | Image | 4.1 opening | Rights-holder identification scene | Local CSO facilitator/team reviewing community map. | CSO team reviewing a community map to identify affected groups. | No identifiable vulnerable people. | Alt text required. |
| A-M04-003 | rights-holder-identification-lens.svg | Diagram | 4.1 labeled graphic | Five-lens rights-holder diagram | DEC blue/green markers. | Diagram showing five lenses for identifying rights-holders. | No sensitive data. | Text alternative for all markers. |
| A-M04-004 | rights-holder-list-worksheet.pdf | Worksheet | 4.1 tool | Rights-holder list worksheet | Accessible worksheet with fields matching tool activity. | Worksheet for listing rights-holder groups and barriers. | Warn users not to include names. | Accessible PDF/in-platform form. |
| A-M04-005 | duty-bearer-responsibility-meeting.jpg | Image | 4.2 opening | Duty-bearer role discussion | Local meeting discussing responsibilities and referral pathways. | People in a meeting discussing roles and responsibilities. | Avoid real government identifiers. | Alt text required. |
| A-M04-006 | respect-protect-fulfil-accordion-icons.svg | Icon set | 4.2 accordion | Respect/protect/fulfil icons | Three simple icons with text labels handled by platform. | Icons representing respect, protect, and fulfil responsibilities. | No risk. | Do not rely on icon alone. |
| A-M04-007 | duty-bearer-map-worksheet.pdf | Worksheet | 4.2 tool | Duty-bearer map worksheet | Accessible worksheet with actor categories and safety considerations. | Worksheet for mapping duty-bearers and responsible actors. | Use role categories when sensitive. | Accessible PDF/in-platform form. |
| A-M04-008 | claims-obligations-capacity-table.xlsx | Template | 4.3 tool | Claims/obligations/capacity table | Simple spreadsheet template with fictional example row. | Spreadsheet template for claims, obligations, and capacity gaps. | No real case data. | Accessible table headings. |
| A-M04-009 | capacity-gap-feedback-case.jpg | Image | 4.3 case | Feedback case image | CSO staff reviewing anonymized feedback categories. | CSO staff reviewing feedback categories during a learning meeting. | No real complaint data. | Alt text required. |
| A-M04-010 | community-consultation-power-dynamics.jpg | Image | 4.4 opening | Power dynamics consultation | Respectful consultation scene showing varied participation dynamics. | Community consultation where some participants speak and others listen. | Avoid exploitative portrayal. | Alt text required. |
| A-M04-011 | consultation-exclusion-hotspot.svg | Interactive diagram | 4.4 hotspot | Consultation exclusion hotspot scene | Illustrated meeting with six hotspot markers. | Diagram of a community consultation with markers for possible exclusion barriers. | Fictional scene. | Text alternative for all hotspots. |
| A-M04-012 | power-exclusion-checklist.pdf | Checklist | 4.4 checklist | Power and exclusion checklist | Printable checklist with attendance/voice/risk/info/feedback questions. | Checklist for reviewing power and exclusion in participation processes. | No personal data. | Accessible PDF/in-platform checklist. |
| A-M04-013 | intersectionality-practical-panels.svg | Diagram | 4.5 accordion | Intersectionality panels | Card diagram covering overlapping barriers. | Cards showing different types of overlapping participation barriers. | Avoid stereotyping. | Text alternative required. |
| A-M04-014 | intersectional-barriers-training-case.jpg | Image | 4.5 case | Training barrier case image | Local livelihood training setting, respectful and modest. | Participants attending a local training session with a facilitator. | No pity/deficit imagery. | Alt text required. |
| A-M04-015 | intersectional-inclusion-barrier-scan.pdf | Worksheet | 4.5 tool | Inclusion barrier scan | Accessible worksheet for barrier categories and adjustments. | Worksheet for scanning inclusion barriers in a CSO activity. | No identifiers. | Accessible PDF/in-platform form. |
| A-M04-016 | hrba-stakeholder-mapping-process.svg | Diagram | 4.6 process | Six-step stakeholder mapping process | Process diagram in DEC colors. | Six-step process for HRBA stakeholder mapping. | No risk. | Text alternative required. |
| A-M04-017 | stakeholder-power-interest-safety-matrix.svg | Diagram/matrix | 4.6 matrix | Power-interest-safety matrix | Four-quadrant matrix with safety overlay. | Matrix showing stakeholder influence, support, and safety considerations. | Civic-space caution. | Text alternative required. |
| A-M04-018 | hrba-stakeholder-map-template.xlsx | Template | 4.6 tool | Stakeholder map template | Spreadsheet template with RH/DB/allies/blockers/risk/engagement fields. | Template for mapping HRBA stakeholders and safe engagement options. | No sensitive actors in sample. | Accessible table headings. |
| A-M04-019 | module-4-summary-cards.svg | Summary visual | 4.6 summary | Module recap cards | Six cards for rights-holders, duty-bearers, claims/obligations, capacity gaps, power/exclusion, stakeholder map. | Summary cards for Module 4 learning points. | No risk. | Text equivalent required. |

## Asset implementation rules

- Every image/SVG must include alt text.
- Complex diagrams need text alternatives.
- PDF/XLSX worksheets must also have in-platform field versions.
- Do not use photos that identify vulnerable people or sensitive situations.
- Do not show readable confidential documents, real logos, political signage, or sensitive text.
- Avoid text-heavy images; all essential text must also exist as HTML text.
- If assets are missing, render placeholder cards using the approved filename reference.
