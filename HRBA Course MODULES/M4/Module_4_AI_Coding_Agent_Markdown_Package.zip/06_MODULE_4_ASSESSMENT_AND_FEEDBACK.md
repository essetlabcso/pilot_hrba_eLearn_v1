# Module 4 Assessment and Feedback Map

## Module assessment rule

All Module 4 checks are **formative only**. They help participants practice HRBA analysis and prepare for later modules.

Module 4 checks do **not**:

- issue a certificate;
- unlock a certificate;
- replace the final course test;
- rank the participant;
- rank the CSO;
- require sensitive information;
- require document uploads;
- require real stakeholder maps, complaint files, safeguarding information, legal disputes, or confidential organizational data.

The course certificate remains linked to the **final course test with a score of 80% or above**.

## Assessment sequence

| Item/check ID | Lesson | Type | Question/prompt | Options/expected response | Best/correct answer | Feedback | Formative status | Certificate implication | Accessibility note | Safety note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KC-M04-01 | 4.1 | MCQ | Which question best reflects rights-holder analysis? | A. How many people can we reach quickly?; B. Which groups are affected, excluded, or facing different barriers?; C. Which activity is easiest to report?; D. Which group is most visible? | B | That’s right: HRBA asks who is affected, excluded, and facing barriers. Not quite: rights-holder analysis goes beyond reach and visibility. | Formative | None; prepares for final test domain | Accessible MCQ | No sensitive data. |
| APP-M04-01 | 4.1 | Tool activity | Create rights-holder list. | Completion-based; no right/wrong score. | Completion | A good list becomes specific, inclusive, and safe. | Formative/application | No certificate implication | Accessible form + PDF | Use categories only. |
| KC-M04-02 | 4.2 | MCQ | Which statement best describes a duty-bearer? | A service recipient; actor with responsibility; international body only; donor only. | Actor with responsibility | Duty-bearers are responsible actors and may need capacity support. | Formative | None | Accessible MCQ | No sensitive data. |
| APP-M04-02 | 4.2 | Matching | Match actors to HRBA roles. | Rights-holders; primary duty-bearer; service-level actor; influencing actor; CSO role; resource actor. | All correct | Role clarity helps constructive engagement. | Formative | No certificate implication | Tap/keyboard alternative | Fictional actors only |
| APP-M04-03 | 4.2 | Tool activity | Map duty-bearers and responsible actors. | Actor category fields and safe engagement opportunity. | Completion | Duty-bearer map helps engage the right actors safely. | Formative/application | No certificate implication | Accessible worksheet | Use actor categories if sensitive. |
| KC-M04-03 | 4.3 | Multiple response | Which are capacity gap examples? | A info access; B response protocol; C inaccessible venue; D awareness solves all; E low trust. | A,B,C,E | Capacity gaps include information, systems, access, and trust. Awareness alone may be insufficient. | Formative | None | Accessible multiple response | No sensitive data. |
| APP-M04-04 | 4.3 | Sorting | Sort capacity gaps. | Rights-holder; duty-bearer; shared/system. | Configured by item | Capacity gaps are barriers, not personal failings. | Formative | None | Non-drag alternative | Avoid stigmatizing groups. |
| APP-M04-05 | 4.3 | Tool table | Complete claims/obligations/capacity table. | Nine fields. | Completion | Clarifies what should change, who is involved, and how CSO can support. | Formative/application | No certificate implication | Accessible table | No active case details. |
| KC-M04-04 | 4.4 | MCQ | Which statement best reflects HRBA power analysis? | A attendance means participation; B asks who speaks/decides/silent/absent/risk; C national only; D avoid participation. | B | HRBA looks at voice, decision power, silence, absence, and risk. | Formative | None | Accessible MCQ | No sensitive data. |
| APP-M04-06 | 4.4 | Hotspot | Spot exclusion risks in consultation scene. | Six hotspots. | Completion | Participation is not only invitation; conditions matter. | Formative | None | Text-list alternative | Fictional scene. |
| KC-M04-05 | 4.5 | MCQ | What does intersectional analysis help a CSO do? | Assume same experience; notice overlapping barriers; avoid groups; replace consultation. | Notice overlapping barriers | Intersectional analysis helps identify overlapping barriers. | Formative | None | Accessible MCQ | No sensitive identities. |
| APP-M04-07 | 4.5 | Decision activity | Choose rights-based inclusion plan. | Correct plan adjusts timing/access/formats/safe spaces/feedback. | B | Rights-based inclusion changes conditions of participation. | Formative | No certificate implication | Keyboard accessible | Avoid stereotypes. |
| APP-M04-08 | 4.5 | Tool activity | Complete inclusion barrier scan. | Barrier categories and adjustments. | Completion | Open-to-all is not accessible-to-all. | Formative/application | No certificate implication | Accessible worksheet | No identifiers. |
| KC-M04-06 | 4.6 | Multiple response | What should an HRBA stakeholder map include? | A RHs; B DBs; C excluded groups; D power/risk/safe engagement; E only donor/project team. | A,B,C,D | Map includes affected groups, responsible actors, exclusion, power, risks, and safe engagement. | Formative | None | Accessible multiple response | No sensitive data. |
| APP-M04-09 | 4.6 | Tool activity | Complete HRBA stakeholder map. | Fields: issue, RH, excluded, DB, actors, allies, blockers, risks, safe engagement, next step. | Completion | Stakeholder map bridges analysis and action. | Formative/application | No certificate implication | Accessible XLSX/PDF/form | Use role categories for sensitive issues. |


# Repaired learner-facing feedback patterns

## KC-M04-01 — Rights-holder analysis

Question: Which question best reflects rights-holder analysis?

A. How many people can we reach quickly?  
B. Which groups are affected, excluded, or facing different barriers?  
C. Which activity is easiest to report to the donor?  
D. Which group is most visible in existing meetings?

Best response: B

Feedback for A: Not quite. Reach matters, but rights-holder analysis asks who is affected, excluded, or facing different barriers, not only how many people can be reached quickly.  
Feedback for B: That’s right. HRBA asks who is affected, excluded, and facing barriers.  
Feedback for C: Not quite. Reporting matters, but the rights-holder lens starts with people, barriers, voice, and safety.  
Feedback for D: Not quite. Visible groups may not be the most affected or the most excluded.

## KC-M04-02 — Duty-bearer role

Question: Which statement best describes a duty-bearer in HRBA?

A. Any person who receives CSO services.  
B. An actor with responsibilities.  
C. Only an international body.  
D. Only a donor.

Best response: B

Feedback for A: Not quite. A person receiving support may be a rights-holder, not necessarily a duty-bearer.  
Feedback for B: That’s right. Duty-bearers are actors with responsibilities; they may also need capacity support.  
Feedback for C: Not quite. Duty-bearers can include local, service-level, institutional, and other responsible actors, not only international bodies.  
Feedback for D: Not quite. Donors may influence resources, but they are not the only duty-bearers or responsible actors.

## KC-M04-03 — Capacity gap examples

Question: Which are examples of capacity gaps that may affect rights-based change? Select all that apply.

A. Rights-holders lack information about how to use a feedback channel.  
B. A service provider has no clear response protocol.  
C. A venue is inaccessible for some participants.  
D. Awareness training solves every barrier.  
E. People do not trust that feedback will be answered safely.

Best responses: A, B, C, and E

Feedback for A/B/C/E: That’s right. Capacity gaps can include information, systems, access, and trust barriers.  
Feedback for D: Not quite. Awareness can help, but it rarely solves every barrier by itself.

## KC-M04-04 — Power analysis

Question: Which statement best reflects HRBA power analysis?

A. Attendance means participation.  
B. HRBA asks who speaks, who decides, who stays silent, who is absent, who controls information, and who may face risk.  
C. Power analysis is only needed at national level.  
D. CSOs should avoid participation because it can be complicated.

Best response: B

Feedback for A: Not quite. Attendance is not the same as meaningful, safe, and influential participation.  
Feedback for B: That’s right. HRBA looks at voice, decision power, silence, absence, information, and risk.  
Feedback for C: Not quite. Power can shape participation in local meetings, trainings, assessments, and feedback systems.  
Feedback for D: Not quite. HRBA encourages safer and better-designed participation, not avoidance.

## KC-M04-05 — Intersectional analysis

Question: What does intersectional analysis help a CSO do?

A. Assume all people in a group have the same experience.  
B. Notice overlapping barriers that affect participation, access, safety, and voice.  
C. Avoid working with groups that face barriers.  
D. Replace consultation with assumptions.

Best response: B

Feedback for A: Not quite. Intersectional analysis helps avoid assuming that one group label explains everyone’s experience.  
Feedback for B: That’s right. It helps identify overlapping barriers that affect participation, access, safety, and voice.  
Feedback for C: Not quite. The goal is to improve access and participation, not avoid groups facing barriers.  
Feedback for D: Not quite. Intersectional analysis should improve consultation and participation, not replace them.

## KC-M04-06 — Stakeholder map components

Question: What should an HRBA stakeholder map include? Select all that apply.

A. Affected rights-holder groups.  
B. Duty-bearers and responsible actors.  
C. Excluded or less-heard groups.  
D. Power, influence, risks, and safe engagement options.  
E. Only the donor and project team.

Best responses: A, B, C, and D

Feedback for A/B/C/D: That’s right. HRBA stakeholder mapping includes affected groups, responsible actors, exclusion, power, risks, and safe engagement options.  
Feedback for E: Not quite. A stakeholder map that includes only the donor and project team misses rights-holders, duty-bearers, exclusion, power, risk, and engagement options.


## Assessment data map

| Assessment/tool | Required saved data | Optional saved data | Do not save |
|---|---|---|---|
| Rights-holder check | Completion status | Selected answer | Personal examples, names, real cases |
| Duty-bearer check | Completion status | Selected answer | Real actor names, political details |
| Matching/sorting activities | Completion status | Selected matches/categories and attempts | Sensitive stakeholder details |
| Capacity-gap table | Completion status if completed in platform | Private worksheet fields if saved | Active case details or complaint files |
| Power/exclusion hotspot and checklist | Completion/review status | Selected improvement if saved | Identifiable participants or local tensions |
| Inclusion decision and scan | Completion status | Private scan fields if saved | Sensitive identity details |
| Stakeholder map | Completion status if completed in platform | Private map fields if saved | Names, active advocacy targets, political details |
