# Module 4 Build Acceptance Criteria

## Source acceptance criteria

| Criteria area | Acceptance criterion | Verification method | Pass condition | Status |
| --- | --- | --- | --- | --- |
| Module structure | Six lessons appear in approved order, with module intro and summary. | Route/course player shows Module 4 correctly. | Pass | Approved |
| Content quality | Learner text is practical, clear, locally grounded, and not manual-like. | Review 09_FINAL_CONTENT and implementation preview. | Pass | Approved |
| HRBA accuracy | Rights-holder/duty-bearer, claims/obligations, capacity gaps, power/exclusion, and stakeholder mapping reflect EU/OHCHR/UN sources. | Compare with evidence sheet. | Pass | Approved |
| Ethiopia-local relevance | Scenarios are plausible for local/grassroots CSO work without unsafe specificity. | Scenario review. | Pass | Approved |
| Power/exclusion quality | Power analysis includes voice, silence, absence, risk, information, decision power, and safe entry points. | Lesson 4.4 and 4.6 review. | Pass | Approved |
| Intersectionality quality | Gender, disability, youth/age, poverty/location, language and overlapping barriers are handled respectfully. | Lesson 4.5 review. | Pass | Approved |
| Interaction quality | Every lesson includes purposeful interaction with feedback and completion behavior. | 13_INTERACTION_LOGIC. | Pass | Approved |
| Assessment/certificate | All Module 4 checks are formative; certificate remains final course test ≥80%. | Assessment and build handoff. | Pass | Approved |
| Proof/portfolio separation | Tools and reflections may be private portfolio supports but are not proof or certificate requirements. | 20_REFLECTION_PORTFOLIO. | Pass | Approved |
| Safety/privacy | No names, active cases, legal disputes, political details, complaint files, safeguarding details, confidential records, beneficiary/staff lists. | 21_SAFETY_PRIVACY and tool fields. | Pass | Approved |
| Asset readiness | Asset register, filenames, alt text, safety rules, and generation prompts are complete and approved for implementation. | 17 and 18 sheets. | Pass | Approved |
| Accessibility | Alt text, text alternatives, keyboard/tap, non-drag alternatives, hotspot list, mobile-readable tools, low-bandwidth fallback. | 22_ACCESSIBILITY_QA. | Pass | Approved |
| Mobile/low-bandwidth | Single-column readable layout; essential content remains without downloads/images. | Course player preview. | Pass | Approved |
| Final learner cleanup | Learner-facing screens do not include internal IDs, evidence tables, source notes, reviewer comments, or implementation notes. | Preview check. | Pass | Approved |

## Additional clean-package acceptance checks

| Check | Pass condition |
|---|---|
| Clean content only | Learner-facing build excludes QA history, source inventories, evidence packs, change logs, approval locks, and internal reviewer notes. |
| Approved title | Module title is “Rights-Holders, Duty-Bearers, Power, and Exclusion.” |
| Approved sequence | Six lessons appear in approved order, with module intro and summary. |
| Correct screen count | 38 learner-facing screens/blocks are represented. |
| Feedback wording | Weaker responses use “Not quite,” not “Incorrect.” |
| Certificate integrity | No Module 4 check, tool, worksheet, or reflection affects certificate eligibility. |
| 80% rule | Learner copy states certificate is linked to final course test score of 80% or above. |
| Portfolio privacy | Tool outputs, stakeholder maps, and optional notes are private by default. |
| No sensitive data | No screen asks for names, real stakeholder maps, active cases, complaints, safeguarding details, legal disputes, political details, confidential records, beneficiary/staff lists, uploads, or raw data. |
| Legal-learning boundary | Duty-bearer/obligation content is learning guidance, not legal advice. |
| Peer exchange excluded | No required peer exchange or public stakeholder-map sharing appears in the build. |
| Accessibility | All interactions are keyboard/tap accessible and screen-reader friendly. |
| Low bandwidth | Essential learning does not depend on heavy media, PDFs, or external embeds. |
| Asset control | Source-named assets are preserved; missing assets remain placeholders. |
| Metadata hidden | Learners do not see screen IDs, block IDs, source IDs, QA notes, or implementation metadata. |
