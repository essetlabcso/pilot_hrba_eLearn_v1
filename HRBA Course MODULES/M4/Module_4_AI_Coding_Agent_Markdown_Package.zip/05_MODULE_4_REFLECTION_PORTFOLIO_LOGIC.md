# Module 4 Reflection and Portfolio Logic

## Portfolio principle

Module 4 produces a set of private learning tools that help the learner build a safer HRBA analysis before action. These outputs are private by default, not graded, not certificate-linked, and not used to rank participants or CSOs.

## Main Module 4 portfolio/tool outputs

1. Rights-holder list
2. Duty-bearer map
3. Claims, obligations, and capacity gaps table
4. Power and exclusion reflection
5. Inclusion barrier scan
6. HRBA stakeholder map

## Portfolio behavior table

| Reflection/tool | Placement | Required status | Visibility | Save behavior | Skip behavior | Portfolio implication | Proof implication | Certificate implication | Safety rule |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Rights-holder list | 4.1 | Required interaction; optional save | Private by default | Save draft if platform supports portfolio; downloadable alternative | Skip save allowed after completing interaction | Portfolio output P04-01 if enabled | No proof implication | No certificate implication | Use categories only; no names. |
| Duty-bearer map | 4.2 | Required interaction; optional save | Private by default | Save/download | Skip save allowed | P04-02 if enabled | No proof implication | No certificate implication | Use actor categories if sensitive. |
| Claims/obligations/capacity table | 4.3 | Required interaction; optional save | Private by default | Save/download | Skip save allowed | P04-03 if enabled | No proof implication | No certificate implication | No active case details. |
| Power and exclusion reflection | 4.4 | Optional reflection | Private by default | Optional save to notes/portfolio | Skip allowed without penalty | P04-04 if enabled | No proof implication | No certificate implication | Avoid identifiable participants/groups. |
| Inclusion barrier scan | 4.5 | Required interaction; optional save | Private by default | Save/download | Skip save allowed | P04-05 if enabled | No proof implication | No certificate implication | No identifiers or sensitive identity details. |
| HRBA stakeholder map | 4.6 | Required interaction; optional save | Private by default | Save/download | Skip save allowed | P04-06 if enabled | No proof implication | No certificate implication | No names, political details, or active advocacy targets. |

## Final Module 4 portfolio checkpoint

The main integrated checkpoint is the **HRBA stakeholder map**.

### Saved fields

- broad rights issue;
- rights-holder groups;
- excluded or less-heard groups;
- duty-bearer categories;
- responsible/influencing actor categories;
- allies or supportive actors;
- blockers or resistance risks, using broad categories only;
- power/influence level;
- interest/support level;
- safety considerations;
- safe engagement option;
- first practical next step;
- optional private note.

### Safety helper text

Use before any optional text field:

> Keep this safe and general. Do not include names, real stakeholder maps, active cases, complaint files, safeguarding details, legal disputes, political details, confidential records, beneficiary/staff lists, or raw organizational data.

## Save behavior

When the learner saves a Module 4 output:

```text
save:
  module_id = M04
  output_type
  structured selections
  optional private note if entered
  timestamp

do_not_save:
  real names
  active cases
  complaint files
  legal disputes
  safeguarding details
  political details
  confidential records
  beneficiary/staff lists
  uploaded files
```

## Deterministic synthesis logic

| Rule ID | Input | Output |
|---|---|---|
| `M4_SYN_01` | rights-holder list | Add to “Groups affected or missing from the analysis” |
| `M4_SYN_02` | duty-bearer map | Add to “Actors with responsibility or influence” |
| `M4_SYN_03` | capacity table | Add to “Capacity gaps affecting change” |
| `M4_SYN_04` | power/exclusion reflection | Add to “Participation and power risks to consider” |
| `M4_SYN_05` | inclusion barrier scan | Add to “Intersectional barriers and adjustments” |
| `M4_SYN_06` | stakeholder map | Add to “Safe engagement options and next steps” |
| `M4_SYN_07` | optional private notes | Include only in private export; never in safe-share summary |
| `M4_SYN_08` | skipped saves | Show “Not saved yet — you can return later,” without penalty |

## Carry-forward logic

| Later module | How Module 4 portfolio data is reused |
|---|---|
| Module 5 — Applying HRBA in Project Design | Use rights-holder, duty-bearer, capacity-gap, and power/exclusion analysis as the basis for problem/objective design. |
| Module 6 — Implementation and Adaptive Practice | Use stakeholder map and safe engagement options to guide participation and implementation decisions. |
| Module 7 — HRBA in MEAL and Evidence Use | Use missing voices, information gaps, and power risks to design safer evidence and feedback questions. |
| Module 9 — Course Closing and 90-Day Action Plan | Use safe next steps as candidates for the 90-day HRBA action plan. |

## Visibility rules

| User type | Can see Module 4 portfolio content? |
|---|---|
| Participant | Yes, their own private portfolio |
| Course facilitator | No by default; only safe aggregate or consent-based summary if enabled |
| CSO focal person | No individual notes by default |
| Peer participant | No |
| Donor or external partner | No |
| Admin dashboard | Aggregate tags only, no private notes |
| AI service | No raw reflections, maps, worksheet entries, or private notes |
