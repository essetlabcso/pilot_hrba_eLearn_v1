# Module 4 Interaction Logic

## Global rules

```text
Module 4 checks, tools, and reflections are formative only.
Certificate eligibility is not calculated in Module 4.
Certificate eligibility remains linked to the final course test with score >= 80%.

Do not expose to learners:
  screen IDs
  block IDs
  source IDs
  QA notes
  reviewer notes
  approval metadata
  implementation metadata

Do not request:
  real names
  real stakeholder maps
  active cases
  complaint files
  safeguarding/protection details
  legal disputes
  political details
  confidential records
  beneficiary or staff lists
  raw organizational data
  uploads
```

## Required completion logic

```text
Module 4 is complete when:
  module intro viewed
  rights-holder lens interaction completed
  rights-holder check completed
  respect/protect/fulfil accordion completed
  actor-role matching completed
  duty-bearer check completed
  capacity-gap sorting completed
  capacity-gap check completed
  power/exclusion hotspot completed
  power/exclusion checklist reviewed
  power-analysis check completed
  intersectionality accordion completed
  inclusion decision activity completed
  intersectionality check completed
  stakeholder mapping process completed
  power-interest-safety matrix viewed
  stakeholder map check completed
  module summary viewed

Tool outputs and reflections may be recommended or required interactions, but private save/download must not affect certificate eligibility.
```

## Interaction map

| Interaction ID | Lesson | Type | Prompt/question | Configuration/options | Completion/retry | Feedback behavior | Scoring | Portfolio/proof | Safety/privacy | Accessibility |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| INT-M04-001 | 4.1 | Labeled graphic | Open markers to explore rights-holder identification lens. | Five markers with text content. | Completion after all markers opened. | Completion message reinforces specificity, inclusion, and safety. | Not scored | None | No names; categories only. | Keyboard/tap and text alternative. |
| INT-M04-002 | 4.1 | Tool activity | Create rights-holder list. | Issue; directly affected groups; excluded groups; barriers; participation adjustments; learning gaps. | Completion/save draft. | Encouragement; no right/wrong scoring. | Not scored | Private portfolio P04-01 if enabled | Use broad categories only. | In-platform and downloadable alternatives. |
| INT-M04-003 | 4.1 | MCQ | Choose best rights-holder analysis question. | A/B/C/D; correct B. | One answer; immediate feedback; retry allowed. | Correct/incorrect feedback. | Formative | None | No sensitive data. | Accessible MCQ. |
| INT-M04-004 | 4.2 | Accordion | Open respect/protect/fulfil panels. | Three panels with examples. | Completion after all panels opened. | Panel-level reinforcement. | Not scored | None | Not legal advice. | Screen-reader accessible. |
| INT-M04-005 | 4.2 | Matching | Match actor to HRBA role. | Six actor-role pairs. | Correct all or retry. | Roles can overlap; explain logic. | Formative | Optional | Fictional actors. | Tap/keyboard alternative. |
| INT-M04-006 | 4.2 | Tool activity | Map duty-bearers and responsible actors. | Actor categories, responsibilities, engagement opportunity, safety. | Completion/save draft. | Duty-bearer map helps engage right actors. | Not scored | Private portfolio P04-02 if enabled | Use categories if sensitive. | Accessible worksheet. |
| INT-M04-007 | 4.3 | Tool table | Complete claims/obligations/capacity table. | Nine-column table. | Completion/save draft. | Clarifies change, responsibility, and support. | Not scored | Private portfolio P04-03 | No active case details. | Accessible table; no horizontal-only layout on mobile. |
| INT-M04-008 | 4.3 | Sorting | Sort capacity gaps. | Rights-holder; duty-bearer; shared/system. | Correct/partial with retry. | Capacity gaps are barriers, not personal failings. | Formative | None | Avoid stigmatizing groups. | Non-drag alternative. |
| INT-M04-009 | 4.3 | Multiple response | Identify capacity gap examples. | Correct A,B,C,E. | Immediate feedback; retry allowed. | Correct/partial feedback. | Formative | None | No sensitive data. | Accessible multiple response. |
| INT-M04-010 | 4.4 | Hotspot | Spot exclusion risks in consultation scene. | Six hotspots: time, venue, language, seating, public speaking, note-taking. | Open all hotspots. | Participation is not only invitation. | Not scored | None | Fictional scene. | Text-list alternative. |
| INT-M04-011 | 4.4 | Checklist | Review power/exclusion questions. | 10 checklist items. | All marked reviewed. | Supports safer consultation design. | Not scored | Private/local output optional | Do not collect sensitive individuals. | Accessible checklist. |
| INT-M04-012 | 4.4 | Private reflection | Improve one participation moment. | Short answer; optional save. | Skip allowed. | Small design changes can reduce exclusion. | Not scored | Private reflection P04-04 optional | No names or sensitive groups. | Private by default. |
| INT-M04-013 | 4.5 | Accordion | Explore intersectionality panels. | Six panels covering practical barriers. | Open all panels. | Reinforces overlapping barriers. | Not scored | None | Avoid sensitive identities. | Screen-reader accessible. |
| INT-M04-014 | 4.5 | Decision activity | Choose most rights-based inclusion plan. | Correct B. | Answer with feedback; retry allowed. | Equal invitation is not equitable access. | Formative | None | Avoid stereotypes. | Keyboard accessible. |
| INT-M04-015 | 4.5 | Tool activity | Complete inclusion barrier scan. | Barrier categories and adjustments. | Completion/save draft. | Open-to-all is not accessible-to-all. | Not scored | Private portfolio P04-05 | No personal identifiers. | Downloadable worksheet. |
| INT-M04-016 | 4.6 | Process | Review six stakeholder mapping steps. | Six steps. | Complete process. | Links analysis to action. | Not scored | None | Avoid sensitive naming. | Text alternative. |
| INT-M04-017 | 4.6 | Interactive matrix | Explore power-interest-safety lens. | Four quadrants plus safety overlay. | Viewed/all quadrants. | Engagement strategy depends on influence/support/risk. | Not scored | None | High-risk issues require caution. | Text alternative; no color-only meaning. |
| INT-M04-018 | 4.6 | Tool activity | Complete HRBA stakeholder map. | RH, DB, allies, blockers, risks, safe engagement, next step. | Completion/save draft. | Map bridges analysis and action. | Not scored | Private portfolio P04-06 | Use role categories; avoid political details. | Accessible template. |
| INT-M04-019 | 4.6 | Multiple response | Identify stakeholder map components. | Correct A,B,C,D. | Immediate feedback; retry allowed. | Correct/partial feedback. | Formative | None | No sensitive data. | Accessible multiple response. |

## Core behavior rules

### Labeled graphic and hotspot behavior

```text
For all labeled graphics and hotspots:
  every marker must be keyboard focusable
  every marker must have text label and explanation
  provide full text-list alternative
  do not rely on hover
  mark completed when all markers are opened OR accessible text alternative is viewed
```

### Accordion behavior

```text
For respect/protect/fulfil and intersectionality panels:
  allow keyboard/tap expansion
  panel content must be in the DOM or accessible to screen readers
  mark completed when all panels are opened OR accessible full text alternative is viewed
```

### Matching and sorting behavior

```text
For matching and sorting:
  provide non-drag alternative:
    dropdown
    tap-select cards
    keyboard-selectable category buttons
  show immediate feedback
  allow retry
  use “Good choice” or “That’s right” for best matches
  use “Not quite” for weaker matches
  do not use red failure-only state
```

### Tool and worksheet behavior

```text
For every tool:
  show purpose and fields before the tool
  provide downloadable template where asset exists
  provide in-platform form/table alternative
  allow private save if portfolio is enabled
  allow download if save is not enabled
  do not require uploads
  do not require real examples
  do not require names or sensitive actor details
  do not affect certificate logic
```

### Reflection behavior

```text
For reflections:
  reflection is optional/private
  show safety helper before any free-text field
  allow skip without penalty
  save only if learner chooses save
  do not send raw reflection to AI
```

### Knowledge check behavior

```text
For MCQ/MRQ/decision checks:
  formative only
  option-level feedback required
  no pass/fail language
  no certificate effect
  use “Not quite,” not “Incorrect”
  allow retry if platform supports it
```
