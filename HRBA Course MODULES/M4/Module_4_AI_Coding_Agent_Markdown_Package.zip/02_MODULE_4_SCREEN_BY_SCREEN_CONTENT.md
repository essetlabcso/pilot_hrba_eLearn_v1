# Module 4 Screen-by-Screen Learner-Facing Content

# Module 4: Rights-Holders, Duty-Bearers, Power, and Exclusion

## Module introduction

Welcome to Module 4.

In the previous modules, you explored HRBA foundations, human rights in everyday CSO work, and HRBA principles in practice. Now you will practice one of the most important HRBA skills: analyzing who is affected, who has responsibilities, who has influence, who may be excluded, and where capacity gaps prevent rights from being realized.

This module helps you move from general statements like “the community needs support” to clearer analysis: which rights-holder groups are affected, which duty-bearer categories should respond, what claims and obligations exist, what power relations shape the issue, and how your CSO can engage safely and constructively.

### Safety reminder

Use fictionalized or general examples. Do not include names, active cases, complaint details, confidential records, political details, or sensitive local power information.


# Module Intro

## M4-S0-01 — Rights-Holders, Duty-Bearers, Power, and Exclusion

Welcome to Module 4. In the previous modules, you explored HRBA foundations, everyday rights, and HRBA principles. Now you will practice one of the most important HRBA skills: analyzing who is affected, who has responsibilities, who has influence, who may be excluded, and where capacity gaps prevent rights from being realized. This module helps you move from general statements like “the community needs support” to clearer analysis: which rights-holder groups are affected, which duty-bearer categories should respond, what claims and obligations exist, what power relations shape the issue, and how your CSO can engage safely and constructively.

### Learner action / configuration

Viewed; continue button enabled after text is viewed.

### Safety note

No sensitive names or active cases.

### Asset reference

module-4-power-exclusion-header.jpg

### Button

Continue

---


# 4.1 Identifying Rights-Holders

## M4-S1-01 — Who is affected — and who is missing?

A CSO is preparing a project to improve access to public services. The first draft says: “The project will support vulnerable community members.” During review, one team member asks: “Which groups are we actually talking about? Who is directly affected? Who is indirectly affected? Who is less heard? Who might face additional risks if we involve them carelessly?” This is the first step in rights-holder analysis: becoming specific enough to include people who are often invisible in general project language.

### Learner action / configuration

Display scenario with image and short reflective question.

### Safety note

Use broad population categories only.

### Asset reference

rights-holder-identification-community-map.jpg

### Button

Continue

---

## M4-S1-02 — Rights-holders are not a generic group

In HRBA, rights-holders are people or groups who have rights and legitimate claims. A rights-holder is not only someone who receives support. Rights-holders have dignity, voice, agency, and the right to participate in decisions that affect them. For CSOs, the practical question is not only “Who benefits from our project?” It is also: Who is affected? Who is excluded? Who faces barriers? Whose voice is missing? Who may experience harm if we design poorly?

### Learner action / configuration

Viewed.

### Safety note

Avoid beneficiary language.

### Button

Continue

---

## M4-S1-03 — Rights-holder identification lens

Use five lenses: directly affected people; indirectly affected people; excluded or less-heard groups; higher-risk groups; and organized voices that may help explain shared concerns. A strong rights-holder list does not expose people. It helps the CSO design safer and more inclusive participation.

### Learner action / configuration

Open all markers: directly affected, indirectly affected, excluded/less-heard, higher-risk, organized voice.

### Feedback / completion message

After all markers: stronger analysis becomes specific, inclusive, and safe.

### Safety note

No names; categories and barriers only.

### Asset reference

rights-holder-identification-lens.svg

### Button

Continue

---

## M4-S1-04 — Create a rights-holder list

Choose one issue your CSO works on. Complete a rights-holder list using general descriptions only. Start broad, then become more specific.

### Learner action / configuration

Fields: issue; directly affected groups; excluded groups; additional barriers; participation adjustments; what we still need to learn.

### Feedback / completion message

Good analysis becomes more rights-based when it becomes more specific, inclusive, and safe.

### Safety note

Use broad categories; no identifiable sensitive details.

### Asset reference

rights-holder-list-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M4-S1-05 — Who might be missing?

Think about one project or activity your CSO has implemented or planned. Which group may have been under-represented, unheard, or affected differently? What might you do differently next time to hear from them safely?

### Learner action / configuration

Optional private save.

### Feedback / completion message

Noticing who is missing is a core HRBA skill. The goal is not blame; the goal is better inclusion.

### Safety note

No names or sensitive details.

### Buttons

Save privately
Skip for now
Continue

---

## M4-S1-06 — Check your understanding

Which question best reflects rights-holder analysis?

### Learner action / configuration

A. How many people can we reach quickly? B. Which groups are affected, excluded, or facing different barriers? C. Which activity is easiest to report to the donor? D. Which group is most visible in existing meetings?

### Feedback / completion message

Best response: B. HRBA asks who is affected, excluded, and facing barriers — not only who is easiest to reach.

### Safety note

No sensitive data.

### Button

Submit and view feedback

---


# 4.2 Identifying Duty-Bearers

## M4-S2-01 — Who has responsibility?

A youth group tells a CSO that young people are excluded from local planning meetings. The CSO could respond by organizing a youth awareness session. That may help, but HRBA asks more: who has responsibility to ensure inclusive decision-making? Which institution, committee, service actor, or responsible role can remove barriers? Who needs capacity, information, incentives, or accountability to respond?

### Learner action / configuration

Viewed.

### Safety note

Avoid naming real officials or political actors.

### Asset reference

duty-bearer-responsibility-meeting.jpg

### Button

Continue

---

## M4-S2-02 — Duty-bearers have responsibilities

Duty-bearers are actors with responsibilities to respect, protect, and fulfil rights. Public institutions are often primary duty-bearers. Other actors may also influence whether people can enjoy their rights, such as service providers, school leaders, community committees, employers, CSO leaders, customary structures, private actors, or networks. HRBA does not mean blaming one actor. It means clarifying responsibilities so CSO action can be constructive, realistic, and accountable.

### Learner action / configuration

Viewed.

### Safety note

Learning only; not legal advice.

### Button

Continue

---

## M4-S2-03 — Three types of duty-bearer responsibility

Open each panel: Respect — avoid interfering with rights or creating barriers. Protect — prevent others from violating rights or causing harm. Fulfil — take positive steps so people can enjoy rights, access services, participate, and seek remedy.

### Learner action / configuration

Open all panels before continue.

### Feedback / completion message

Duty-bearer responsibilities help clarify constructive engagement.

### Safety note

Avoid legal overclaiming.

### Asset reference

respect-protect-fulfil-accordion-icons.svg

### Button

Continue

---

## M4-S2-04 — Match the actor to the role

Match each actor to the most likely role in a local CSO scenario about inclusive access to education.

### Learner action / configuration

Pairs: girls with disabilities → rights-holders; district education office → primary duty-bearer; school leadership → service-level actor; parent association → influencing stakeholder; CSO → facilitator/accountability actor; donor → resource/influencing actor.

### Feedback / completion message

Roles can overlap, but HRBA starts by clarifying affected groups and responsible actors.

### Safety note

Fictional actors only.

### Button

Submit and view feedback

---

## M4-S2-05 — Map duty-bearers and responsible actors

Return to the issue you selected. Identify actors who have responsibilities, influence, or practical ability to remove barriers.

### Learner action / configuration

Fields: issue; primary duty-bearer; service-level actors; local decision actors; informal/community influence actors; CSO role; constructive engagement opportunity; safety consideration.

### Feedback / completion message

A good duty-bearer map helps your CSO engage the right actors with the right message at the right time.

### Safety note

Use actor categories if sensitive.

### Asset reference

duty-bearer-map-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M4-S2-06 — Check your understanding

Which statement best describes a duty-bearer in HRBA?

### Learner action / configuration

A. Any person who receives CSO services. B. An actor with responsibilities. C. Only an international body. D. Only a donor.

### Feedback / completion message

Best response: B. Duty-bearers are responsible actors; they may also need capacity support.

### Safety note

No sensitive data.

### Button

Submit and view feedback

---


# 4.3 Claims, Obligations, and Capacity Gaps

## M4-S3-01 — The HRBA bridge

HRBA connects three things: what rights-holders can legitimately claim, what duty-bearers should do, and what capacity gaps make change difficult.

### Learner action / configuration

Viewed.

### Safety note

No legal diagnosis.

### Button

Continue

---

## M4-S3-02 — Capacity gaps exist on both sides

HRBA connects three questions: what can rights-holders legitimately claim; what should duty-bearers do; and what capacity gaps make change difficult? Rights-holders may lack information, confidence, safe channels, resources, or collective organization. Duty-bearers may lack budget, systems, skills, coordination, data, or accountability processes. CSOs may also have capacity gaps, such as weak facilitation, language barriers, poor feedback loops, or limited accessibility planning.

### Learner action / configuration

Viewed.

### Safety note

Avoid blame.

### Button

Continue

---

## M4-S3-03 — Claims, obligations, and capacity gaps table

Complete a simple table for one issue. This helps you move from “there is a problem” to “what should change, who is involved, and what support is needed.”

### Learner action / configuration

Columns: rights issue; rights-holders; claim/concern; duty-bearer; obligation/responsibility; RH gap; DB gap; CSO support; safety.

### Feedback / completion message

This table helps identify what should change, who should act, and how a CSO can support safely.

### Safety note

Use generalized examples; no active case details.

### Asset reference

claims-obligations-capacity-table.xlsx

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M4-S3-04 — When training is not enough

A CSO notices that community members rarely use the local feedback mechanism. The team first assumes people need awareness. Then they ask deeper questions: do people trust the channel, know what happens after feedback, have accessible language options, fear consequences, or see duty-bearers respond?

### Learner action / configuration

Viewed; followed by sorting.

### Safety note

Fictional scenario; no real complaints.

### Asset reference

capacity-gap-feedback-case.jpg

### Button

Continue

---

## M4-S3-05 — Sort the capacity gap

Sort each barrier into the side where it mainly appears: rights-holder capacity gap, duty-bearer capacity gap, or shared/system barrier.

### Learner action / configuration

Six items configured in interaction logic.

### Feedback / completion message

Capacity gaps are barriers to address, not personal failings.

### Safety note

Avoid stigmatizing excluded groups.

### Button

Submit and view feedback

---

## M4-S3-06 — Check your understanding

Which are examples of capacity gaps that may affect rights-based change? Select all that apply.

### Learner action / configuration

That’s right: information access; response protocol; inaccessible venue; low trust in feedback. Not quite: awareness solves everything.

### Feedback / completion message

Capacity gaps can involve information, systems, access, trust, and response capacity.

### Safety note

No sensitive data.

### Button

Submit and view feedback

---


# 4.4 Power and Exclusion Analysis

## M4-S4-01 — The loudest voices are not always the most affected

During a community consultation, the most confident participants speak first and influence the discussion. Others remain quiet. Some people are absent because the meeting time, venue, language, or social dynamics make participation difficult. HRBA asks: Who speaks? Who decides? Who is silent? Who is absent? Who may face risk? Who controls information? Who is expected to agree?

### Learner action / configuration

Viewed.

### Safety note

Do not imply all communities work the same way.

### Asset reference

community-consultation-power-dynamics.jpg

### Button

Continue

---

## M4-S4-02 — Power shapes participation

Power affects who can access information, who feels safe to speak, who is believed, who is represented, who controls resources, and whose priorities are included. A consultation may look participatory while still excluding important voices. HRBA does not require a CSO to solve all power inequalities alone, but it does require the CSO to notice them and design participation more carefully.

### Learner action / configuration

Viewed.

### Safety note

Focus on safer facilitation, not blame.

### Button

Continue

---

## M4-S4-03 — Spot the exclusion risks

Explore the consultation scene. Select each hotspot to identify a possible exclusion barrier.

### Learner action / configuration

Hotspots: time, venue, language, seating, public speaking, information/note-taking.

### Feedback / completion message

Participation is not only invitation. It also requires conditions that make safe, meaningful voice possible.

### Safety note

Fictional scene only.

### Asset reference

consultation-exclusion-hotspot.svg

### Button

Continue

---

## M4-S4-04 — Power and exclusion questions

Use these questions before relying on a consultation, assessment, or stakeholder meeting.

### Learner action / configuration

Items include: invited, attended, absent, spoke, stayed silent, influenced decision, felt safe, accessible information, feedback/report-back, risk.

### Feedback / completion message

Small design changes can make participation more meaningful.

### Safety note

Do not collect sensitive individual information.

### Asset reference

power-exclusion-checklist.pdf

### Button

Submit and view feedback

---

## M4-S4-05 — Improve one participation moment

Think of one consultation, meeting, training, or assessment your CSO has conducted. What one design change could make participation safer or more inclusive next time?

### Learner action / configuration

Optional private save.

### Feedback / completion message

Small changes — timing, language, facilitation, accessibility, information, feedback — can reduce exclusion.

### Safety note

No identifiable participants.

### Buttons

Save privately
Skip for now
Continue

---

## M4-S4-06 — Check your understanding

Which statement best reflects HRBA power analysis?

### Learner action / configuration

That’s right: asks who speaks, decides, stays silent, is absent, controls information, and may face risk.

### Feedback / completion message

HRBA asks whether participation is meaningful, inclusive, and safe.

### Safety note

No sensitive data.

### Button

Submit and view feedback

---


# 4.5 Gender, Disability, Youth, and Intersectionality

## M4-S5-01 — People do not experience barriers in only one way

People do not experience barriers in only one way. A young woman with a disability may face different barriers than an older man in the same community. A person living far from a service point may also face language, transport, literacy, safety, or care-work barriers. Intersectional analysis helps CSOs notice overlapping barriers instead of assuming that one group label explains everyone’s experience.

### Learner action / configuration

Viewed.

### Safety note

Avoid stereotypes.

### Button

Continue

---

## M4-S5-02 — Intersectionality in plain language

Open each panel to explore what intersectionality means for practical CSO work.

### Learner action / configuration

Panels: gender; disability/accessibility; youth/age; poverty/location/time; language/information; overlapping barriers.

### Feedback / completion message

Intersectional analysis helps reduce assumptions and improve access.

### Safety note

Use broad examples, no sensitive identities.

### Asset reference

intersectionality-practical-panels.svg

### Button

Continue

---

## M4-S5-03 — Same project, different barriers

A CSO organizes livelihood training in a town center. Attendance looks good, but different groups face different barriers: some leave early because of care work; some cannot access the venue; some cannot afford transport; some hesitate to speak in mixed groups; some do not use printed materials. The activity is open to everyone, but not equally accessible to everyone. HRBA asks the CSO to adjust conditions of participation, not blame the people facing barriers.

### Learner action / configuration

Viewed; followed by decision activity.

### Safety note

Fictional case; respectful representation.

### Asset reference

intersectional-barriers-training-case.jpg

### Button

Continue

---

## M4-S5-04 — Improve the inclusion plan

The CSO wants to improve the livelihood training. Which combination of actions is most rights-based?

### Learner action / configuration

That’s right: adjust timing, transport, venue accessibility, formats, safer discussion spaces, and feedback. Not quite: keep plan because everyone was invited; remove inconsistent participants; ask excluded groups to adapt.

### Feedback / completion message

Rights-based inclusion changes the conditions of participation, not only the invitation.

### Safety note

Avoid reinforcing stereotypes.

### Button

Submit and view feedback

---

## M4-S5-05 — Inclusion barrier scan

Choose one activity your CSO runs or plans. Scan for barriers using the categories provided.

### Learner action / configuration

Fields: activity; gender barriers; disability/accessibility barriers; youth/age barriers; poverty/location/time barriers; language/information barriers; practical adjustment; safety issue.

### Feedback / completion message

An inclusion barrier scan helps move from “open to all” toward meaningful accessibility.

### Safety note

Use barriers/categories, not personal identifiers.

### Asset reference

intersectional-inclusion-barrier-scan.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M4-S5-06 — Check your understanding

What does intersectional analysis help a CSO do?

### Learner action / configuration

That’s right: notice overlapping barriers that affect participation, access, safety, and voice.

### Feedback / completion message

Intersectional analysis helps CSOs design more inclusive and realistic participation.

### Safety note

No sensitive data.

### Button

Submit and view feedback

---


# 4.6 Stakeholder Mapping for HRBA

## M4-S6-01 — Bring the analysis together

You have now practiced identifying rights-holders, duty-bearers, claims, obligations, capacity gaps, power, and exclusion. The next step is to bring these pieces together in a stakeholder map. A stakeholder map helps your CSO decide who to listen to, who to engage, who may support change, who may resist change, what risks exist, and where your CSO can act safely and constructively.

### Learner action / configuration

Viewed.

### Safety note

No sensitive actor names.

### Button

Continue

---

## M4-S6-02 — Six steps for HRBA stakeholder mapping

Define the rights issue clearly. Identify affected rights-holder groups and excluded groups. Identify duty-bearer and responsible actor categories. Identify allies, influencers, blockers, and resource actors. Analyze power, interest, risks, and relationships. Choose safe engagement strategies and first practical next steps.

### Learner action / configuration

Complete process before continue.

### Safety note

Use role categories for sensitive issues.

### Asset reference

hrba-stakeholder-mapping-process.svg

### Button

Continue

---

## M4-S6-03 — Power, interest, and safety lens

Stakeholder mapping is not only a list. It asks how much influence each actor has, how interested or supportive they are, how they relate to rights-holders, and what risks or opportunities are present.

### Learner action / configuration

Quadrants: high influence/high support; high influence/low support; low influence/high support; low influence/low support. Safety overlay: public engagement, private dialogue, indirect engagement, or do not engage without advice.

### Feedback / completion message

The safest engagement strategy depends on influence, support, relationships, and risk.

### Safety note

High-risk advocacy may require specialist advice.

### Asset reference

stakeholder-power-interest-safety-matrix.svg

### Button

Continue

---

## M4-S6-04 — Complete your HRBA stakeholder map

Create a simple stakeholder map for one issue. Use fictionalized or generalized examples if the issue is sensitive.

### Learner action / configuration

Fields: rights issue; rights-holder groups; excluded groups; duty-bearers; influencing actors; allies; blockers; risks; safe engagement options; first practical next step.

### Feedback / completion message

Your stakeholder map is a practical bridge between HRBA analysis and action. Keep it updated as you learn more.

### Safety note

Avoid names, political details, active advocacy targets.

### Asset reference

hrba-stakeholder-map-template.xlsx

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M4-S6-05 — What changed in your analysis?

Compare your stakeholder map with how your CSO might normally describe the same issue. What became clearer when you used rights-holders, duty-bearers, capacity gaps, power, and exclusion?

### Learner action / configuration

Optional private save.

### Feedback / completion message

A strong HRBA map often reveals missing voices, unclear responsibilities, and safer entry points for action.

### Safety note

No sensitive actors or active advocacy details.

### Buttons

Save privately
Skip for now
Continue

---

## M4-S6-06 — Check your understanding

What should an HRBA stakeholder map include? Select all that apply.

### Learner action / configuration

That’s right: affected rights-holder groups; duty-bearers/responsible actors; excluded/less-heard groups; power/influence/risks/safe engagement. Not quite: only donor/project team.

### Feedback / completion message

HRBA stakeholder mapping includes affected groups, responsible actors, exclusion, power, risks, and safe engagement options.

### Safety note

No sensitive data.

### Button

Submit and view feedback

---

## M4-S6-07 — Module 4 summary

In this module, you moved from general stakeholder awareness to practical HRBA analysis. You identified rights-holders and duty-bearers, connected claims and obligations, examined capacity gaps, analyzed power and exclusion, applied an intersectional inclusion lens, and created a stakeholder map. In the next module, you will use this analysis to strengthen HRBA project design.

### Learner action / configuration

Viewed; next-module CTA enabled.

### Safety note

No sensitive data.

### Asset reference

module-4-summary-cards.svg

### Button

Continue

---


## Module 4 next step

In Module 5, you will use this analysis to strengthen HRBA project design. Your rights-holder, duty-bearer, capacity-gap, power, exclusion, and stakeholder mapping work will help you design projects that are more specific, inclusive, accountable, and safe.

### Button

Continue to Module 5
