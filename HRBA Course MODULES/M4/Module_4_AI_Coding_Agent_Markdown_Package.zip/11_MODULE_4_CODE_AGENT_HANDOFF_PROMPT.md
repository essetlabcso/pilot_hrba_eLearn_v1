# Copy/Paste Prompt for Coding Agent — Module 4

You are implementing **Module 4: Rights-Holders, Duty-Bearers, Power, and Exclusion** for the CSO Learning Hub course **Applying the Human Rights-Based Approach (HRBA) in CSO Practice**.

Use this Markdown package as the controlled source of truth. Do not use the original production workbook directly unless specifically instructed. Build the learner-facing Module 4 course-player experience only.

## Plan first

Before editing code, produce a short implementation plan that identifies:

1. routes/components/files you will update;
2. how you will represent the approved Module 4 lesson sequence and 38 screens/blocks;
3. how you will implement labeled graphics, accordions, matching, sorting, hotspot, checklist, decision activity, process block, matrix, worksheets/tools, private reflections, MCQ/MRQ checks, and summary;
4. how privacy and data-saving will work;
5. how certificate logic will remain untouched;
6. how accessibility and low-bandwidth requirements will be met;
7. any missing assets and how placeholder components will be used.

Do not proceed with code until the plan is clear.

## Source files in this package

Use these files:

- `01_MODULE_4_OVERVIEW.md`
- `02_MODULE_4_SCREEN_BY_SCREEN_CONTENT.md`
- `03_MODULE_4_BLOCK_STORYBOARD.md`
- `04_MODULE_4_INTERACTION_LOGIC.md`
- `05_MODULE_4_REFLECTION_PORTFOLIO_LOGIC.md`
- `06_MODULE_4_ASSESSMENT_AND_FEEDBACK.md`
- `07_MODULE_4_DESIGN_AND_VISUAL_SPEC.md`
- `08_MODULE_4_SAFETY_ACCESSIBILITY_DATA_RULES.md`
- `09_MODULE_4_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`
- `10_MODULE_4_BUILD_ACCEPTANCE_CRITERIA.md`

## Required implementation

Implement Module 4 with:

1. approved title: **Rights-Holders, Duty-Bearers, Power, and Exclusion**;
2. approved six-lesson sequence plus module intro and summary;
3. 38 learner-facing screens/blocks;
4. exact learner-facing text from `02_MODULE_4_SCREEN_BY_SCREEN_CONTENT.md`;
5. formative checks and repaired feedback from `06_MODULE_4_ASSESSMENT_AND_FEEDBACK.md`;
6. deterministic logic from `04_MODULE_4_INTERACTION_LOGIC.md`;
7. private portfolio/tool behavior from `05_MODULE_4_REFLECTION_PORTFOLIO_LOGIC.md`;
8. visual design rules from `07_MODULE_4_DESIGN_AND_VISUAL_SPEC.md`;
9. safety/accessibility rules from `08_MODULE_4_SAFETY_ACCESSIBILITY_DATA_RULES.md`;
10. asset references from `09_MODULE_4_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`.

## Hard constraints

Do not:

- expose screen IDs, block IDs, source IDs, evidence IDs, QA notes, or implementation metadata to learners;
- include source inventories, evidence packs, change logs, approval locks, or review history;
- use “Incorrect,” “Wrong,” “Failed,” or pass/fail language;
- imply Module 4 checks, tools, worksheets, maps, or reflections affect the certificate;
- issue or unlock certificates from Module 4;
- request names, real stakeholder maps, active cases, complaint files, safeguarding details, legal disputes, political details, confidential records, beneficiary/staff lists, raw organizational data, or uploads;
- send raw reflections, worksheet entries, optional notes, stakeholder maps, or portfolio content to AI services;
- make worksheets download-only;
- use drag-and-drop-only or hotspot-only interactions;
- invent asset filenames;
- present learning guidance as legal advice;
- frame duty-bearers as enemies;
- add public peer exchange or public sharing of stakeholder maps.

Must:

- use “Not quite” for weaker responses;
- use “That’s right” or “Good choice” for best responses;
- keep all Module 4 checks/tools/reflections formative;
- state certificate eligibility remains tied to final course test score of 80% or above;
- include legal-learning boundary where obligations/standards/responsibilities are discussed;
- keep tool outputs and stakeholder maps private by default;
- provide downloadable and in-platform worksheet/tool options where feasible;
- ensure keyboard, tap, screen-reader, and low-bandwidth support;
- use DEC/CSO Learning Hub colors and premium card-based course-player design;
- use safe broad actor categories, not real names.

## Acceptance criteria

Use `10_MODULE_4_BUILD_ACCEPTANCE_CRITERIA.md` as the final QA checklist. The implementation is not complete until every acceptance check passes.

## Evidence pack required after implementation

After completing the work, provide:

1. summary of implementation;
2. files changed;
3. routes/screens affected;
4. components created or updated;
5. data/schema changes, if any;
6. role/permission changes, if any;
7. certificate logic confirmation;
8. safety/privacy confirmation;
9. accessibility and low-bandwidth confirmation;
10. asset handling summary;
11. tests/checks run and results;
12. known gaps or missing assets;
13. manual verification steps.

## Final verification

Verify at minimum:

- Module 4 route loads;
- approved six lessons and summary appear;
- all 38 screens/blocks are reachable;
- labeled graphic, accordion, matching, sorting, hotspot, checklist, decision, process, matrix, tool activity, MCQ/MRQ, and private reflections work;
- matching/sorting have non-drag alternatives;
- hotspot and matrix have text alternatives;
- worksheets/tools have in-platform and download options where feasible;
- stakeholder map is private by default;
- feedback uses “Not quite,” “That’s right,” and “Good choice” as specified;
- no Module 4 activity triggers certificate logic;
- no sensitive fields or uploads are requested;
- missing assets render as placeholders using approved references.
