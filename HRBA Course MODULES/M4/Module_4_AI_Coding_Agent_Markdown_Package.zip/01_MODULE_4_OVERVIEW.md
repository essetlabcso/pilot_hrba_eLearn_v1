# Module 4 Overview

## Course

**Applying the Human Rights-Based Approach (HRBA) in CSO Practice**

## Module title

**Module 4: Rights-Holders, Duty-Bearers, Power, and Exclusion**

## Module role

Module 4 is a substantive HRBA practice module. It moves participants from general stakeholder awareness to practical HRBA analysis before CSO action.

## Recommended duration

**90–110 minutes**

## Primary audience

Local and grassroots CSO staff, project officers, MEAL staff, advocacy/community engagement staff, coordinators, facilitators, and focal persons.

## Main learner shift

From:

> “The community needs support.”

To:

> “Which rights-holder groups are affected or excluded, which duty-bearer categories have responsibilities, what claims and obligations exist, what capacity gaps and power relations shape the issue, and how can our CSO engage safely and constructively?”

## Module learning outcomes

By the end of Module 4, participants should be able to:

1. identify rights-holder groups using safe, specific, broad categories;
2. distinguish rights-holders, duty-bearers, service-level actors, influencing actors, CSOs, and resource actors;
3. connect rights-holder claims, duty-bearer obligations, and capacity gaps;
4. recognize how power and exclusion shape participation and evidence;
5. apply a practical intersectional lens to gender, disability, youth/age, poverty/location/time, language, and overlapping barriers;
6. create a safe HRBA stakeholder map using role categories, power, risk, allies, blockers, and constructive engagement options;
7. save or download private Module 4 portfolio/tool outputs without affecting certificate eligibility.

## Approved lesson sequence

1. **Identifying Rights-Holders**
2. **Identifying Duty-Bearers**
3. **Claims, Obligations, and Capacity Gaps**
4. **Power and Exclusion Analysis**
5. **Gender, Disability, Youth, and Intersectionality**
6. **Stakeholder Mapping for HRBA**
7. **Module 4 Summary**

## Main portfolio/tool outputs

- Rights-holder list
- Duty-bearer map
- Claims, obligations, and capacity gaps table
- Power and exclusion reflection
- Inclusion barrier scan
- HRBA stakeholder map

## Assessment rule

All Module 4 checks are formative only. They support practice and review. They do not issue a certificate, unlock a certificate, rank participants, or rank CSOs.

## Certificate rule

Certificate eligibility remains tied to the final course test with a score of **80% or above**.

## Safety level

Moderate to high due to power/exclusion analysis, stakeholder mapping, and potentially sensitive actor relationships.

## Privacy rule

Tool outputs, stakeholder maps, optional notes, worksheet entries, and reflection outputs are private by default.

## Sensitive data rule

Do not ask learners to provide names, real stakeholder maps, active cases, complaint files, safeguarding details, legal disputes, political details, confidential records, beneficiary/staff lists, raw organizational data, or uploads.
