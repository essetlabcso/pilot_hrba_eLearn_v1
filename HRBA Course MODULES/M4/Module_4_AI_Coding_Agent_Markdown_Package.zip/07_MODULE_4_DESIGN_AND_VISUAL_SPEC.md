# Module 4 Design and Visual Interaction Specification

## Module title

**Module 4: Rights-Holders, Duty-Bearers, Power, and Exclusion**

## Design purpose

Module 4 should feel practical, careful, safe, and action-oriented. It deals with sensitive HRBA analysis: rights-holders, duty-bearers, claims, obligations, capacity gaps, power, exclusion, intersectionality, and stakeholder mapping.

The experience should not feel like a political analysis worksheet, legal accusation tool, generic stakeholder matrix, or static manual. It should feel like a guided, safe, premium learning journey for local and grassroots CSO practitioners.

## Visual identity

| Use | Color |
|---|---|
| Primary action / active progress | `#3B99D4` |
| Positive accent / completion / growth | `#91C852` |
| Deep heading / navigation text | `#0F172A` |
| Main text | `#111827` |
| Secondary text | `#6B7280` |
| Background | `#F9FAFB` |
| Card background | `#FFFFFF` |
| Border | `#E5E7EB` |
| Warning / safety accent | `#F97316` |
| Critical safety warning only | `#EF4444` |

## Source visual interaction controls

| Design/interaction area | Specification | Where used | Mobile behavior | Low-bandwidth behavior | Motion rule |
| --- | --- | --- | --- | --- | --- |
| Global visual system | Use DEC blue #3B99D4, accent green #91C852, deep navy #0F172A, light background #F9FAFB, white cards, dark text #111827, subtle borders #E5E7EB, rounded corners, soft shadows. | All module screens | Responsive single-column on mobile. | Text-first fallback. | No unnecessary animation. |
| Module layout | Course player with left navigation, main learning canvas, optional resource/notes drawer if implemented. | All lessons | Sidebar collapses to drawer; progress remains visible. | Lesson content usable without side drawer. | No animation required. |
| Scenario hooks | Use warm local CSO visuals or illustrated scenes paired with short text. Avoid sensationalism or stereotypes. | Opening blocks | Image above text or stacked; no text embedded in image. | Full scenario text visible. | Subtle fade allowed; reduced motion off. |
| Labeled graphic behavior | Markers reveal content and require opening all markers before continue if supported. | 4.1 lens | Markers become accordion/list on mobile. | Text alternative below. | No bouncing animation. |
| Accordion behavior | Progressive reveal panels with complete text accessible to screen readers. | 4.2, 4.5 | Single-column panels. | All panel text in DOM. | No auto-scroll animation required. |
| Hotspot behavior | Interactive consultation scene with six selectable markers; text alternative available. | 4.4 | Hotspots become numbered list on mobile or keyboard mode. | Text list alternative mandatory. | Minimal highlighting; no color-only cue. |
| Matrix behavior | Power-interest-safety matrix with quadrant explanations and caution overlay. | 4.6 | Stack quadrants as cards on mobile. | Full text explanation below. | No motion required. |
| Tool behavior | In-platform form/table plus downloadable template. Save optional/private if portfolio supported. | 4.1–4.6 tools | Stack fields; avoid wide tables where possible. | Download not required for essential learning. | No animation. |
| Safety/warning styling | Short, calm helper notes using warm orange or neutral note style; avoid alarming tone. | Tools/reflections/power mapping | Icon + text, not color only. | Text helper embedded. | No animation. |
| Sensitive power/exclusion styling | Use practical analysis cards, not red-alert or adversarial visuals. | 4.4–4.6 | Readable card layout. | No visual-only risk labels. | No dramatic motion. |
| Completion behavior | Complete major interactions before continue where supported; private reflections optional/skippable. | All lessons | Touch-friendly buttons. | Manual continue alternative. | No forced animation. |

## Section design rules

| Section | Visual / interaction treatment |
|---|---|
| Module intro | Hero/bridge card with calm local CSO image and safety reminder |
| 4.1 Identifying Rights-Holders | Scenario, micro-lesson, labeled graphic, worksheet/tool, private reflection, MCQ |
| 4.2 Identifying Duty-Bearers | Scenario, definition card, respect/protect/fulfil accordion, matching, duty-bearer map, MCQ |
| 4.3 Claims, Obligations, and Capacity Gaps | Statement block, micro-lesson, interactive table, case, sorting, MRQ |
| 4.4 Power and Exclusion Analysis | Scenario, micro-lesson, hotspot scene, checklist, private reflection, MCQ |
| 4.5 Gender, Disability, Youth, and Intersectionality | Statement, accordion, case, decision activity, inclusion barrier scan, MCQ |
| 4.6 Stakeholder Mapping for HRBA | Transition, process, matrix, stakeholder map tool, reflection, MRQ, summary |

## Sensitive design rules

- Avoid images that imply conflict, blame, surveillance, or political targeting.
- Avoid pity or deficit imagery for disability, gender, poverty, youth, or exclusion.
- Do not show recognizable faces, readable documents, real logos, political signage, or confidential records.
- Power/exclusion screens should feel careful and constructive, not accusatory.
- Duty-bearers should be visually represented as responsible actors who may need capacity/support, not villains.

## Mobile behavior

On mobile:

- all layouts become single column;
- navigation collapses to drawer/menu;
- labeled graphics/hotspots become numbered accordion lists;
- matrix quadrants stack as cards;
- interactive tables become grouped cards or horizontally scrollable accessible tables;
- all CTAs are full width;
- large tap targets are required.

## Feedback states

| State | Design rule |
|---|---|
| Best response | Green accent; text begins “That’s right” or “Good choice” |
| Weaker response | Neutral or soft amber accent; text begins “Not quite” |
| Saved portfolio | Green confirmation; “Saved privately” language |
| Safety reminder | Orange accent; calm protective tone |
| Critical block | Red only if there is a real release-blocking safety issue, not for learner feedback |

## Design no-drift rules

The coding agent must not:

- turn Module 4 into a static article;
- remove private tool/portfolio options;
- require real stakeholder names;
- use drag-only or hotspot-only interactions;
- imply Module 4 tools/reflections affect certificate;
- create public peer exchange;
- show “Incorrect” feedback;
- use legal-accusation language;
- frame duty-bearers as enemies;
- use risky or stereotyped imagery;
- invent asset filenames;
- omit text alternatives for essential visuals.
