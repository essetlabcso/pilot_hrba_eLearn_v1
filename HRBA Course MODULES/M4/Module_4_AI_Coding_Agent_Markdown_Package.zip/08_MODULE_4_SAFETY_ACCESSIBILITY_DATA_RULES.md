# Module 4 Safety, Accessibility, and Data Rules

## Safety principle

Module 4 has a moderate-to-high safety level because it deals with power, exclusion, duty-bearers, stakeholder mapping, actor relationships, and potentially sensitive local dynamics.

The module must help learners analyze safely without exposing people, organizations, communities, complaints, safeguarding cases, legal disputes, political details, confidential records, or sensitive power relationships.

## Safety rules from source workbook

| Safety rule | Where addressed | Learner-facing wording | Pass condition | Boundary |
| --- | --- | --- | --- | --- |
| Use fictional/generalized examples | All lessons | Use fictional or general examples. Do not include names or details that could identify people, communities, officials, cases, or organizations. | Learner-facing warning appears before tools/reflections. | Power/exclusion and legal boundary |
| No names or sensitive actor details | Rights-holder/duty-bearer/stakeholder tools | Use broad categories or role descriptions instead of names. | Tool fields do not request names. | Power mapping safety |
| No active complaint/legal/protection cases | Capacity table, power analysis, stakeholder map | Do not describe active complaint files, safeguarding/protection cases, legal disputes, or confidential records. | Tool text includes privacy helper. | Legal/safeguarding boundary |
| No legal advice | Duty-bearer and obligations content | This is learning guidance, not legal advice. For real legal questions, consult qualified support through appropriate channels. | Visible where obligations/standards are discussed. | Legal-advice boundary |
| Private reflections | All reflections | Your reflection is private by default. You may skip or save it for your own learning if the platform allows. | Reflection blocks marked private/optional. | Privacy boundary |
| Peer exchange deferred | Module 4 peer plan | Do not share real stakeholder maps, duty-bearer names, power analysis, or sensitive cases in open peer spaces. | Peer exchange not included in required flow. | Power/exclusion safety |
| No certificate overclaim | README, build handoff, assessments | Module activities prepare you for practice but do not certify field competence. Certificate depends only on final course test score of 80% or above. | Certificate UI remains separate. | Certificate boundary |
| Asset safety | All visuals | Images must not show recognizable faces, readable documents, logos, political signage, or sensitive text. | Asset prompts include safety language. | Power/exclusion visual boundary |

## Do not request

Never ask learners to submit:

- real names of people, officials, organizations, communities, or institutions;
- real stakeholder maps;
- active cases;
- complaint files;
- safeguarding or protection details;
- legal disputes;
- political details;
- active advocacy targets;
- confidential documents;
- beneficiary/staff lists;
- raw organizational data;
- uploads.

## Safe alternatives

Use:

- fictional examples;
- broad group categories;
- role descriptions;
- actor categories;
- non-identifying descriptions;
- structured choices;
- optional private notes with safety helper text;
- private portfolio summaries.

## Legal-learning boundary

Use this learner-facing message where duty-bearers, obligations, standards, or legal responsibility are discussed:

> This is learning guidance, not legal advice. For real legal questions, consult qualified support through appropriate channels.

## Privacy rules

| Data type | Default visibility |
|---|---|
| Tool outputs | Private by default |
| Optional reflections | Private by default |
| Stakeholder maps | Private by default |
| Assessment completion | Learner/system only |
| Assessment score/response | Formative only; no certificate effect |
| Portfolio summaries | Learner private portfolio only |
| Admin analytics | Aggregated only, no raw notes/maps |

## Accessibility and low-bandwidth QA

| QA item | Where addressed | Requirement | Pass condition | Status | Notes |
| --- | --- | --- | --- | --- | --- |
| Keyboard access | All interactions | All controls reachable by keyboard or equivalent navigation. | Test tab order and enter/space activation. | Pass | Approved |
| Screen-reader labels | MCQ, matching, sorting, hotspot, tools | Controls and fields have labels and instructions. | Inspect labels; test with screen reader where possible. | Pass | Approved |
| Visible focus | All interactive elements | Focus state visible and not color-only. | Manual UI test. | Pass | Approved |
| Alt text | All images and diagrams | Meaningful alt text provided in asset register. | Verify alt text exists and does not repeat file name only. | Pass | Approved |
| Text alternatives | Labeled graphic, hotspot, matrix, process, summary cards | All visual meaning also provided as selectable text. | Compare visual to text alternative. | Pass | Approved |
| Non-drag alternatives | Matching and sorting | Tap/list or dropdown alternative available; drag/drop not required. | Mobile/keyboard test. | Pass | Approved |
| Hotspot alternative | Consultation hotspot | Text list includes all hotspots and explanations. | Verify list is accessible before/after visual. | Pass | Approved |
| Accessible tools/PDFs | Worksheets/templates | Downloadable files must have headings, reading order, simple tables, and in-platform alternatives. | Pass | Approved | Approved: use asset register filenames with accessible in-platform alternatives. |
| Mobile readability | All lessons | Single-column layout; tables convert to cards or scroll with labels; large tap targets. | Mobile preview. | Pass | Approved |
| Low-bandwidth fallback | Images/downloads | Essential learning available without images/downloads. | Disable images/downloads test. | Pass | Approved |
| Reduced motion | Hotspot, process, matrix | No essential content depends on animation; reduced-motion behavior avoids unnecessary movement. | Reduced-motion browser setting test. | Pass | Approved |
| Color contrast | Cards, warnings, buttons, diagrams | Use DEC colors with accessible contrast; no color-only meaning. | Contrast check. | Pass | Approved |

## AI/data restriction

Raw reflections, optional notes, stakeholder maps, worksheet entries, and portfolio content should not be sent to AI services. If AI is later used for safe summaries, use structured non-sensitive tags or participant-approved safe summaries only.

## Safe helper text

Use before any optional text field or tool output:

> Keep this safe and general. Do not include names, real stakeholder maps, active cases, complaint files, safeguarding details, legal disputes, political details, confidential records, beneficiary/staff lists, or raw organizational data.
