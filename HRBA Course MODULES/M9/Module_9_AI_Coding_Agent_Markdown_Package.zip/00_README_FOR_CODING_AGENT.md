# Module 9 AI Coding Agent Package — README

## Package purpose

This package contains the clean implementation content for **Module 9: Course Closing, Final Test, and Next Steps** in the course **Applying the Human Rights-Based Approach (HRBA) in CSO Practice**.

Use this package as the source of truth for building Module 9 in the CSO Learning Hub course player or related repo implementation.

## Package files

1. `00_README_FOR_CODING_AGENT.md` — build rules, file map, no-drift instructions.
2. `01_MODULE_9_OVERVIEW.md` — module purpose, outcomes, duration, learner shift, section flow.
3. `02_MODULE_9_SCREEN_BY_SCREEN_CONTENT.md` — exact learner-facing content and implementation microcopy.
4. `03_MODULE_9_BLOCK_STORYBOARD.md` — content block/storyboard map.
5. `04_MODULE_9_INTERACTION_LOGIC.md` — deterministic behavior rules and pseudo-logic.
6. `05_MODULE_9_REFLECTION_PORTFOLIO_LOGIC.md` — Module 9 portfolio/action-plan/proof separation.
7. `06_MODULE_9_ASSESSMENT_AND_FEEDBACK.md` — formative checks and assessment rules.
8. `07_MODULE_9_DESIGN_AND_VISUAL_SPEC.md` — visual and interaction design rules.
9. `08_MODULE_9_SAFETY_ACCESSIBILITY_DATA_RULES.md` — safety, privacy, accessibility, low-bandwidth, and data rules.
10. `09_MODULE_9_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md` — approved asset filenames, placeholders, and alt text.
11. `10_MODULE_9_BUILD_ACCEPTANCE_CRITERIA.md` — implementation QA checks.
12. `11_MODULE_9_CODE_AGENT_HANDOFF_PROMPT.md` — copy/paste-ready coding-agent prompt.
13. `12_MODULE_9_FINAL_TEST_ITEM_BANK.md` — 40-item final test source of truth.
14. `13_MODULE_9_CERTIFICATE_FEEDBACK_NEXT_STEPS.md` — certificate behavior, result states, feedback survey, and next steps.

## Binding implementation rules

- Build only the learner-facing Module 9 closing/capstone/final-test experience.
- Preserve the approved functional title: **Course Closing, Final Test, and Next Steps**.
- Preserve the approved six-lesson sequence:
  1. Course Synthesis
  2. Portfolio Review
  3. Finalize Your 90-Day HRBA Action Plan
  4. Final Test Instructions
  5. Final Test
  6. Feedback and Next Steps
- Module 9 is a closing/capstone/final-test module, not a new theory-heavy module.
- Do not include QA history, source inventories, evidence packs, change logs, approval locks, review notes, or production-process records in learner-facing screens.
- Do not expose screen IDs, block IDs, source IDs, citations, or implementation metadata to learners.
- Configure the final test using **exactly 40 items** from `12_MODULE_9_FINAL_TEST_ITEM_BANK.md`.
- Certificate eligibility is based only on the final test score of **80% or above**.
- Never use a 90% certificate threshold.
- Portfolio tools, 90-day action plan, optional proof, application stories, badges, peer exchange, and course feedback are separate from certificate eligibility.
- Do not request names, cases, complaint details, safeguarding details, confidential documents, real legal cases, advocacy targets, political details, raw data, or uploads.
- Portfolio, action plan, final-test readiness, feedback survey comments, and optional notes are private by default.
- Do not send raw portfolio/reflection/action-plan/test/free-text/feedback text to AI services.
- Use “Not quite” instead of “Incorrect.”
- Use “That’s right” or “Good choice” for best responses.
- Optional story/proof is disabled by default and must not be required for certificate.
- All tools must have downloadable and in-platform accessible options where feasible.
- All interactions and final test items must be keyboard accessible, tap-friendly, screen-reader readable, and usable in low-bandwidth settings.
- Matching and sorting must have non-drag alternatives.
- Do not invent asset filenames. Use approved source-named assets where listed; otherwise use placeholders.
