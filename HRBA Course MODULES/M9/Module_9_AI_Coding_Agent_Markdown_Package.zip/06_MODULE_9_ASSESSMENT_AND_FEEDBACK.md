# Module 9 Assessment and Feedback Map

## Assessment and certificate rule

Module 9 contains formative checks and the certificate-linked final test.

Only the **40-item final test** is certificate-linked. Certificate eligibility requires a final test score of **80% or above**.

The following are not certificate requirements:

- portfolio review;
- 90-day HRBA action plan;
- optional proof;
- application story;
- badges or verified achievements;
- peer exchange;
- course feedback survey.

## Source assessment map

| Assessment ID | Lesson/section | Question/prompt | Options/items | Best/correct answer | Feedback/rationale | Status | Certificate implication | Accessibility note | Safety note | Reviewer status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KC-M09-01 | 9.1 | Which statement best summarizes HRBA in CSO practice? | A) Legal vocabulary only. B) Service delivery only. C) Dignity, participation, inclusion, accountability, responsibilities, and safe change. D) Donor reporting only. | C | Reinforces course synthesis. | Formative | No certificate effect | Accessible MCQ | No sensitive content | Approved |
| KC-M09-02 | 9.3 | What is the best response to an unrealistic 90-day plan? | A) Approve because ambitious. B) Narrow into 3–5 realistic actions. C) Remove all actions. D) Upload internal records. | B | Action plans should be realistic and safe. | Formative | No certificate effect | Accessible scenario | No sensitive data | Approved |
| FT-M09-001 to FT-M09-030 | 9.5 | Baseline final-test items covering course domains. | MCQ, multiple response, matching, sorting, scenario | See 30_FINAL_TEST_ITEM_BANK | Baseline source-grounded items. | Certifying | Certificate-linked | Accessible item controls | No real cases/sensitive disclosures | Approved |
| FT-M09-031 to FT-M09-040 | 9.5 | Expanded items covering synthesis, portfolio/certificate/proof boundaries, feedback privacy, safe next steps, result states, action-plan privacy. | MCQ, multiple response, scenario | See 30_FINAL_TEST_ITEM_BANK | Expanded items approved during final QA to meet the 40-item requirement without requesting sensitive disclosures. | Certifying | Certificate-linked | Accessible item controls | No real data/sensitive disclosure | Approved after assessment QA |
| Feedback survey | 9.6 | Course relevance, clarity, usefulness, accessibility, confidence, suggestions. | Rating + optional safe text | No correct answer | Course improvement only. | Non-graded feedback | No certificate effect | Accessible mobile survey | No sensitive data | Approved |

## Repaired formative check feedback

## KC-M09-01 — Section 9.1

### Question

Which statement best summarizes HRBA in CSO practice?

A) Legal vocabulary only.
B) Service delivery only.
C) Dignity, participation, inclusion, accountability, responsibilities, and safe change.
D) Donor reporting only.

Best response: C

Feedback for A: Not quite. HRBA is more than legal vocabulary.
Feedback for B: Not quite. HRBA can strengthen service delivery, but it is not service delivery only.
Feedback for C: That’s right. HRBA connects dignity, participation, inclusion, accountability, responsibilities, and safe change.
Feedback for D: Not quite. Donor reporting is not the purpose of HRBA.

## KC-M09-02 — Section 9.3

### Question

What is the best response to an unrealistic 90-day plan?

A) Approve because ambitious.
B) Narrow into 3–5 realistic actions.
C) Remove all actions.
D) Upload internal records.

Best response: B

Feedback for A: Not quite. Ambition is useful, but unrealistic plans are hard to implement safely.
Feedback for B: That’s right. A strong 90-day plan should be narrowed into 3–5 realistic actions with first steps and risk checks.
Feedback for C: Not quite. Removing all actions loses the practical value of the plan.
Feedback for D: Not quite. Do not upload internal records or confidential documents.

## Final test specification

| Field | Rule |
|---|---|
| Final test item count | 40 |
| Source | `12_MODULE_9_FINAL_TEST_ITEM_BANK.md` |
| Certificate threshold | 80% or above |
| Forbidden threshold | 90% |
| Scoring | Percent correct from 40 items |
| Question types | MCQ, multiple response, matching, sorting, scenario |
| Accessibility | Keyboard/tap/screen-reader accessible; non-drag alternatives for matching/sorting |
| Safety | No real cases, sensitive disclosures, uploads, or confidential data |
| Result if score ≥ 80 | Course passed; certificate available |
| Result if score < 80 | Not yet passed; review and retry according to course rules |

## Feedback wording rules

- Best responses: “That’s right” or “Good choice.”
- Weaker responses: “Not quite.”
- Do not use pass/fail language for formative checks.
- Do not use “Incorrect” as learner-facing feedback.
