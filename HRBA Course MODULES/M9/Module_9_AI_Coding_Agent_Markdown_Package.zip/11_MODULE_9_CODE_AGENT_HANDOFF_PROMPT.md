# Copy/Paste Prompt for Coding Agent — Module 9

You are implementing **Module 9: Course Closing, Final Test, and Next Steps** for the CSO Learning Hub course **Applying the Human Rights-Based Approach (HRBA) in CSO Practice**.

Use this Markdown package as the controlled source of truth. Do not use the original production workbook directly unless specifically instructed. Build the learner-facing Module 9 course-player experience only.

## Plan first

Before editing code, produce a short implementation plan that identifies:

1. routes/components/files you will update;
2. how you will represent the approved six-lesson Module 9 flow;
3. how you will implement course synthesis, portfolio checklist, toolkit resources, priority/value-effort matrix, 90-day action plan, final-test instructions, readiness checklist, 40-item final test, certificate result states, feedback survey, and closing CTA;
4. how privacy and data-saving will work;
5. how certificate logic will use only the final test score;
6. how accessibility and low-bandwidth requirements will be met;
7. any missing assets and how placeholder components will be used.

Do not proceed with code until the plan is clear.

## Source files in this package

Use these files:

- `01_MODULE_9_OVERVIEW.md`
- `02_MODULE_9_SCREEN_BY_SCREEN_CONTENT.md`
- `03_MODULE_9_BLOCK_STORYBOARD.md`
- `04_MODULE_9_INTERACTION_LOGIC.md`
- `05_MODULE_9_REFLECTION_PORTFOLIO_LOGIC.md`
- `06_MODULE_9_ASSESSMENT_AND_FEEDBACK.md`
- `07_MODULE_9_DESIGN_AND_VISUAL_SPEC.md`
- `08_MODULE_9_SAFETY_ACCESSIBILITY_DATA_RULES.md`
- `09_MODULE_9_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`
- `10_MODULE_9_BUILD_ACCEPTANCE_CRITERIA.md`
- `12_MODULE_9_FINAL_TEST_ITEM_BANK.md`
- `13_MODULE_9_CERTIFICATE_FEEDBACK_NEXT_STEPS.md`

## Required implementation

Implement Module 9 with:

1. approved functional title: **Course Closing, Final Test, and Next Steps**;
2. approved six-lesson sequence;
3. 12 learner-facing content blocks;
4. 40 final-test items;
5. exact learner-facing text from `02_MODULE_9_SCREEN_BY_SCREEN_CONTENT.md`;
6. final-test source of truth from `12_MODULE_9_FINAL_TEST_ITEM_BANK.md`;
7. deterministic logic from `04_MODULE_9_INTERACTION_LOGIC.md`;
8. private portfolio/action-plan behavior from `05_MODULE_9_REFLECTION_PORTFOLIO_LOGIC.md`;
9. certificate/result behavior from `13_MODULE_9_CERTIFICATE_FEEDBACK_NEXT_STEPS.md`;
10. visual design rules from `07_MODULE_9_DESIGN_AND_VISUAL_SPEC.md`;
11. safety/accessibility rules from `08_MODULE_9_SAFETY_ACCESSIBILITY_DATA_RULES.md`;
12. asset references from `09_MODULE_9_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`.

## Hard constraints

Do not:

- expose screen IDs, block IDs, source IDs, evidence IDs, QA notes, or implementation metadata to learners;
- include source inventories, evidence packs, change logs, approval locks, or review history;
- use “Incorrect,” “Wrong,” “Failed,” or punitive feedback language for formative checks;
- use 90% as certificate threshold;
- imply portfolio review, 90-day action plan, proof, story, badges, peer exchange, or feedback affect certificate eligibility;
- issue or unlock certificates from anything except final test score of 80% or above;
- request names, cases, complaint details, safeguarding details, confidential documents, real legal cases, advocacy targets, political details, raw organizational data, or uploads;
- send raw reflections, action plans, feedback comments, optional notes, test free text, or portfolio content to AI services;
- make tools download-only;
- use drag-and-drop-only interactions;
- invent asset filenames;
- enable optional story/proof by default.

Must:

- implement exactly 40 final-test items;
- use final test score >= 80% as the certificate pass rule;
- show clear pass and not-yet-passed result states;
- provide review/retry path according to course rules for not-yet-passed learners;
- keep portfolio/action plan/feedback private by default;
- make feedback survey separate from certificate;
- use “Not quite” for weaker formative responses;
- use “That’s right” or “Good choice” for best responses;
- ensure keyboard, tap, screen-reader, and low-bandwidth support;
- provide non-drag alternatives for matching/sorting;
- use DEC/CSO Learning Hub colors and premium card-based course-player design;
- use safe fictional/generalized examples only.

## Acceptance criteria

Use `10_MODULE_9_BUILD_ACCEPTANCE_CRITERIA.md` as the final QA checklist. The implementation is not complete until every acceptance check passes.

## Evidence pack required after implementation

After completing the work, provide:

1. summary of implementation;
2. files changed;
3. routes/screens affected;
4. components created or updated;
5. data/schema changes, if any;
6. role/permission changes, if any;
7. final test item implementation summary;
8. certificate logic confirmation;
9. 80% threshold confirmation and 90% search result;
10. proof/portfolio/story/feedback separation confirmation;
11. safety/privacy confirmation;
12. accessibility and low-bandwidth confirmation;
13. asset handling summary;
14. tests/checks run and results;
15. known gaps or missing assets;
16. manual verification steps.

## Final verification

Verify at minimum:

- Module 9 route loads;
- approved six lessons appear in order;
- all 12 content blocks are reachable;
- all 40 final-test items are configured;
- final test score >= 80% enables certificate;
- final test score < 80% does not enable certificate;
- no active 90% threshold exists;
- portfolio, action plan, proof, story, badges, peer exchange, and feedback do not affect certificate;
- no sensitive fields or uploads are requested;
- matching/sorting have non-drag alternatives;
- feedback survey does not affect certificate;
- missing assets render as placeholders using approved references.
