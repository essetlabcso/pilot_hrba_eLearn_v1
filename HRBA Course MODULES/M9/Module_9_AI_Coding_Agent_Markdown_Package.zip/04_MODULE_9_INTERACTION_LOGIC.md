# Module 9 Interaction Logic

## Global rules

```text
Final test is the only certificate-linked assessment.
Certificate eligibility requires final_test_score >= 80%.
Never use a 90% threshold.

Portfolio review, 90-day action plan, optional proof/story, badges, peer exchange, and feedback survey:
  are not certificate requirements
  do not substitute for final test score
  are private or disabled by default according to feature flags

Do not expose to learners:
  screen IDs
  block IDs
  source IDs
  QA notes
  reviewer notes
  approval metadata
  implementation metadata

Do not request:
  names
  cases
  complaint details
  safeguarding details
  confidential documents
  legal cases
  advocacy targets
  political details
  raw data
  uploads
```

## Completion logic

```text
Module 9 completion requires:
  course synthesis viewed
  portfolio review completed or acknowledged according to platform rules
  90-day HRBA action plan drafted/saved/downloaded according to platform rules
  final test instructions and readiness checklist completed if gating is enabled
  final test submitted
  result state displayed
  feedback/next step screen viewed or survey submitted/skipped according to policy

Certificate eligibility:
  if final_test_score >= 80%:
      pass course
      certificate available
  else:
      no certificate yet
      show review/retry path according to course rules

Portfolio/proof/story/feedback:
  never override final_test_score
```

## Source interaction map

| Interaction ID | Lesson / Block | Type | Learner input | Configuration | Correct/completion logic | Feedback/result | Data saved | Safety/privacy | Accessibility | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| INT-M09-001 | M09-L01-B02 | Timeline reveal | Open all eight journey steps | Eight-step recap timeline with mobile stacked layout | All steps viewed | Journey completion message | Viewed steps only | No personal data | Keyboard/text alternative | Approved with asset implementation |
| INT-M09-002 | M09-L01-B03 | Summary card reveal | View all eight takeaway cards | Grid or carousel; icon + text | All cards viewed | Full-course synthesis | Viewed cards only | No personal data | Screen-reader card labels | Approved with asset implementation |
| INT-M09-003 | M09-L01-B04 | Private reflection | Short text answer | 600 characters; save/edit/skip option | Saved or skipped | Saved privately | Private note | Warn against names/locations/cases | Accessible text area | Approved |
| INT-M09-004 | M09-L02-B02 | Portfolio checklist | Mark each tool status | Complete/Needs review/Not started | All items reviewed | Readiness message | Portfolio status summary | No uploads/raw documents | Accessible checkboxes/dropdowns | Approved with asset implementation |
| INT-M09-005 | M09-L03-B02 | Prioritization matrix | Place/select actions | 2x2 value/effort plus list fallback | 3 ideas categorized or skip confirmed | Suggests 3–5 realistic actions | Priority selections | Generic action labels only | Non-drag alternative | Approved with asset implementation |
| INT-M09-006 | M09-L03-B03 | Action-plan tool | Complete action rows | Minimum 3; max recommended 5 | Draft saved | Plan completion message | Action-plan fields | Broad roles/general terms only | Labeled fields; printable version | Approved with asset implementation |
| INT-M09-007 | M09-L04-B02 | Accordion/FAQ | Open final-test scope panels | 6–7 panels; open before continue if gated | Panels viewed | Readiness message | Viewed panels | No sensitive data | Screen-reader-visible panels | Approved |
| INT-M09-008 | M09-L04-B05 | Readiness checklist | Check final-test readiness | Rule, scope, privacy, accessibility, support | Checklist completed | Ready to start | Readiness status | No sensitive data | Keyboard/tap accessible | Approved |
| INT-M09-009 | M09-L05-B02 | Final test block | Answer 40 items | Mixed MCQ/multiple response/scenario/matching/sorting if supported | Submitted score | Score, pass/fail, item feedback | Final test score/status | No open-ended sensitive answers | Accessible controls/non-drag alternatives | Approved after assessment QA |
| INT-M09-010 | M09-L05-B03 | Certificate result state | Pass state | If score >=80 display certificate button | Conditional on score | Certificate available | Certificate status | No proof data displayed | Not color-only | Approved |
| INT-M09-011 | M09-L05-B04 | Retry/result state | Not-yet-passed state | If score <80 show review/retry guidance | Conditional on score | Supportive review pathway | Test status | No shame/no proof substitution | Accessible review links | Approved |
| INT-M09-012 | M09-L06-B02 | Feedback survey | Ratings + optional safe text | Relevance, clarity, usefulness, accessibility, confidence, suggestions | Submitted/skipped | Thank-you message | Feedback response | No sensitive details | Mobile-friendly labels | Approved |
| INT-M09-013 | M09-L06-B03 | Optional application story guidance | Interest/optional link | Disabled by default unless approved | Optional only | Separate pathway explanation | Interest only if enabled | Consent/anonymization required | Clear warnings | Deferred — disabled by default |
| INT-M09-014 | M09-L06-B04 | Next-step cards | Select next step | Card selection, one or more | Saved/skipped | Next-step message | Selection summary | Generic options only | Keyboard/tap cards | Approved |

## Final test behavior

```text
final_test_items = 40
item_source = 12_MODULE_9_FINAL_TEST_ITEM_BANK.md
supported_types = MCQ, multiple response, matching, sorting, scenario

For matching/sorting:
  provide accessible non-drag alternatives
  preserve correct logic
  score equivalently to source item bank

Score:
  percent_correct = correct_items / 40 * 100
  pass_threshold = 80

Result states:
  score >= 80:
      show pass state
      show certificate available state
  score < 80:
      show not-yet-passed state
      show review/retry path
```

## 90-day action-plan behavior

```text
Action plan fields:
  priority
  why it matters
  first step
  responsible role/team
  support needed
  timeline
  safety check
  progress sign

Rules:
  3–5 actions recommended
  roles/teams, not names
  no sensitive advocacy/legal/regulatory/organizational details
  private by default
  not certificate-linked
```

## Feedback survey behavior

```text
Survey:
  safe ratings and optional general comments only
  no complaints, safeguarding details, personal data, confidential records, political details, or sensitive organizational information
  does not affect certificate
  may be skipped according to course policy
```
