# Module 9 Reflection and Portfolio Logic

## Portfolio principle

Module 9 helps the learner review and use course outputs. The portfolio and 90-day action plan are learning and application tools. They are private by default and do not determine certificate eligibility.

## Portfolio behavior table

| Reflection/tool | Placement | Required status | Visibility | Save behavior | Skip behavior | Portfolio implication | Proof implication | Certificate implication | Safety rule | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Most important HRBA shift reflection | 9.1 | Optional/required by setting | Private by default | Save/edit private note | Allow skip if policy permits | Private synthesis note | Not proof | No certificate effect | No names, places, complaints, cases, legal issues, or confidential details. | Approved |
| Portfolio completion checklist | 9.2 | Required for module completion | Private by default | Save status summary only | No skip if required | Organizes portfolio outputs | Not proof; no upload | No certificate effect | Do not upload raw tools/documents. | Approved |
| 90-Day HRBA Action Plan | 9.3 | Required for module completion, not certificate | Private by default | Save/download/export if supported | Can save as draft | Final capstone portfolio output | Not proof unless separately submitted through approved proof workflow | No certificate effect | No sensitive names/cases/locations/conflict/legal/civic-space details. | Approved |
| Final test readiness checklist | 9.4 | Required before test if gating supported | Private/system status | Save readiness status | No skip if gated | Not portfolio | Not proof | Pre-test only | No sensitive data. | Approved |
| Final test score | 9.5 | Required for certificate path | Restricted learner/admin/system view | Saved automatically | Cannot skip if certificate desired | Not portfolio | Not proof | Certificate-linked; pass at 80%+ | No open-ended sensitive prompts. | Approved after assessment QA |
| Course feedback survey | 9.6 | Optional/required by setting; not grading | Restricted/course improvement view | Save response in safe aggregate reporting | Allow skip if policy permits | Not portfolio | Not proof | No certificate effect | No sensitive feedback requested. | Approved |
| Optional application story guidance | 9.6 | Optional only | Private by default; external visibility requires consent | Save interest only if enabled | Skip freely | Not required portfolio | Separate optional proof/story pathway | No certificate effect | Anonymized, consent-based, no sensitive cases/stories/photos. | Deferred — disabled by default |

## Main Module 9 outputs

1. Most important HRBA shift reflection
2. Portfolio completion checklist
3. 90-Day HRBA Action Plan
4. Final test readiness checklist
5. Final test result state
6. Course feedback survey
7. Closing next-step choices

## 90-Day HRBA Action Plan fields

- priority;
- why it matters;
- first step;
- responsible role or team;
- support needed;
- timeline;
- safety check;
- progress sign.

## Safety helper text

Use before portfolio, action-plan, readiness, and feedback fields:

> Keep this safe and general. Do not include names, cases, complaint details, safeguarding details, confidential documents, real legal cases, advocacy targets, political details, raw organizational data, or uploads.

## Save behavior

```text
save_portfolio_review:
  module_id = M09
  tool_statuses = Complete / Needs review / Not started
  save status summary only
  do not collect uploads

save_action_plan:
  module_id = M09
  action_rows = 3 to 5 recommended
  use roles/teams not names
  private by default
  not certificate-linked

save_feedback:
  ratings
  optional general comment if safe
  no certificate effect
  do not collect sensitive disclosures
```

## Certificate separation

```text
certificate_eligible = final_test_score >= 80

not_certificate_inputs:
  portfolio_complete
  action_plan_complete
  proof_submitted
  story_submitted
  feedback_submitted
  badge_status
  peer_exchange_status
```

## Visibility rules

| User type | Can see Module 9 portfolio/action-plan content? |
|---|---|
| Participant | Yes, their own private portfolio and action plan |
| Course facilitator | No by default; only safe aggregate or consent-based summary if enabled |
| CSO focal person | No individual notes by default |
| Peer participant | No |
| Donor or external partner | No |
| Admin dashboard | Aggregate tags/status only, no raw notes or action-plan details |
| AI service | No raw reflections, action plans, feedback comments, or private notes |
