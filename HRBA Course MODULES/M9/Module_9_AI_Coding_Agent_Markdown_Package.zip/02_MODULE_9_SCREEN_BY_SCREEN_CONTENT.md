# Module 9 Screen-by-Screen Learner-Facing Content

# Module 9: Course Closing, Final Test, and Next Steps


# 9.1 Course Synthesis

## M9-S1-01 — Welcome to the closing module

You have reached the final module. This is where you bring the course together, review the tools you created, prepare a practical 90-day HRBA action plan, complete the final test, and choose your next safe step.

### Learner instruction

Take your time. This module is about clarity and practical application, not rushing to the certificate.

### Completion note

Viewed.

### Safety and privacy note

Do not include names, cases, complaint details, or confidential organizational information in any reflection or action plan.

### Button

Continue

---

## M9-S1-02 — Eight ideas to carry forward

1) People are rights-holders. 2) Duty-bearers have responsibilities. 3) Participation should influence decisions. 4) Inclusion needs deliberate action. 5) Accountability means listening, explaining, responding, and correcting. 6) Do-no-harm means reducing risk. 7) MEAL should show inclusion and change. 8) HRBA should shape the CSO internally too.

### Learner instruction

Read each card and think about where it matters most in your work.

### Optional synthesis check

### Question

Which statement best summarizes HRBA in CSO practice?

A) Legal vocabulary only.
B) Service delivery only.
C) Dignity, participation, inclusion, accountability, responsibilities, and safe change.
D) Donor reporting only.

Best response: C

Feedback for A: Not quite. HRBA is more than legal vocabulary.
Feedback for B: Not quite. HRBA can strengthen service delivery, but it is not service delivery only.
Feedback for C: That’s right. HRBA connects dignity, participation, inclusion, accountability, responsibilities, and safe change.
Feedback for D: Not quite. Donor reporting is not the purpose of HRBA.

### Completion note

Complete after all cards viewed.

### Safety and privacy note

No personal or sensitive examples required.

### Button

Continue

---


# 9.2 Portfolio Review

## M9-S2-01 — Review your HRBA practice portfolio

Your portfolio is a set of working tools. It does not need to be perfect. It should help your CSO continue improving.

### Learner instruction

Mark each tool as Complete, Needs review, or Not started.

### Completion note

Complete after all items reviewed.

### Safety and privacy note

Do not upload raw documents. This is a private review for learning.

### Buttons

Open tool
Save privately
Download if available
Continue

---

## M9-S2-02 — A portfolio is for learning, not surveillance

Your portfolio should help your CSO improve. It should not become a ranking tool, a way to expose sensitive issues, or a requirement to share raw internal information.

### Learner instruction

Use the checklist to decide which tools are useful for your next steps.

### Completion note

Viewed.

### Safety and privacy note

Keep portfolio outputs private unless your organization chooses a safe and approved sharing process.

### Buttons

Open tool
Save privately
Download if available
Continue

---


# 9.3 Action Plan

## M9-S3-01 — Turn learning into realistic action

A strong action plan is not a long wish list. It is a small set of useful, safe, and possible improvements your CSO can begin within 90 days.

### Learner instruction

Choose 3–5 actions that are realistic and safe.

### Action-plan scenario check

### Question

What is the best response to an unrealistic 90-day plan?

A) Approve because ambitious.
B) Narrow into 3–5 realistic actions.
C) Remove all actions.
D) Upload internal records.

Best response: B

Feedback for A: Not quite. Ambition is useful, but unrealistic plans are hard to implement safely.
Feedback for B: That’s right. A strong 90-day plan should be narrowed into 3–5 realistic actions with first steps and risk checks.
Feedback for C: Not quite. Removing all actions loses the practical value of the plan.
Feedback for D: Not quite. Do not upload internal records or confidential documents.

### Completion note

Complete when action plan draft is saved.

### Safety and privacy note

Use broad roles and general priorities. Do not include names, conflict details, complaints, safeguarding information, or confidential records.

### Button

Continue

---


# 9.4 Final Test Instructions

## M9-S4-01 — Prepare for the final test

The final test checks whether you understand the essential HRBA ideas and can apply them to practical CSO situations.

### Learner instruction

Review the test scope, rules, support options, and certificate threshold before starting.

### Completion note

Complete when readiness checklist is done.

### Safety and privacy note

The test will not ask you to share real cases or confidential information.

### Button

Continue

---

## M9-S4-02 — Certificate rule

Complete the final test. If you score 80% or above, you pass the course and receive the course certificate. Practical proof, portfolio tools, stories, badges, peer exchange, and feedback are separate from the certificate.

### Learner instruction

Read this rule carefully before starting the test.

### Completion note

Viewed.

### Safety and privacy note

No 90% threshold is used.

### Button

Continue

---


# 9.5 Final Test

## M9-S5-01 — Final test: HRBA in Local CSO Practice

You are about to begin the final test. Many questions are practical judgment questions. Choose the answer that best reflects HRBA, safety, inclusion, accountability, and realistic CSO practice.

### Learner instruction

Answer all final test questions and submit when ready.

### Completion note

Score recorded. Certificate available if score is 80% or above.

### Safety and privacy note

Do not enter real names, cases, documents, or sensitive data in the test.

### Buttons

Start final test
Save progress if supported
Submit when ready

---

## M9-S5-02 — If you pass

Congratulations. You scored 80% or above on the final test. You have passed the course and your certificate is available.

### Learner instruction

Download your certificate if the button is shown.

### Completion note

Certificate issued.

### Safety and privacy note

Certificate data is visible only to you and authorized platform roles.

### Buttons

Download certificate if available
Review next steps

---

## M9-S5-03 — If you are not yet passed

You have not reached 80% yet. This does not erase your learning. Review the recommended sections and try again according to the course rules.

### Learner instruction

Use the review links before retrying.

### Completion note

No certificate yet.

### Safety and privacy note

No proof upload can replace the final test threshold.

### Buttons

Download certificate if available
Review next steps

---


# 9.6 Feedback and Next Steps

## M9-S6-01 — Course feedback survey

Your feedback helps improve future versions of the course. It is not a test and it does not affect your certificate.

### Learner instruction

Rate relevance, clarity, usefulness, accessibility, and confidence. Share general suggestions only.

### Completion note

Survey submitted or skipped according to course policy.

### Safety and privacy note

Do not include complaints, safeguarding details, personal data, confidential records, political details, or sensitive organizational information.

### Buttons

Submit feedback
Skip if allowed
Continue

---

## M9-S6-02 — Closing message

Rights-based work grows through consistent practice: asking better questions, listening more carefully, including those left behind, engaging responsibilities constructively, using evidence safely, and being accountable for change. Start small. Learn with others. Improve as you go.

### Learner instruction

Return to your dashboard, download your certificate if eligible, open your action plan, or explore more courses.

### Completion note

Course closing complete.

### Safety and privacy note

Keep next steps safe, realistic, and non-identifying.

### Button

Continue

---
