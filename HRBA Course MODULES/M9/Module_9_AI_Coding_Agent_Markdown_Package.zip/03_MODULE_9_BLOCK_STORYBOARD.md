# Module 9 Block Storyboard

## Module identity

| Field | Final entry |
|---|---|
| Course title | Applying the Human Rights-Based Approach in CSO Practice |
| Module title | Module 9: Course Closing, Final Test, and Next Steps |
| Module role | Closing / capstone / final-test / certificate / next-step module |
| Recommended duration | 45–60 minutes plus final test time |
| Learner-facing content blocks | 12 |
| Final-test items | 40 |
| Certificate rule | Final test score of 80% or above. Never use 90%. |
| Portfolio/proof rule | Portfolio, 90-day action plan, feedback, proof, story, badges, and peer exchange are separate from certificate. |
| Privacy rule | Portfolio, action plan, feedback comments, and optional notes are private by default. |
| Safety rule | No names, cases, complaints, safeguarding details, confidential documents, legal cases, advocacy targets, political details, raw data, or uploads. |

## Lesson summary

| Lesson | Title | Purpose | Learner action | Key message | Practice/check/test/reflection |
| --- | --- | --- | --- | --- | --- |
| 9.1 | Course Synthesis | Review the full HRBA journey and connect the course’s major practice shifts. | Review the full HRBA journey and connect the course’s major practice shifts. | Closing module supports safe practical application. | Timeline, synthesis cards, private reflection, MCQ |
| 9.2 | Portfolio Review | Review practical tools created during the course without treating them as proof or certificate requirements. | Review practical tools created during the course without treating them as proof or certificate requirements. | Closing module supports safe practical application. | Portfolio checklist, resource links, private reflection, privacy statement |
| 9.3 | Finalize Your 90-Day HRBA Action Plan | Prioritize realistic, safe, rights-based actions for the next 90 days. | Prioritize realistic, safe, rights-based actions for the next 90 days. | Closing module supports safe practical application. | Priority matrix, action-plan tool, scenario decision, commitment |
| 9.4 | Final Test Instructions | Understand final test scope, rules, 80% threshold, accessibility support, and proof separation. | Understand final test scope, rules, 80% threshold, accessibility support, and proof separation. | Closing module supports safe practical application. | Accordion/FAQ, certificate rule statement, readiness checklist |
| 9.5 | Final Test | Complete the certificate-linked final test and understand result states. | Complete the certificate-linked final test and understand result states. | Closing module supports safe practical application. | 40-item final test, pass/not-yet-passed result states, certificate access |
| 9.6 | Feedback and Next Steps | Submit safe feedback and choose one practical next step after the course. | Submit safe feedback and choose one practical next step after the course. | Closing module supports safe practical application. | Feedback survey, optional story guidance, next-step cards, closing message |

## Detailed storyboard table

| Screen ID | Lesson | Screen title | Block type | Learner action | Completion rule | Data saved | Privacy rule | Safety/privacy | Asset requirement |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| M9-S1-01 | 9.1 Course Synthesis | Welcome to the closing module | Learner-facing content block | Take your time. This module is about clarity and practical application, not rushing to the certificate. | Viewed. | Viewed/completion status | No personal data | Do not include names, cases, complaint details, or confidential organizational information in any reflection or action plan. | See asset register if visual applies |
| M9-S1-02 | 9.1 Course Synthesis | Eight ideas to carry forward | Synthesis cards | Read each card and think about where it matters most in your work. | Complete after all cards viewed. | Viewed/completion status | No personal data | No personal or sensitive examples required. | See asset register if visual applies |
| M9-S2-01 | 9.2 Portfolio Review | Review your HRBA practice portfolio | Portfolio checklist / privacy statement | Mark each tool as Complete, Needs review, or Not started. | Complete after all items reviewed. | Portfolio status summary only if saved | Private by default; no uploads | Do not upload raw documents. This is a private review for learning. | See asset register if visual applies |
| M9-S2-02 | 9.2 Portfolio Review | A portfolio is for learning, not surveillance | Portfolio checklist / privacy statement | Use the checklist to decide which tools are useful for your next steps. | Viewed. | Portfolio status summary only if saved | Private by default; no uploads | Keep portfolio outputs private unless your organization chooses a safe and approved sharing process. | See asset register if visual applies |
| M9-S3-01 | 9.3 Action Plan | Turn learning into realistic action | Learner-facing content block | Choose 3–5 actions that are realistic and safe. | Complete when action plan draft is saved. | Viewed/completion status | No personal data | Use broad roles and general priorities. Do not include names, conflict details, complaints, safeguarding information, or confidential records. | See asset register if visual applies |
| M9-S4-01 | 9.4 Final Test Instructions | Prepare for the final test | Final test instruction or assessment block | Review the test scope, rules, support options, and certificate threshold before starting. | Complete when readiness checklist is done. | Final test progress/result | Certificate-linked only through final test score | The test will not ask you to share real cases or confidential information. | See asset register if visual applies |
| M9-S4-02 | 9.4 Final Test Instructions | Certificate rule | Learner-facing content block | Read this rule carefully before starting the test. | Viewed. | Viewed/completion status | No personal data | No 90% threshold is used. | See asset register if visual applies |
| M9-S5-01 | 9.5 Final Test | Final test: HRBA in Local CSO Practice | Final test instruction or assessment block | Answer all final test questions and submit when ready. | Score recorded. Certificate available if score is 80% or above. | Final test progress/result | Certificate-linked only through final test score | Do not enter real names, cases, documents, or sensitive data in the test. | See asset register if visual applies |
| M9-S5-02 | 9.5 Final Test | If you pass | Certificate result state | Download your certificate if the button is shown. | Certificate issued. | Result state | Visible only to learner and authorized platform roles | Certificate data is visible only to you and authorized platform roles. | See asset register if visual applies |
| M9-S5-03 | 9.5 Final Test | If you are not yet passed | Certificate result state | Use the review links before retrying. | No certificate yet. | Result state | Visible only to learner and authorized platform roles | No proof upload can replace the final test threshold. | See asset register if visual applies |
| M9-S6-01 | 9.6 Feedback and Next Steps | Course feedback survey | Feedback survey | Rate relevance, clarity, usefulness, accessibility, and confidence. Share general suggestions only. | Survey submitted or skipped according to course policy. | Survey ratings and optional safe comments | Private/aggregate; no certificate effect | Do not include complaints, safeguarding details, personal data, confidential records, political details, or sensitive organizational information. | See asset register if visual applies |
| M9-S6-02 | 9.6 Feedback and Next Steps | Closing message | Learner-facing content block | Return to your dashboard, download your certificate if eligible, open your action plan, or explore more courses. | Course closing complete. | Viewed/completion status | No personal data | Keep next steps safe, realistic, and non-identifying. | See asset register if visual applies |

## Source block storyboard cross-check

| Internal block ID | Section | Learner-facing title | Block type | Learning purpose | Certificate/proof note | Status |
| --- | --- | --- | --- | --- | --- | --- |
| M09-L01-B01 | 9.1 Course Synthesis | Course Synthesis | Image + intro | Explain/practice/check/apply/reflect | Certificate-linked only if final test block; proof/portfolio/story/feedback separate. | Approved |
| M09-L02-B01 | 9.2 Portfolio Review | Portfolio Review | Timeline/process | Explain/practice/check/apply/reflect | Certificate-linked only if final test block; proof/portfolio/story/feedback separate. | Approved |
| M09-L03-B01 | 9.3 Finalize Your 90-Day HRBA Action Plan | Finalize Your 90-Day HRBA Action Plan | Summary cards | Explain/practice/check/apply/reflect | Certificate-linked only if final test block; proof/portfolio/story/feedback separate. | Approved |
| M09-L04-B01 | 9.4 Final Test Instructions | Final Test Instructions | Private reflection | Explain/practice/check/apply/reflect | Certificate-linked only if final test block; proof/portfolio/story/feedback separate. | Approved |
| M09-L05-B01 | 9.5 Final Test | Final Test | Knowledge check | Explain/practice/check/apply/reflect | Certificate-linked only if final test block; proof/portfolio/story/feedback separate. | Approved after assessment QA |
| M09-L06-B01 | 9.6 Feedback and Next Steps | Feedback and Next Steps | Lesson intro | Explain/practice/check/apply/reflect | Certificate-linked only if final test block; proof/portfolio/story/feedback separate. | Approved |
