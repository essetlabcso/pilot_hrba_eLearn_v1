# Module 9 Design and Visual Interaction Specification

## Module title

**Module 9: Course Closing, Final Test, and Next Steps**

## Design purpose

Module 9 should feel like a calm, structured course-closing experience. It should help learners consolidate learning, review private tools, prepare a realistic action plan, understand the final test and certificate path, complete the final test, and choose next steps.

The experience should not feel like a compliance audit, document upload portal, proof collection system, or punitive exam page.

## Visual identity

| Use | Color |
|---|---|
| Primary action / active progress | `#3B99D4` |
| Positive accent / completion / growth | `#91C852` |
| Deep heading / navigation text | `#0F172A` |
| Main text | `#111827` |
| Secondary text | `#6B7280` |
| Background | `#F9FAFB` |
| Card background | `#FFFFFF` |
| Border | `#E5E7EB` |
| Warning / safety accent | `#F97316` |
| Critical safety warning only | `#EF4444` |

## Source visual interaction controls

| Area | Required specification | Mobile behavior | Low-bandwidth behavior | Motion/safety/style rule | Completion behavior | Status |
| --- | --- | --- | --- | --- | --- | --- |
| Global visual system | DEC blue #3B99D4, green #91C852, navy #0F172A, light #F9FAFB, white cards, dark text #111827, subtle borders, rounded corners, soft shadows. | Single-column readable cards. | Text-only content complete. | No color-only meaning; no unnecessary animation. | N/A | Approved |
| Course timeline | Horizontal timeline with eight course steps. | Stacked step list. | Full text list displayed. | Reduced motion uses instant reveal. | Viewed all steps. | Approved visual specification |
| Synthesis cards | Eight cards with icon + short takeaway. | Two-column/tablet; single-column/mobile. | Text labels visible without icons. | No dense text. | Viewed all cards. | Approved visual specification |
| Portfolio checklist | Interactive statuses Complete/Needs review/Not started. | Stacked checklist items. | Printable/editable table available. | No upload fields. | All items reviewed. | Approved visual specification |
| 90-day action plan | Repeatable action rows with labeled fields. | Stacked form fields. | Printable accessible PDF and in-platform form. | Safety helper before tool. | Draft saved. | Approved visual specification |
| Priority matrix | 2x2 value/effort with drag/tap and list fallback. | List mode default on small screens. | List alternative includes same categories. | No drag-only interaction. | 3+ ideas categorized/skipped. | Approved visual specification |
| Final test instructions | Accordion/FAQ/readiness checklist. | Tap accordions; full-width checklist. | Plain text instructions available. | 80% threshold and proof separation shown. | Readiness complete. | Approved |
| Final test | 40-item mixed-format test using supported item types. | One question at a time or accessible question list. | Text-only items usable. | No open-ended sensitive prompts; no unsupported timer. | Score recorded. | Approved after assessment QA |
| Certificate states | Clear pass, not-yet-passed, retry, certificate issued states. | Stacked result cards/buttons. | Text result state available. | No color-only pass/fail; supportive language. | State displayed based on score. | Approved |
| Feedback survey | Short rating items + optional safe comments. | Mobile form with large controls. | Text-only survey. | Warning before optional text field. | Survey submitted/skipped. | Approved |
| Closing CTA | Buttons: dashboard, certificate if eligible, action plan, more courses. | Full-width buttons. | Text links visible. | No false certificate promise. | Course closing complete. | Approved |

## Section design rules

| Section | Visual / interaction treatment |
|---|---|
| Course Synthesis | Hero image, journey timeline, eight takeaway cards, private reflection, formative synthesis check |
| Portfolio Review | Portfolio checklist, resource bundle, privacy statement, no upload fields |
| 90-Day HRBA Action Plan | Priority/value-effort matrix, action-plan form, scenario decision, quality checklist |
| Final Test Instructions | FAQ/accordion, certificate path diagram, readiness checklist, 80% rule statement |
| Final Test | Accessible 40-item test with clear progress and safe item types |
| Feedback and Next Steps | Safe feedback survey, certificate/result next steps, dashboard/learning CTA |

## Sensitive design rules

- Do not show real certificates with learner data in generic assets.
- Do not show identifiable people, confidential documents, complaint details, legal documents, advocacy plans, or organizational records.
- Use calm completion and practical planning visuals.
- Use green for successful certificate state and clear neutral guidance for not-yet-passed state.
- Do not overuse red; not-yet-passed state should be encouraging, not punitive.

## Mobile behavior

On mobile:

- all layouts become single column;
- timeline becomes stacked steps;
- cards become stacked or two-column on tablet;
- matrices become selectable list/card views;
- final test has clear one-question or short-section navigation;
- result states are screen-reader labeled;
- CTAs are full width.

## Design no-drift rules

The coding agent must not:

- turn Module 9 into new theory-heavy content;
- remove the final test;
- change the 80% certificate threshold;
- use 90% anywhere as an active certificate threshold;
- imply portfolio/action plan/feedback/proof/story/badge/peer exchange determines certificate;
- add upload fields;
- ask for real cases or confidential data;
- use drag-only sorting/matching;
- use “Incorrect” feedback;
- invent asset filenames;
- omit text alternatives for essential visuals.
