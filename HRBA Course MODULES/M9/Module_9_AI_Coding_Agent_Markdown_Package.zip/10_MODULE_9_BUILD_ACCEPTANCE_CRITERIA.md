# Module 9 Build Acceptance Criteria

## Source acceptance criteria

| Criteria area | Acceptance criterion | Pass condition | Status |
| --- | --- | --- | --- |
| Module structure | Six lessons appear in approved order; Module 9 functions as closing/capstone/final-test module, not new theory content. | Preview correct. | Approved |
| Content quality | Learner-facing content is plain, warm, practical, and free of internal notes. | Content review pass. | Approved |
| HRBA synthesis | Timeline and cards accurately synthesize Modules 1–8 without unsupported concepts. | SME review pass. | Approved |
| Action-plan quality | 90-day plan supports 3–5 realistic, safe, rights-based actions with first steps/risk checks. | Tool QA pass. | Approved |
| Final-test validity | 40-item item bank covers approved domains; application-based; no sensitive real-case prompts. | Assessment reviewer approval required. | Approved after assessment QA |
| Certificate behavior | Certificate issued only for final test score 80%+; no 90%; no proof/story/feedback/portfolio requirement. | System/content checks pass. | Approved |
| Feedback quality | Survey is for course improvement and avoids sensitive data. | Survey QA pass. | Approved |
| Proof/portfolio separation | Portfolio, action plan, proof, badges, achievements, stories, peer exchange, and feedback separate from certificate. | Check pass. | Approved |
| Safety/privacy | No prompts request sensitive uploads, names, real cases, complaints/safeguarding records, legal diagnosis, or civic-space details. | Safety scan pass. | Approved |
| Asset readiness | All assets have approved filename, purpose, prompt, alt text, and low-bandwidth alternative. Actual files must be produced/uploaded during implementation. | Asset specification QA pass; production/upload remains implementation task. | Approved asset specification |
| Accessibility | Accessibility requirements are approved: keyboard, screen-reader labels, focus, alt text, non-drag alternatives, accessible PDFs/forms, and no color-only result states. | Accessibility requirements ready for implementation and post-build QA. | Approved |
| Mobile/low-bandwidth | Single-column mobile layout and essential learning usable without images/downloads. | Mobile/low-bandwidth pass. | Approved |
| Implementation route | Approved route/path confirmed in repo before implementation. | Implementation agent confirms actual route in repo before coding. | Approved with repo route confirmation |
| Optional story/proof | Disabled by default unless safe consent-based workflow approved; never certificate-linked. | Optional story/proof remains disabled by default and is not certificate-linked. | Deferred — disabled by default |

## Additional clean-package acceptance checks

| Check | Pass condition |
|---|---|
| Clean content only | Learner-facing build excludes QA history, source inventories, evidence packs, change logs, approval locks, and internal reviewer notes. |
| Approved function | Module 9 functions as closing/capstone/final-test module, not new theory content. |
| Approved sequence | Six lessons appear in approved order: Synthesis; Portfolio; Action Plan; Final Test Instructions; Final Test; Feedback and Next Steps. |
| Content block count | 12 learner-facing content blocks are represented. |
| Final test count | 40 final-test items are implemented or adapted accessibly. |
| Certificate threshold | Certificate requires final test score of 80% or above. |
| Forbidden threshold | No active 90% certificate threshold appears anywhere. |
| Certificate separation | Portfolio, action plan, proof, story, badges, peer exchange, and feedback do not affect certificate eligibility. |
| Feedback wording | Weaker formative responses use “Not quite,” not “Incorrect.” |
| Privacy | Portfolio, action plan, feedback comments, and optional notes are private by default. |
| No sensitive data | No screen asks for names, cases, complaints, safeguarding details, confidential documents, real legal cases, advocacy targets, political details, uploads, or raw data. |
| Optional story/proof | Disabled by default unless separate consent workflow is approved. |
| Accessibility | All interactions and test items are keyboard/tap accessible and screen-reader friendly. |
| Low bandwidth | Essential learning/test instructions do not depend on heavy media, PDFs, uploads, or external embeds. |
| Asset control | Source-named assets are preserved; missing assets remain placeholders. |
| Metadata hidden | Learners do not see screen IDs, block IDs, source IDs, QA notes, or implementation metadata. |
