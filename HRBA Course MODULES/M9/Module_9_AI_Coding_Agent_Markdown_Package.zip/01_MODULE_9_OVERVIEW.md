# Module 9 Overview

## Course

**Applying the Human Rights-Based Approach (HRBA) in CSO Practice**

## Module title

**Module 9: Course Closing, Final Test, and Next Steps**

## Module role

Module 9 is the closing, synthesis, action-planning, final-test, certificate, and next-step module. It consolidates course learning, helps learners review their practical tools, supports a realistic 90-day HRBA action plan, explains the final test and certificate rule, runs the certificate-linked final test, and invites safe feedback.

## Recommended duration

**45–60 minutes**, plus time for the final test.

## Primary audience

Local and grassroots CSO learners completing the HRBA course.

## Main learner shift

From:

> “I finished the learning screens.”

To:

> “I can summarize the HRBA shifts, review my tools privately, choose realistic next actions, understand the certificate rule, complete the final test, and continue applying HRBA safely.”

## Module learning outcomes

By the end of Module 9, participants should be able to:

1. synthesize the key HRBA shifts from the full course;
2. review their practical HRBA portfolio as a private learning resource;
3. prioritize 3–5 safe and realistic HRBA actions for the next 90 days;
4. understand final test scope, rules, accessibility support, and certificate threshold;
5. complete the final course test;
6. distinguish certificate requirements from portfolio, proof, story, badge, peer exchange, and feedback activities;
7. submit safe course feedback or skip according to platform policy.

## Approved lesson sequence

1. **Course Synthesis**
2. **Portfolio Review**
3. **Finalize Your 90-Day HRBA Action Plan**
4. **Final Test Instructions**
5. **Final Test**
6. **Feedback and Next Steps**

## Main portfolio/tool outputs

- Most important HRBA shift reflection
- Portfolio completion checklist
- 90-Day HRBA Action Plan
- Final test readiness checklist
- Final test result state
- Course feedback survey
- Closing next-step choices

## Assessment and certificate rule

The final test has **40 items** and is the only certificate-linked assessment. Certificate eligibility requires a final test score of **80% or above**.

Portfolio completion, 90-day action plan, optional proof, application story, badges, peer exchange, and feedback survey completion do **not** determine certificate eligibility.

## Safety level

High because the closing module touches portfolio outputs, action plans, final-test state, optional proof/story boundaries, and feedback. The module must not request sensitive organizational, legal, safeguarding, complaint, advocacy, political, or raw data.

## Privacy rule

Portfolio, action plan, readiness status, feedback comments, and optional notes are private by default.

## Sensitive data rule

Do not ask learners to provide names, cases, complaint details, safeguarding details, confidential documents, real legal cases, advocacy targets, political details, raw data, or uploads.

## Final build scope

The build must include:

- 12 learner-facing content blocks;
- 40 final-test items;
- pass and not-yet-passed result states;
- certificate behavior with an exact 80% threshold;
- safe feedback and next-step flow.
