# Module 9 Safety, Accessibility, and Data Rules

## Safety principle

Module 9 has a high safety level because it touches portfolio outputs, action plans, final-test result states, feedback, optional proof/story boundaries, and certificate behavior.

The module must help learners close the course safely without exposing people, organizations, complaints, safeguarding details, legal cases, advocacy targets, confidential documents, political details, raw data, or uploads.

## Safety rules from source workbook

| Safety rule | Where addressed | Learner-facing wording | Pass condition | Repetition-reduction decision | Boundary type | Status |
| --- | --- | --- | --- | --- | --- | --- |
| Do not collect sensitive real data | Action plan, portfolio, feedback, final test, optional story/proof | Use general learning examples. Do not enter names, complaint details, safeguarding details, confidential documents, real legal cases, political details, or raw data. | All prompts avoid requesting sensitive data. | Use once in opening safety reminder and point-of-risk reminders. | Core boundary | Approved |
| Portfolio privacy | 9.2 Portfolio Review | Your portfolio is for learning and internal improvement. You do not need to upload raw documents here. | No upload fields in portfolio checklist. | Not repeated excessively. | Proof boundary | Approved |
| Action-plan privacy | 9.3 Action Plan | Keep your action plan practical and general. Use broad roles, not names or sensitive details. | Action plan fields include helper text. | Point-of-risk before tool. | Action-plan boundary | Approved |
| Final-test privacy | 9.4/9.5 Final Test | The final test will not ask you to share real cases or confidential information. | No open-ended real-case prompts. | Visible before test. | Assessment boundary | Approved |
| Certificate/proof separation | 9.4/9.5 Certificate states | Certificate depends only on final test score of 80% or above. Practical proof, portfolio, stories, feedback, and peer exchange are separate. | Certificate wording and states use exact rule. | Instruction and result states only. | Certificate boundary | Approved |
| Feedback privacy | 9.6 Survey | Course feedback is for improving the course. Do not include complaints, safeguarding details, personal data, political details, or confidential organizational information. | Survey avoids sensitive prompts. | Visible before optional text field. | Feedback boundary | Approved |
| Optional application story safety | 9.6 Optional story | Sharing an application story is optional, anonymized, consent-based, and separate from certificate. | Feature disabled unless consent workflow approved. | Only shown if optional block included. | Story/proof boundary | Deferred — disabled by default |
| No legal advice | Final test and synthesis where legal/regulatory issues appear | This course supports learning. It does not provide legal advice or ask you to diagnose real legal violations. | No item asks legal diagnosis. | Use only if legal/regulatory item appears. | Legal boundary | Approved |
| Data minimization | All tools and survey | Collect only what is needed for learning, feedback, certificate, or safe improvement. | No unnecessary uploads or identifiers. | Embedded in tool design. | Privacy boundary | Approved |
| No shame in retry state | 9.5 Result not passed yet | You have not reached 80% yet. Review recommended sections and try again according to course rules. | Supportive wording. | Single result message. | Learner safety | Approved |

## Do not request

Never ask learners to submit:

- names;
- real cases;
- complaint details;
- safeguarding or protection details;
- confidential documents;
- real legal cases;
- advocacy targets;
- political details;
- raw organizational data;
- beneficiary/staff lists;
- uploads.

## Safe alternatives

Use:

- general learning examples;
- broad roles rather than names;
- safe summaries;
- private status checklists;
- structured action-plan fields;
- optional comments with clear safety warning;
- safe aggregated analytics only.

## Final test privacy boundary

Use before the test:

> The final test will not ask you to share real cases or confidential information.

## Certificate boundary

Use wherever results are explained:

> Certificate eligibility is based only on the final test score of 80% or above. Portfolio tools, action plans, stories, proof, peer exchange, badges, and feedback are separate from the certificate.

## Accessibility and low-bandwidth QA

| QA area | Where it applies | Requirement | Pass condition | Status |
| --- | --- | --- | --- | --- |
| Keyboard access | All interactions, final test, survey, action-plan tool | All controls reachable and operable by keyboard. | Manual keyboard test passes. | Approved |
| Screen-reader labels | Timeline, cards, checklist, action-plan form, final test, certificate states, feedback survey | Every control and field has meaningful label and state. | Screen-reader label check passes. | Approved |
| Visible focus | Buttons, cards, accordions, test controls, certificate download | Focus indicator visible and high contrast. | Focus visible on all interactive elements. | Approved |
| Alt text | All images and visual assets | Every visual has meaningful alt text. | Alt text present. | Approved with asset QA |
| Text alternatives | Timeline, synthesis cards, matrix, certificate path diagram | Text equivalent available near/under visual or to screen reader. | Learning remains usable without images. | Approved |
| Non-drag alternatives | Priority matrix, sorting/matching test items | List/tap alternatives provided; no drag-only action. | Fallback works. | Approved |
| Accessible final-test behavior | Final test controls/result states | Item formats accessible; result states not color-only; submit confirmation clear. | Assessment QA passes. | Approved after assessment QA |
| Accessible PDFs/forms | Portfolio checklist, action plan, application story guidance | Tagged accessible PDFs or editable alternatives. | Accessibility QA passes. | Approved with PDF/form QA |
| Mobile readability | All sections | Single-column mobile layout; tables converted to stacked cards where needed. | Mobile preview passes. | Approved |
| Low-bandwidth fallback | All visuals/resources | Essential learning available without images/downloads; individual downloads available. | Low-bandwidth mode usable. | Approved |
| Reduced motion | Timeline/cards/result states | No unnecessary animation; static transitions for reduced motion. | Reduced-motion setting respected. | Approved |
| Timer behavior | Final test | No timer assumed unless approved; if added, must follow accessibility/support rules. | No unsupported timer. | Approved |

## AI/data restriction

Raw reflections, action-plan fields, feedback comments, test free-text, proof/story content, portfolio notes, and private learner notes should not be sent to AI services. If AI is later used for safe aggregate summaries, use structured non-sensitive tags or participant-approved safe summaries only.

## Safe helper text

Use before any optional text field or tool output:

> Keep this safe and general. Do not include names, cases, complaint details, safeguarding details, confidential documents, real legal cases, advocacy targets, political details, raw organizational data, or uploads.
