# Module 9 Certificate, Feedback, and Next Steps

## Certificate behavior

| Behavior area | Rule | System behavior | Learner-facing wording | Safety/privacy note | Accessibility note | Status |
| --- | --- | --- | --- | --- | --- | --- |
| Certificate rule | Final test score of 80% or above. | Certificate issued only if final test percentage >=80%. | If you score 80% or above, you pass the course and receive your certificate. | No 90% threshold allowed. | Accessible text state, not color only. | Approved |
| Not-yet-passed state | Score below 80%. | No certificate issued; show supportive review/retry message. | You have not reached 80% yet. Review recommended sections and try again according to the course rules. | No shame language; no proof substitution. | Result message readable by screen readers. | Approved |
| Retry behavior | Follow platform/course policy for attempts. | Retry option or review pathway displayed if configured. | You may review the course and retry according to the course rules. | Do not invent attempt limit if not configured. | Retry button accessible. | Approved with platform policy check |
| Certificate-issued state | Score 80% or above and system certificate generation succeeds. | Certificate button/display available. | Congratulations. You passed the course. Your certificate is available. | Certificate data visible only to learner and authorized platform roles. | Button/links clearly labeled. | Approved |
| Proof separation | Practical proof is not required for certificate. | Proof status must not block certificate if final test is passed. | Practical proof and verified achievements are separate pathways. | Raw proof private by default; no upload required here. | Proof section not tied to certificate state. | Approved |
| Badge/verified achievement separation | Badges/verified achievements are separate from certificate. | Badge status must not affect certificate eligibility. | Badges or verified achievements may be offered separately where enabled. | Consent and review needed for external visibility. | Separate UI labels. | Approved |
| Portfolio separation | Portfolio/action plan do not determine certificate. | Portfolio completion not certificate prerequisite. | Portfolio tools support learning and application only. | Private by default; no upload required. | Checklist not tied to certificate gating. | Approved |
| Application story separation | Application stories are optional and separate from certificate. | No story required; disabled unless safe workflow enabled. | Sharing an application story is optional and not required for your certificate. | Consent/anonymization required if enabled. | Optional pathway clearly labeled. | Deferred — disabled by default |
| Feedback separation | Feedback survey does not determine certificate. | Feedback response cannot block/trigger certificate. | Your feedback helps improve the course and does not affect your certificate. | No sensitive data requested. | Survey accessible and skippable if policy allows. | Approved |
| System behavior | Final test submitted → score calculated → pass/fail set → certificate issued if >=80. | Automated or configured in course player. | System shows result and next steps. | No public exposure of score beyond authorized roles. | Result states accessible. | Approved with platform configuration check |

## Feedback and next-step behavior

| Item ID | Element | Prompt / learner-facing text | Response behavior | Data use statement | Safety note | Accessibility requirement | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| FB-M09-001 | Relevance rating | How relevant was this course to your CSO work? | 1–5 rating + optional safe comment | Course improvement only | Do not include sensitive cases or confidential details. | Keyboard/tap accessible rating | Approved |
| FB-M09-002 | Clarity rating | How clear was the course language and structure? | 1–5 rating | Improve plain-language design | No personal data required. | Accessible label and scale | Approved |
| FB-M09-003 | Interaction usefulness | Which activities were most useful for learning? | Select all: scenarios; checklists; tools; reflections; final test prep; other | Improve block design | No sensitive examples requested. | Multi-select accessible | Approved |
| FB-M09-004 | Confidence shift | After the course, how confident do you feel applying HRBA in one practical area? | 1–5 rating | Adaptive learning insight | Do not ask for real cases. | Accessible scale | Approved |
| FB-M09-005 | Accessibility feedback | Was anything difficult to use on mobile, with low bandwidth, or with accessibility tools? | Yes/No + optional safe detail | Accessibility improvement | Keep general; do not request health/disability details. | Accessible text field with warning | Approved |
| FB-M09-006 | General improvement suggestion | What should be improved in future versions? | Optional short text | Course improvement | Do not include names, complaints, safeguarding details, political issues, or confidential records. | Accessible text area; character limit | Approved |
| NEXT-M09-001 | Optional next-step reflection | Choose one safe next step after the course. | Cards/dropdown | Private learner support | Use broad non-identifying next steps. | Accessible card/dropdown | Approved |
| STORY-M09-001 | Optional application story guidance | If enabled later, learners may share an anonymized, consent-based story separate from certificate. | Guidance card only; disabled by default | Future application evidence only | No real names, photos, survivor/child/community details, complaints, or confidential information. | Accessible guidance card/PDF | Deferred — disabled by default |
| DATA-M09-001 | Data use statement | Your feedback will be used to improve the course. It does not affect your certificate. | Displayed before survey | Transparency/accountability | No external sharing of raw identifiable comments without safeguards. | Screen-reader visible note | Approved |
| PEER-M09-001 | Peer/follow-up boundary | No required peer exchange in Module 9 self-paced flow. | Not included | No certificate/proof implication | If enabled later, moderated and generalized. | N/A | Approved |

## Binding certificate logic

```text
final_test_score = correct_items / 40 * 100

if final_test_score >= 80:
  course_status = "passed"
  certificate_available = true
else:
  course_status = "not_yet_passed"
  certificate_available = false
```

## Explicit non-certificate inputs

The following must not issue or unlock certificates:

- portfolio review;
- 90-day action plan;
- optional proof;
- application story;
- badges;
- verified achievements;
- peer exchange;
- feedback survey;
- facilitator review;
- resource download.

## Result-state wording

### Pass state

> Congratulations. You scored 80% or above on the final test. You have passed the course and your certificate is available.

### Not-yet-passed state

> You have not reached 80% yet. This does not erase your learning. Review the recommended sections and try again according to the course rules.

## Feedback survey safety wording

> Your feedback helps improve future versions of the course. It is not a test and it does not affect your certificate. Share general suggestions only. Do not include complaints, safeguarding details, personal data, confidential records, political details, or sensitive organizational information.
