# Module 9 Asset Placeholders and Alt Text

## Asset rule

Do not invent final asset filenames or paths. Use approved source-named assets where listed. If a file is missing, use a placeholder component with the approved filename reference.

## Visual style

Use CSO Learning Hub / DEC visual identity:

- primary blue: `#3B99D4`
- accent green: `#91C852`
- deep navy: `#0F172A`
- light background: `#F9FAFB`
- white cards
- dark text: `#111827`
- subtle borders: `#E5E7EB`
- rounded corners
- soft shadows

## Asset register

| Asset ID | Filename | Type | Used in | Purpose | Production specification | Required format | Alt text | Priority | Safety/privacy note | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-M09-001 | closing-module-hero.jpg | Photographic hero | M09-L01-B01 | Introduce closing module with calm completion mood | Realistic Ethiopian/East African CSO team reviewing worksheets and action plan notes in a modest training room; no text/logos/UI; professional but not corporate. | JPG/SVG/PDF/ZIP/In-platform as specified | CSO team reviewing learning worksheets and an action plan in a modest meeting room. | High | No recognizable faces, readable text, logos, or confidential documents. | Approved asset specification |
| A-M09-002 | hrba-course-journey-timeline.svg | Timeline diagram | M09-L01-B02 | Summarize full HRBA learning journey | DEC blue/green timeline with eight steps and simple icons; responsive stacked mobile version. | JPG/SVG/PDF/ZIP/In-platform as specified | Diagram showing the eight steps of the HRBA course journey. | High | No dense text or sensitive references. | Approved asset specification |
| A-M09-003 | eight-hrba-takeaways-icon-grid.svg | Icon grid | M09-L01-B03 | Show eight key HRBA takeaways | Eight white cards with line icons: rights-holder, duty-bearer, participation, inclusion, accountability, do-no-harm, MEAL evidence, internal practice. | JPG/SVG/PDF/ZIP/In-platform as specified | Eight cards summarizing core HRBA takeaways. | High | No real examples or sensitive text. | Approved asset specification |
| A-M09-004 | portfolio-review-checklist.pdf | Checklist PDF | M09-L02-B02 | Support portfolio review | Accessible checklist listing tools with Complete/Needs review/Not started columns. | JPG/SVG/PDF/ZIP/In-platform as specified | Portfolio review checklist for HRBA course tools. | High | No uploads; private use. | Approved asset specification |
| A-M09-005 | hrba-toolkit-resource-bundle.zip | Resource bundle | M09-L02-B03 | Bundle blank tools/templates | Accessible PDFs/Word docs: self-assessment, RH/DB map, problem analysis, risk checklist, MEAL indicator worksheet, 90-day plan. | JPG/SVG/PDF/ZIP/In-platform as specified | Downloadable package of HRBA course tools. | High | Blank templates/fictional examples only. | Approved asset specification |
| A-M09-006 | action-planning-team.jpg | Photographic image | M09-L03-B01 | Support final action planning | Local CSO team discussing a practical action plan around printed templates; no readable text/logos. | JPG/SVG/PDF/ZIP/In-platform as specified | CSO team reviewing an action plan template together. | High | No recognizable faces/confidential docs. | Approved asset specification |
| A-M09-007 | priority-matrix.svg | Matrix diagram | M09-L03-B02 | Help prioritize HRBA actions | 2x2 value/effort matrix with accessible labels and DEC accents. | JPG/SVG/PDF/ZIP/In-platform as specified | Matrix for prioritizing HRBA improvement actions. | High | No color-only meaning. | Approved asset specification |
| A-M09-008 | 90-day-hrba-action-plan-template.pdf | Worksheet PDF | M09-L03-B03 | Main final application output | Fillable action plan with fields: priority, change, first step, role/team, support, risk, progress sign, target date. | JPG/SVG/PDF/ZIP/In-platform as specified | 90-day HRBA action plan template. | High | No sensitive prompts; private output. | Approved asset specification |
| A-M09-009 | certificate-path-diagram.svg | Diagram / FAQ visual | M09-L04-B03 | Clarify final test and certificate pathway | Flow: Review → Final test → Score 80%+ → Certificate; proof/story/portfolio/feedback separate. | JPG/SVG/PDF/ZIP/In-platform as specified | Diagram showing final test and certificate pathway. | High | Must show 80%, never 90%. | Approved asset specification |
| A-M09-010 | certificate-success-card.svg | Result state visual | M09-L05-B03 | Support pass state | Accessible success card with DEC green accent and certificate icon; no personal details. | JPG/SVG/PDF/ZIP/In-platform as specified | Success card indicating certificate available after passing. | High | No real certificate data in asset. | Approved asset specification |
| A-M09-011 | certificate-download-icon.svg | Icon | M09-L05-B05 | Support certificate access | Simple line icon of certificate/download; no fake certificate number. | JPG/SVG/PDF/ZIP/In-platform as specified | Certificate download icon. | Medium | No personal data in icon. | Approved asset specification |
| A-M09-012 | continued-learning-image.jpg | Photographic image | M09-L06-B01 | Support next-step mood | Local CSO team having a practical planning conversation; modest setting; hopeful tone. | JPG/SVG/PDF/ZIP/In-platform as specified | CSO team discussing next steps after training. | Medium | No identifiable faces/text/logos. | Approved asset specification |
| A-M09-013 | application-story-template.pdf | Guidance card / PDF | M09-L06-B03 | Optional application story guidance | One-page guidance: optional, anonymized, consent-based, no sensitive data, separate from certificate. | JPG/SVG/PDF/ZIP/In-platform as specified | Guidance card for optional safe application story. | Medium | Disabled unless program enables. | Approved asset specification |
| A-M09-014 | course-feedback-survey-form | In-platform survey | M09-L06-B02 | Capture safe feedback | In-platform form with ratings and safe optional comments; no sensitive prompts. | JPG/SVG/PDF/ZIP/In-platform as specified | Course feedback survey form. | Medium | No sensitive data requested. | Approved asset specification |
| A-M09-015 | next-step-cards.svg | Icon card set | M09-L06-B04 | Support choice of safe next step | Six simple cards: discuss plan, use one tool, improve feedback, adjust activity, team learning, explore course. | JPG/SVG/PDF/ZIP/In-platform as specified | Cards showing safe next-step options. | Medium | No risky advocacy prompts. | Approved asset specification |
| A-M09-016 | closing-illustration.svg | Closing illustration | M09-L06-B05 | Close course with positive tone | Warm DEC-style pathway from learning cards to action; no political imagery. | JPG/SVG/PDF/ZIP/In-platform as specified | Illustration showing learning moving into practical action. | Medium | No logos/flags/political imagery. | Approved asset specification |

## Asset implementation rules

- Every image/SVG must include alt text.
- Complex diagrams need text alternatives.
- PDF/XLSX tools must also have in-platform field versions where feasible.
- Do not use photos that identify people or sensitive situations.
- Do not show real certificates with real learner data in generic assets.
- Do not show readable complaint details, legal documents, advocacy plans, political signage, internal records, or confidential materials.
- Avoid text-heavy images; all essential text must also exist as HTML text.
- If assets are missing, render placeholder cards using the approved filename reference.
