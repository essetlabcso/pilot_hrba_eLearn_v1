# Module 7 Reflection and Portfolio Logic

## Portfolio principle

Module 7 produces private MEAL and evidence-use practice tools. These outputs help the learner strengthen rights-based indicators, disaggregation choices, feedback loops, ethical stories, and adaptation decisions. They are private by default, not graded, not certificate-linked, and not visible externally by default.

## Main Module 7 portfolio/tool outputs

1. Evidence-use reflection
2. HRBA indicator worksheet
3. Disaggregation safety checklist
4. Feedback loop repair note
5. Ethical story checklist
6. Adaptation decision note

## Portfolio behavior table

| Reflection/tool ID | Tool/reflection | Placement | Required status | Visibility | Save behavior | Skip behavior | Portfolio implication | Proof implication | Certificate implication | Safety rule |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| REF-M7-01 | Evidence-use reflection | M07-L01 | Optional | Private by default | Learner may save a short general note; no real data. | Skippable | Optional private portfolio note only | No proof implication | No certificate implication | Do not mention real projects, names or sensitive information. |
| REF-M7-02 | Indicator worksheet | M07-L02 | Optional | Private by default | Learner may draft a revised fictional indicator. | Skippable | Private tool output | No proof implication | No certificate implication | Use sample indicator only. |
| REF-M7-03 | Disaggregation safety checklist | M07-L03 | Optional | Private by default | Learner checks safe collection/display decisions. | Skippable | Private checklist | No proof implication | No certificate implication | No sensitive small-cell data. |
| REF-M7-04 | Ethical story checklist | M07-L05 | Optional | Private by default | Learner applies ethical checklist to fictional story. | Skippable | Private checklist | No proof implication | No certificate implication | No real stories. |
| REF-M7-05 | Learning-use plan | M07-L06 | Optional | Private by default | Learner drafts safe learning-use plan. | Skippable | Private plan | No proof implication | No certificate implication | No real data or project details. |

## Final Module 7 portfolio checkpoint

The main integrated checkpoint is the **HRBA Evidence Use Action**.

### Saved fields

- broad MEAL/evidence practice area;
- evidence-use gap;
- rights-based evidence question;
- indicator improvement idea;
- disaggregation safety decision;
- feedback-loop repair action;
- ethical story/evidence safeguard;
- adaptation decision;
- optional private note.

### Safety helper text

Use before any optional text field:

> Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

## Save behavior

When the learner saves a Module 7 output:

```text
save:
  module_id = M07
  output_type
  structured selections
  optional private note if entered
  timestamp

do_not_save:
  real datasets
  reports
  feedback records
  stories
  photos
  audio
  video
  names
  complaints
  safeguarding/protection details
  confidential records
  political details
  raw organizational data
  uploaded files
```

## Deterministic synthesis logic

| Rule ID | Input | Output |
|---|---|---|
| `M7_SYN_01` | evidence-use reflection | Add to “How MEAL should support rights-based decisions” |
| `M7_SYN_02` | indicator worksheet | Add to “Indicator improvement idea” |
| `M7_SYN_03` | disaggregation checklist | Add to “Safe inclusion evidence decision” |
| `M7_SYN_04` | feedback loop repair | Add to “Feedback response and report-back action” |
| `M7_SYN_05` | ethical story checklist | Add to “Qualitative evidence safeguard” |
| `M7_SYN_06` | adaptation note | Add to “Evidence-informed adaptation action” |
| `M7_SYN_07` | optional private notes | Include only in private export; never in safe-share summary |
| `M7_SYN_08` | skipped saves | Show “Not saved yet — you can return later,” without penalty |

## Carry-forward logic

| Later module | How Module 7 portfolio data is reused |
|---|---|
| Module 8 — Accountability and Learning | Use feedback loop repair, ethical evidence safeguards, and report-back actions to strengthen accountability practice. |
| Module 9 — Course Closing and 90-Day Action Plan | Use indicator improvement, disaggregation safety, feedback repair, and adaptation action as candidates for the 90-day HRBA action plan. |

## Visibility rules

| User type | Can see Module 7 portfolio content? |
|---|---|
| Participant | Yes, their own private portfolio |
| Course facilitator | No by default; only safe aggregate or consent-based summary if enabled |
| CSO focal person | No individual notes by default |
| Peer participant | No |
| Donor or external partner | No |
| Admin dashboard | Aggregate tags only, no raw notes or evidence |
| AI service | No raw reflections, evidence-use drafts, worksheet entries, or private notes |
