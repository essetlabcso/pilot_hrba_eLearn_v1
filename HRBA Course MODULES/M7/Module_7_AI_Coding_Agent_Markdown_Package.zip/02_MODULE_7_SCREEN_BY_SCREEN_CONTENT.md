# Module 7 Screen-by-Screen Learner-Facing Content

# Module 7: HRBA in MEAL and Evidence Use

## Module introduction

Welcome to Module 7.

In earlier modules, you explored human rights, HRBA principles, rights-holders, duty-bearers, power, exclusion, project design, and implementation. This module now focuses on MEAL and evidence use.

Rights-based MEAL is not only about counting activities or preparing reports. It helps a CSO understand who is included, who is left out, what people say, what changed, what risks exist, and how evidence should improve practice.

### Safety reminder

Use only fictional, synthetic, anonymized, or generalized examples. Do not enter or upload real datasets, reports, feedback records, stories, photos, audio, video, names, complaints, safeguarding details, confidential records, political details, or raw organizational data.

### Certificate reminder

Module 7 tools and checks are formative. Your certificate is linked to the final course test with a score of 80% or above.


# M07-L01 — What Makes MEAL Rights-Based?

## M7-S1-01 — Scenario hook

A fictional local CSO has strong attendance numbers for a community dialogue. The team can report that 120 people attended.

But they do not know:

- who could not attend;
- whether women with disabilities, young volunteers, or remote participants were included;
- what people said about barriers;
- whether feedback led to any change;
- whether collecting more data would be useful or risky.

A rights-based MEAL approach does not ignore numbers. It asks what the numbers do not show.

### Learner action

Read a fictional CSO evidence-use dilemma and identify what is missing from count-only MEAL.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

images/module7/hrba-meal-opening.jpg

### Button

Continue

---

## M7-S1-02 — Plain-language explainer

Rights-based MEAL uses evidence to improve dignity, participation, inclusion, accountability, and learning.

It asks:

- Who participated?
- Who was left out?
- What barriers did people face?
- What did people say?
- What changed because of the evidence?
- What should the CSO do differently?
- What data would be useful, safe, and proportionate?

Numbers matter, but numbers alone are not enough.

### Learner action

Understand the shift from activity counting to rights-based evidence use.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---

## M7-S1-03 — Guided practice

Sort each sample evidence use into one of three categories:

1. **Count-only evidence** — useful but incomplete.
2. **Rights-based quality evidence** — helps understand inclusion, voice, accountability, or change.
3. **Unsafe or excessive evidence** — collects more sensitive detail than needed.

Sample cards:

- Number of people who attended the session.
- Which groups were missing and why.
- What participants said about barriers.
- Names and disability status of every participant in a small group.
- What the CSO changed after feedback.
- Photos of participants shared publicly without clear consent.

Feedback should explain that count-only evidence may be useful, rights-based quality evidence improves decisions, and unsafe/excessive evidence should be avoided or redesigned.

### Learner action

Sort sample evidence uses into count-only, rights-based quality, and unsafe/excessive evidence.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

images/module7/hrba-meal-opening.jpg

### Button

Submit and view feedback

---

## M7-S1-04 — Private reflection/tool

Save one private evidence-use takeaway.

Prompt:

**One thing our MEAL should help us understand is...**

Choose or write a broad note, such as:

- who was included and who was missing;
- whether feedback changed practice;
- whether an activity was accessible;
- whether evidence is safe and useful.

Your note is private by default and does not affect your certificate.

### Learner action

Save one safe takeaway about how evidence should improve decisions.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

images/module7/hrba-meal-opening.jpg

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M7-S1-05 — Formative check

Question: Which question makes MEAL more rights-based?

A. How many people attended?  
B. Who was included or left out, what did they say, and what changed?  
C. How many photos were taken?

Best response: B

Feedback for A: Not quite. Attendance is useful, but it does not show inclusion, voice, accountability, or change by itself.  
Feedback for B: That’s right. Rights-based MEAL asks who is included, who is left out, what people said, and what changed because of evidence.  
Feedback for C: Not quite. Photos can create privacy and consent risks and do not show rights-based quality by themselves.

### Learner action

Answer a short formative check about rights-based MEAL questions.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Submit and view feedback

---

## M7-S1-06 — Lesson summary and transition

Key takeaway:

Shift from counting activities upward to using evidence for rights, inclusion, accountability, learning, and safer decisions.

Before moving on, remember:

- use only fictional or generalized examples;
- avoid names, raw data, stories, photos, audio, video, or confidential records;
- use evidence to improve participation, inclusion, accountability, and learning.

Next: **HRBA Indicators**.

### Learner action

Review the key idea and continue to HRBA indicators.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---


# M07-L02 — HRBA Indicators

## M7-S2-01 — Scenario hook

A fictional CSO reports this indicator:

**“Number of trainings conducted.”**

This tells us that activities happened. It does not tell us whether participation was meaningful, whether excluded groups were reached, whether feedback was acted on, or whether practice changed.

In this lesson, you will practice improving weak indicators so they show rights-based quality, not only activity delivery.

### Learner action

Read a fictional example of a weak indicator that only counts training delivery.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/hrba-indicator-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M7-S2-02 — Plain-language explainer

Indicators help a CSO know whether practice is changing.

A weak indicator may only count activities, such as the number of trainings held.

A stronger HRBA indicator may show:

- whether participation was inclusive;
- whether feedback was received and answered;
- whether barriers were reduced;
- whether duty-bearers or responsible actors became more responsive;
- whether rights-holders experienced safer access, voice, or accountability.

Use indicators to support learning and action, not only reporting.

### Learner action

Compare activity/output, structural, process, outcome, and HRBA-aligned indicators.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---

## M7-S2-03 — Guided practice

Use the fictional weak indicator:

**“Number of community meetings held.”**

Choose the strongest HRBA improvement:

A. Number of meetings held.  
B. Number of participants photographed at meetings.  
C. Percentage of meetings where excluded groups participated safely and feedback was documented, reviewed, and reported back.  
D. Number of pages in the donor report.

Best response: C

Then, if the platform supports it, rewrite one weak indicator using this structure:

**Who or what changes + which HRBA quality + how we will know safely.**

### Learner action

Choose the strongest HRBA indicator and improve one weak fictional indicator.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

tools/module7/hrba-indicator-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M7-S2-04 — Private reflection/tool

Draft one safer HRBA indicator using a fictional example.

Suggested structure:

**Who or what changes + HRBA quality + safe way to know.**

Example:

“Percentage of community meetings where excluded groups participated safely and feedback was reviewed and reported back.”

Do not use a real donor indicator, real project name, or confidential proposal text.

### Learner action

Draft a revised fictional indicator privately or download the worksheet.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/hrba-indicator-worksheet.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M7-S2-05 — Formative check

Question: Which is closest to a process indicator?

A. Existence of a policy.  
B. Number of safe feedback sessions held with report-back.  
C. Change in trust after response.

Best response: B

Feedback for A: Not quite. Existence of a policy is closer to a structural indicator because it shows a formal commitment or framework.  
Feedback for B: That’s right. Process indicators track efforts and practices, such as safe feedback sessions and report-back.  
Feedback for C: Not quite. Change in trust is closer to an outcome indicator because it shows a change experienced by people.

### Learner action

Answer a short formative check about process indicators.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Submit and view feedback

---

## M7-S2-06 — Lesson summary and transition

Key takeaway:

Distinguish activity/output measures from structural, process, and outcome indicators linked to rights and HRBA principles.

Before moving on, remember:

- use only fictional or generalized examples;
- avoid names, raw data, stories, photos, audio, video, or confidential records;
- use evidence to improve participation, inclusion, accountability, and learning.

Next: **Disaggregation and Inclusion Evidence**.

### Learner action

Review indicator learning and continue to disaggregation.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---


# M07-L03 — Disaggregation and Inclusion Evidence

## M7-S3-01 — Scenario hook

A project team wants to show whether persons with disabilities participated in a small training group.

The group is small. If the team shows too much detail, some people might be identifiable.

Disaggregation can help reveal exclusion. But it can also create risk if small numbers, sensitive categories, or local knowledge make people identifiable.

### Learner action

Read a fictional small-sample data scenario and notice privacy risks.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/disaggregation-safety-checklist.pdf

### Button

Continue

---

## M7-S3-02 — Plain-language explainer

Disaggregation means looking at data by relevant categories, such as gender, age, disability, location, language, or other broad barriers.

It can help reveal who is included and who is missing.

But disaggregation must be safe.

Before collecting or sharing disaggregated data, ask:

- Is this information necessary?
- Could it identify or stigmatize people?
- Is the group too small to show safely?
- Was consent and purpose clear?
- Can we use broader categories or aggregate results?
- Will the information lead to better action?

### Learner action

Understand when disaggregation helps inclusion and when it can create risk.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---

## M7-S3-03 — Guided practice

A fictional project worked with a very small group of participants. The team wants to publish detailed data by disability, age, location, and gender.

Choose the safest option:

A. Publish the full breakdown because disaggregation is always good.  
B. Aggregate or suppress small categories, explain the limitation, and use safer qualitative learning without identifying people.  
C. Collect names so the data is clearer.  
D. Avoid all inclusion evidence forever.

Best response: B

Feedback should explain that disaggregation is valuable only when it is useful, safe, consented, and non-identifying.

### Learner action

Decide whether to disaggregate, aggregate, anonymize, or avoid collection.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

tools/module7/disaggregation-safety-checklist.pdf

### Button

Submit and view feedback

---

## M7-S3-04 — Private reflection/tool

Use the private disaggregation safety checklist.

Before collecting or sharing a breakdown, check:

- Is the data necessary?
- Is the purpose clear?
- Could people be identified?
- Could the category stigmatize people?
- Are numbers too small?
- Was consent clear?
- Can we aggregate or anonymize?
- Will the evidence lead to safer action?

Save privately or download for offline use.

### Learner action

Use a private checklist to test whether a breakdown is useful and safe.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/disaggregation-safety-checklist.pdf

### Button

Continue

---

## M7-S3-05 — Formative check

Question: What should you check before sharing disaggregated data?

A. Whether it looks impressive.  
B. Whether it could identify or stigmatize people.  
C. Whether it has many colors.

Best response: B

Feedback for A: Not quite. Data should be useful and safe, not only impressive.  
Feedback for B: That’s right. Disaggregation should reveal exclusion without identifying, stigmatizing, or exposing people.  
Feedback for C: Not quite. Visual design matters, but safety and identification risk come first.

### Learner action

Answer a short formative check about safe sharing of disaggregated data.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Submit and view feedback

---

## M7-S3-06 — Lesson summary and transition

Key takeaway:

Use disaggregation carefully to reveal exclusion without exposing people or creating stigma.

Before moving on, remember:

- use only fictional or generalized examples;
- avoid names, raw data, stories, photos, audio, video, or confidential records;
- use evidence to improve participation, inclusion, accountability, and learning.

Next: **Feedback and Community Voice**.

### Learner action

Review safe disaggregation and continue to feedback loops.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---


# M07-L04 — Feedback and Community Voice

## M7-S4-01 — Scenario hook

A CSO has a feedback box at a project site.

People submit comments. The team counts the number of comments and reports the number to a donor.

But community members do not know:

- who reads the feedback;
- whether action is taken;
- what changed because of feedback;
- how sensitive concerns are handled safely.

A feedback loop is not complete when feedback is collected. It becomes accountable when feedback is safely considered, acted on where possible, and reported back.

### Learner action

Read a fictional feedback-box example where collection happens but response is missing.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/feedback-loop-repair-note.pdf

### Button

Continue

---

## M7-S4-02 — Plain-language explainer

A feedback loop is more than a box, hotline, or form.

A rights-based feedback loop includes:

1. Listen safely.
2. Analyze what feedback shows.
3. Decide what can change.
4. Act where possible.
5. Report back to communities.
6. Learn and adapt.

If people give feedback but never hear what happened, accountability remains weak.

### Learner action

Understand the feedback loop: listen, analyze, decide, act, report back, and learn.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---

## M7-S4-03 — Guided practice

Repair the fictional feedback loop by putting the missing steps in order.

Steps:

1. Listen safely.
2. Analyze feedback.
3. Decide what can change.
4. Act where possible.
5. Report back to communities.
6. Learn and adapt.

The key repair is that feedback must lead to response, explanation, and learning — not only collection.

### Learner action

Add missing respond/report-back steps to a fictional feedback loop.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

tools/module7/feedback-loop-repair-note.pdf

### Button

Continue

---

## M7-S4-04 — Private reflection/tool

Write one safe report-back step for a fictional feedback loop.

Prompt:

**After reviewing feedback, the CSO will report back by...**

Safe examples:

- explaining the change made after feedback;
- explaining why some requests cannot be met;
- sharing a simple summary without names or complaint details;
- adjusting the feedback channel to be more accessible.

### Learner action

Write one safe report-back step using a fictional example.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/feedback-loop-repair-note.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M7-S4-05 — Formative check

Question: When is a feedback loop complete?

A. When feedback is collected.  
B. When feedback is safely considered, acted on where possible, and reported back.  
C. When a donor report is submitted.

Best response: B

Feedback for A: Not quite. Collection is only the first step.  
Feedback for B: That’s right. Accountability requires safe consideration, action where possible, report-back, and learning.  
Feedback for C: Not quite. Donor reporting does not replace accountability to communities.

### Learner action

Answer a short formative check about when a feedback loop is complete.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Submit and view feedback

---

## M7-S4-06 — Lesson summary and transition

Key takeaway:

Strengthen feedback loops so communities are listened to, responses are explained, and action is reported back safely.

Before moving on, remember:

- use only fictional or generalized examples;
- avoid names, raw data, stories, photos, audio, video, or confidential records;
- use evidence to improve participation, inclusion, accountability, and learning.

Next: **Qualitative Evidence and Stories**.

### Learner action

Review feedback accountability and continue to qualitative evidence and stories.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---


# M07-L05 — Qualitative Evidence and Stories

## M7-S5-01 — Scenario hook

A donor asks a fictional CSO to share a powerful community story for a report.

The team knows stories can help people understand change. But stories can also create harm if people feel pressured, are identifiable, or share painful details without proper support and consent.

In this lesson, you will practice using qualitative evidence and stories ethically.

### Learner action

Read a fictional donor-story request and identify ethical risks.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/ethical-story-checklist.pdf

### Button

Continue

---

## M7-S5-02 — Plain-language explainer

Stories and qualitative evidence can help CSOs understand experience, dignity, barriers, and change.

But stories must be handled ethically.

Before collecting or using a story, ask:

- Is participation voluntary?
- Is consent informed and specific?
- Could the person be identified?
- Could sharing the story create harm?
- Is there a safer way to share the lesson without personal details?
- Does the story respect dignity and avoid pity or sensationalism?
- Is referral or safeguarding support needed?

### Learner action

Understand when stories can help learning and when they can create harm.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---

## M7-S5-03 — Guided practice

Review this fictional story request:

“Please send a powerful story with the person’s name, photo, location, and details of what happened.”

Choose the safer response:

A. Share the story quickly because the donor needs it.  
B. Ask for more painful details to make the story stronger.  
C. Pause and check consent, safety, anonymization, purpose, dignity, alternatives, and whether a composite or learning summary would be safer.  
D. Never use qualitative evidence.

Best response: C

Feedback should explain that ethical qualitative evidence protects dignity, consent, safety, and choice.

### Learner action

Apply a story-safety checklist to a fictional example.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

tools/module7/ethical-story-checklist.pdf

### Button

Submit and view feedback

---

## M7-S5-04 — Private reflection/tool

Apply the ethical story checklist to a fictional story request.

Check whether the approach protects:

- voluntary participation;
- informed consent;
- dignity;
- privacy;
- safety;
- anonymization;
- referral or support needs;
- the person’s right to decline;
- alternatives such as composite stories or learning summaries.

### Learner action

Choose a safer evidence option for a fictional story request.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/ethical-story-checklist.pdf

### Buttons

Download or open template
Complete in platform
Save privately if supported
Continue

---

## M7-S5-05 — Formative check

Question: What is the safest first step before using a participant story?

A. Ask for more emotional detail.  
B. Check consent, dignity, safety, anonymity, purpose, and alternatives.  
C. Publish it quickly because stories are powerful.

Best response: B

Feedback for A: Not quite. Asking for more emotional detail can create pressure and harm.  
Feedback for B: That’s right. Ethical stories require consent, dignity, safety, anonymity, clear purpose, and safer alternatives where needed.  
Feedback for C: Not quite. Powerful stories can still create risk if used without careful consent and protection.

### Learner action

Answer a short formative check about ethical use of stories.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Submit and view feedback

---

## M7-S5-06 — Lesson summary and transition

Key takeaway:

Use stories and qualitative evidence ethically, with consent, dignity, safety, and no pressure to disclose.

Before moving on, remember:

- use only fictional or generalized examples;
- avoid names, raw data, stories, photos, audio, video, or confidential records;
- use evidence to improve participation, inclusion, accountability, and learning.

Next: **Learning and Adaptation**.

### Learner action

Review ethical evidence use and continue to learning and adaptation.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---


# M07-L06 — Learning and Adaptation

## M7-S6-01 — Scenario hook

A project team reviews its MEAL evidence and notices a pattern:

- attendance is good overall;
- young women from remote areas participate less;
- feedback says meeting times are difficult;
- some people do not understand how decisions are made.

The question is not only, “How do we report this?”

The rights-based question is: **What should we change?**

### Learner action

Read a fictional example where evidence shows participation barriers and the team must adapt.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/adaptation-decision-note.pdf

### Button

Continue

---

## M7-S6-02 — Plain-language explainer

Learning and adaptation means using evidence to improve practice.

It is not enough to collect data and write reports.

A rights-based learning cycle asks:

- What is the evidence telling us?
- Who is missing or facing barriers?
- What feedback needs a response?
- What risk or harm should we avoid?
- What can we change now?
- What should we monitor next?

Adaptation should be safe, realistic, documented, and explained back where appropriate.

### Learner action

Understand learning and adaptation as evidence-informed changes in practice.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---

## M7-S6-03 — Guided practice

Use this fictional evidence:

- young women from remote areas participate less;
- feedback says the meeting time is difficult;
- participants ask for simpler information before meetings.

Choose the most rights-based adaptation:

A. Keep the same plan because attendance is still high.  
B. Adjust timing, improve pre-meeting information, and monitor whether participation becomes more inclusive.  
C. Collect names of all people who did not attend.  
D. Ignore feedback until the final report.

Best response: B

Feedback should explain that adaptation uses evidence to reduce barriers and improve participation safely.

### Learner action

Choose an appropriate adaptation based on safe sample evidence.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

tools/module7/adaptation-decision-note.pdf

### Button

Submit and view feedback

---

## M7-S6-04 — Private reflection/tool

Save one private Module 7 evidence-use action.

Prompt:

**One evidence-use practice I want to strengthen is...**

Options:

- ask who was included and excluded;
- improve one HRBA indicator;
- check disaggregation safety;
- repair a feedback loop;
- handle stories more ethically;
- document one adaptation decision;
- use evidence to report back to communities.

This becomes your private Module 7 portfolio checkpoint.

### Learner action

Save one private Module 7 evidence-use action using broad, safe language.

### Safety helper

Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

tools/module7/adaptation-decision-note.pdf

### Buttons

Save privately
Skip for now
Continue

---

## M7-S6-05 — Formative check

Question: What is evidence-based adaptation?

A. Changing activities randomly.  
B. Using safe evidence and feedback to improve decisions and practice.  
C. Waiting until the final report before making any change.

Best response: B

Feedback for A: Not quite. Adaptation should be based on evidence, learning, and risk awareness.  
Feedback for B: That’s right. Evidence-based adaptation uses safe evidence and feedback to improve decisions and practice.  
Feedback for C: Not quite. If evidence shows barriers or risks, learning should inform decisions before the final report where possible.

### Learner action

Answer a short formative check about evidence-based adaptation.

### Feedback rule

Best responses use “That’s right” or “Good choice.” Weaker responses use “Not quite.” Do not use pass/fail language.

### Completion rule

Complete interaction and view feedback; retry allowed where supported; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Submit and view feedback

---

## M7-S6-06 — Module summary and next step

You have completed Module 7.

In this module, you practiced using MEAL and evidence to strengthen rights-based practice. You reviewed how to:

- move beyond counting activities;
- improve HRBA indicators;
- use disaggregation safely;
- close feedback loops;
- handle qualitative evidence and stories ethically;
- use evidence for learning and adaptation.

Module 7 checks and tools were formative. Your certificate is linked to the final course test with a score of 80% or above.

Next, you will continue toward stronger accountability, learning, and action planning across the course.

### Learner action

Review Module 7 and transition to the next module.

### Completion rule

Read/complete and continue; no certificate effect.

### Asset reference

See asset register if visual applies.

### Button

Continue

---


## Module 7 next step

In the next part of the course, you will continue connecting rights-based evidence to accountability, learning, and action. Your private Module 7 tools can help you strengthen indicators, disaggregation choices, feedback loops, ethical evidence use, and adaptation decisions.

### Button

Continue
