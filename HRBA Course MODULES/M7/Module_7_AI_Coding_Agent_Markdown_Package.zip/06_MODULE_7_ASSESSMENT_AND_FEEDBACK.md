# Module 7 Assessment and Feedback Map

## Module assessment rule

All Module 7 checks are **formative only**. They help participants practice rights-based MEAL and evidence use.

Module 7 checks do **not**:

- issue a certificate;
- unlock a certificate;
- replace the final course test;
- rank the participant;
- rank the CSO;
- require sensitive information;
- require document uploads;
- require real datasets, feedback records, stories, photos, audio, video, names, complaints, safeguarding details, or confidential evidence.

The course certificate remains linked to the **final course test with a score of 80% or above**.

## Assessment sequence

| Item/check | Lesson | Question/prompt | Options | Best/correct answer | Source feedback | Formative status | Certificate implication | Accessibility note | Safety note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KC-M7-01 | M07-L01 | Which question makes MEAL more rights-based? | A. How many people attended? \| B. Who was included or left out, what did they say, and what changed? \| C. How many photos were taken? | B | Feedback: Attendance is useful but not enough. Rights-based MEAL also asks who is included, who is excluded, and how evidence changes action. | Formative | No certificate implication | Keyboard/tap/screen-reader MCQ | No real data. |
| KC-M7-02 | M07-L02 | Which is closest to a process indicator? | A. Existence of a policy \| B. Number of safe feedback sessions held with report-back \| C. Change in trust after response | B | Feedback: Process indicators track efforts and practice. Structural indicators show commitments; outcome indicators show change. | Formative | No certificate implication | MCQ with text alternatives | Use fictional examples. |
| KC-M7-03 | M07-L03 | What should you check before sharing disaggregated data? | A. Whether it looks impressive \| B. Whether it could identify or stigmatize people \| C. Whether it has many colors | B | Feedback: Disaggregation should reveal exclusion without exposing people. | Formative | No certificate implication | MCQ | No small-cell disclosure. |
| KC-M7-04 | M07-L04 | When is a feedback loop complete? | A. When feedback is collected \| B. When feedback is safely considered, acted on where possible, and reported back \| C. When a donor report is submitted | B | Feedback: Accountability requires response and report-back, not only collection. | Formative | No certificate implication | MCQ | No real complaints. |
| KC-M7-05 | M07-L05 | What is the safest rule for stories? | A. Use any strong story \| B. Use stories only with purpose, consent, dignity, anonymization and the right not to share \| C. Use names to make stories credible | B | Feedback: Ethical evidence protects dignity and choice. | Formative | No certificate implication | MCQ | No real stories. |
| KC-M7-06 | M07-L06 | What should evidence lead to? | A. Only a donor report \| B. Learning, safe adaptation and report-back \| C. More data collection even when not needed | B | Feedback: HRBA MEAL uses evidence to improve practice and accountability. | Formative | No certificate implication | MCQ | Use safe evidence only. |

# Repaired learner-facing formative checks

## M07-L01 — What Makes MEAL Rights-Based? formative check

Question: Which question makes MEAL more rights-based?

A. How many people attended?  
B. Who was included or left out, what did they say, and what changed?  
C. How many photos were taken?

Best response: B

Feedback for A: Not quite. Attendance is useful, but it does not show inclusion, voice, accountability, or change by itself.  
Feedback for B: That’s right. Rights-based MEAL asks who is included, who is left out, what people said, and what changed because of evidence.  
Feedback for C: Not quite. Photos can create privacy and consent risks and do not show rights-based quality by themselves.

## M07-L02 — HRBA Indicators formative check

Question: Which is closest to a process indicator?

A. Existence of a policy.  
B. Number of safe feedback sessions held with report-back.  
C. Change in trust after response.

Best response: B

Feedback for A: Not quite. Existence of a policy is closer to a structural indicator because it shows a formal commitment or framework.  
Feedback for B: That’s right. Process indicators track efforts and practices, such as safe feedback sessions and report-back.  
Feedback for C: Not quite. Change in trust is closer to an outcome indicator because it shows a change experienced by people.

## M07-L03 — Disaggregation and Inclusion Evidence formative check

Question: What should you check before sharing disaggregated data?

A. Whether it looks impressive.  
B. Whether it could identify or stigmatize people.  
C. Whether it has many colors.

Best response: B

Feedback for A: Not quite. Data should be useful and safe, not only impressive.  
Feedback for B: That’s right. Disaggregation should reveal exclusion without identifying, stigmatizing, or exposing people.  
Feedback for C: Not quite. Visual design matters, but safety and identification risk come first.

## M07-L04 — Feedback and Community Voice formative check

Question: When is a feedback loop complete?

A. When feedback is collected.  
B. When feedback is safely considered, acted on where possible, and reported back.  
C. When a donor report is submitted.

Best response: B

Feedback for A: Not quite. Collection is only the first step.  
Feedback for B: That’s right. Accountability requires safe consideration, action where possible, report-back, and learning.  
Feedback for C: Not quite. Donor reporting does not replace accountability to communities.

## M07-L05 — Qualitative Evidence and Stories formative check

Question: What is the safest first step before using a participant story?

A. Ask for more emotional detail.  
B. Check consent, dignity, safety, anonymity, purpose, and alternatives.  
C. Publish it quickly because stories are powerful.

Best response: B

Feedback for A: Not quite. Asking for more emotional detail can create pressure and harm.  
Feedback for B: That’s right. Ethical stories require consent, dignity, safety, anonymity, clear purpose, and safer alternatives where needed.  
Feedback for C: Not quite. Powerful stories can still create risk if used without careful consent and protection.

## M07-L06 — Learning and Adaptation formative check

Question: What is evidence-based adaptation?

A. Changing activities randomly.  
B. Using safe evidence and feedback to improve decisions and practice.  
C. Waiting until the final report before making any change.

Best response: B

Feedback for A: Not quite. Adaptation should be based on evidence, learning, and risk awareness.  
Feedback for B: That’s right. Evidence-based adaptation uses safe evidence and feedback to improve decisions and practice.  
Feedback for C: Not quite. If evidence shows barriers or risks, learning should inform decisions before the final report where possible.

## Assessment data map

| Assessment/tool | Required saved data | Optional saved data | Do not save |
|---|---|---|---|
| Evidence-use sorting/check | Completion status | Selected category/answer | Real data, names, stories |
| Indicator check/lab | Completion status | Private fictional indicator draft if saved | Real donor indicators, project records |
| Disaggregation safety check | Completion status | Private checklist choices if saved | Small-cell raw data or sensitive categories |
| Feedback loop check | Completion status | Private repair note if saved | Real complaint details |
| Ethical story check | Completion status | Private checklist choices if saved | Real stories, photos, audio, video, names |
| Adaptation check | Completion status | Private adaptation note if saved | Real datasets, reports, confidential evidence |
