# Copy/Paste Prompt for Coding Agent — Module 7

You are implementing **Module 7: HRBA in MEAL and Evidence Use** for the CSO Learning Hub course **Applying the Human Rights-Based Approach (HRBA) in CSO Practice**.

Use this Markdown package as the controlled source of truth. Do not use the original production workbook directly unless specifically instructed. Build the learner-facing Module 7 course-player experience only.

## Plan first

Before editing code, produce a short implementation plan that identifies:

1. routes/components/files you will update;
2. how you will represent the approved Module 7 six-lesson sequence and 36 screens/blocks;
3. how you will implement sorting, indicator lab, disaggregation safety decision, feedback loop repair, ethical story checklist, adaptation decision, private reflections, MCQ checks, and summary;
4. how privacy and data-saving will work;
5. how certificate logic will remain untouched;
6. how accessibility and low-bandwidth requirements will be met;
7. any missing assets and how placeholder components will be used.

Do not proceed with code until the plan is clear.

## Source files in this package

Use these files:

- `01_MODULE_7_OVERVIEW.md`
- `02_MODULE_7_SCREEN_BY_SCREEN_CONTENT.md`
- `03_MODULE_7_BLOCK_STORYBOARD.md`
- `04_MODULE_7_INTERACTION_LOGIC.md`
- `05_MODULE_7_REFLECTION_PORTFOLIO_LOGIC.md`
- `06_MODULE_7_ASSESSMENT_AND_FEEDBACK.md`
- `07_MODULE_7_DESIGN_AND_VISUAL_SPEC.md`
- `08_MODULE_7_SAFETY_ACCESSIBILITY_DATA_RULES.md`
- `09_MODULE_7_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`
- `10_MODULE_7_BUILD_ACCEPTANCE_CRITERIA.md`

## Required implementation

Implement Module 7 with:

1. approved title: **HRBA in MEAL and Evidence Use**;
2. approved six-lesson sequence;
3. 36 learner-facing screens/blocks;
4. exact learner-facing text from `02_MODULE_7_SCREEN_BY_SCREEN_CONTENT.md`;
5. formative checks and repaired feedback from `06_MODULE_7_ASSESSMENT_AND_FEEDBACK.md`;
6. deterministic logic from `04_MODULE_7_INTERACTION_LOGIC.md`;
7. private portfolio/tool behavior from `05_MODULE_7_REFLECTION_PORTFOLIO_LOGIC.md`;
8. visual design rules from `07_MODULE_7_DESIGN_AND_VISUAL_SPEC.md`;
9. safety/accessibility rules from `08_MODULE_7_SAFETY_ACCESSIBILITY_DATA_RULES.md`;
10. asset references from `09_MODULE_7_ASSET_PLACEHOLDERS_AND_ALT_TEXT.md`.

## Hard constraints

Do not:

- expose screen IDs, block IDs, source IDs, evidence IDs, QA notes, or implementation metadata to learners;
- include source inventories, evidence packs, change logs, approval locks, or review history;
- use “Incorrect,” “Wrong,” “Failed,” or pass/fail language;
- imply Module 7 checks, tools, worksheets, story activities, or reflections affect the certificate;
- issue or unlock certificates from Module 7;
- request real datasets, reports, feedback records, stories, photos, audio, video, names, complaints, safeguarding details, confidential records, political details, raw organizational data, or uploads;
- send raw reflections, worksheet entries, optional notes, evidence-use drafts, story notes, or portfolio content to AI services;
- make tools download-only;
- use drag-and-drop-only interactions;
- invent asset filenames;
- add public peer exchange or public sharing of evidence-use notes.

Must:

- use “Not quite” for weaker responses;
- use “That’s right” or “Good choice” for best responses;
- keep all Module 7 checks/tools/reflections formative;
- state certificate eligibility remains tied to final course test score of 80% or above;
- keep tool outputs and evidence-use notes private by default;
- provide downloadable and in-platform worksheet/tool options where feasible;
- ensure keyboard, tap, screen-reader, and low-bandwidth support;
- use DEC/CSO Learning Hub colors and premium card-based course-player design;
- use safe fictional/synthetic examples only.

## Acceptance criteria

Use `10_MODULE_7_BUILD_ACCEPTANCE_CRITERIA.md` as the final QA checklist. The implementation is not complete until every acceptance check passes.

## Evidence pack required after implementation

After completing the work, provide:

1. summary of implementation;
2. files changed;
3. routes/screens affected;
4. components created or updated;
5. data/schema changes, if any;
6. role/permission changes, if any;
7. certificate logic confirmation;
8. safety/privacy confirmation;
9. accessibility and low-bandwidth confirmation;
10. asset handling summary;
11. tests/checks run and results;
12. known gaps or missing assets;
13. manual verification steps.

## Final verification

Verify at minimum:

- Module 7 route loads;
- approved six lessons appear;
- all 36 screens/blocks are reachable;
- sorting, indicator lab, disaggregation decision, feedback loop repair, ethical story checklist, adaptation decision, MCQs, and private reflections work;
- sorting has non-drag alternatives;
- visuals/tables/process blocks have text alternatives;
- tools have in-platform and download options where feasible;
- evidence-use notes are private by default;
- feedback uses “Not quite,” “That’s right,” and “Good choice” as specified;
- no Module 7 activity triggers certificate logic;
- no sensitive fields or uploads are requested;
- missing assets render as placeholders using approved references.
