# Module 7 Safety, Accessibility, and Data Rules

## Safety principle

Module 7 has a high safety level because MEAL evidence can include real datasets, feedback records, complaint information, photos, audio, video, stories, names, sensitive categories, and raw organizational data.

The module must help learners practice rights-based MEAL safely without exposing people, communities, organizations, cases, complaints, safeguarding records, or confidential evidence.

## Safety rules from source workbook

| Safety rule | Where addressed | Learner-facing wording | Pass condition | Repetition-reduction decision | Boundary type |
| --- | --- | --- | --- | --- | --- |
| No real MEAL data | All lessons/tools | Use the fictional examples in this lesson. Do not enter or upload real datasets, reports, feedback records, stories, photos, audio, video, or names. | Pass if all prompts use sample data only. | Repeat before data/story activities only. | Data-minimization boundary |
| Private by default | Tools and reflections | Your notes and tool outputs are for your own learning. They are not part of your certificate. | Pass if tools are not required for certificate. | State once in tool intro and summary. | Evidence visibility boundary |
| Safe disaggregation | Lesson 3 | Use disaggregation only when it helps inclusion and can be done without identifying or stigmatizing people. | Pass if no small-cell or sensitive category exposure. | Include before activity. | Disaggregation safety boundary |
| Ethical stories | Lesson 5 | Do not use real stories in this course activity. In real work, use stories only with consent, dignity, clear purpose, anonymization, and the right not to share. | Pass if all examples are fictional. | Include before story scenario. | Story safety boundary |
| Feedback safety | Lesson 4 | Do not share real complaints or feedback details. Practice with the fictional feedback loop only. | Pass if no real complaint prompt exists. | Include before feedback loop activity. | Feedback privacy boundary |
| Peer exchange deferred | Peer exchange | Peer exchange is not included in the required self-paced flow. Future use requires moderation and safe prompts. | Pass if no peer step blocks completion. | Not repeated in learner flow. | Consent/moderation boundary |

## Do not request

Never ask learners to submit:

- real datasets;
- reports;
- feedback records;
- stories;
- photos;
- audio;
- video;
- names;
- complaint files;
- safeguarding or protection details;
- beneficiary lists;
- confidential records;
- political details;
- raw organizational data;
- uploads.

## Safe alternatives

Use:

- fictional examples;
- synthetic sample evidence;
- broad categories;
- generalized notes;
- structured choices;
- optional private notes with safety helper text;
- safe summaries instead of raw evidence.

## Story and qualitative evidence boundary

Use this before story activities:

> Do not enter real stories, names, photos, audio, video, case details, complaint information, or safeguarding details. Use the fictional example only.

## Disaggregation boundary

Use this before disaggregation activities:

> Use disaggregation only when it helps inclusion and can be done without identifying or stigmatizing people.

## Privacy rules

| Data type | Default visibility |
|---|---|
| Tool outputs | Private by default |
| Optional reflections | Private by default |
| Indicator drafts | Private by default |
| Disaggregation checklist choices | Private by default |
| Story checklist choices | Private by default |
| Assessment completion | Learner/system only |
| Assessment score/response | Formative only; no certificate effect |
| Admin analytics | Aggregated only, no raw evidence |

## Accessibility and low-bandwidth QA

| QA area | Scope | Requirement | Pass condition | Status |
| --- | --- | --- | --- | --- |
| Keyboard access | All interactive elements | All MCQs, checklists, sorting alternatives and forms are keyboard navigable. | Pass | Approved |
| Screen-reader labels | All interactions and forms | Labels describe purpose, question, options, state and feedback. | Pass | Approved |
| Visible focus | All buttons/inputs | DEC blue or high-contrast focus ring visible; no focus hidden. | Pass | Approved |
| Alt text | All visuals | Every visual has concise alt text and/or text equivalent. | Pass | Draft planning |
| Text alternatives | Diagrams/tables/checklists | Indicator tables, feedback loops, disaggregation checklists, story checklists, learning-use plans and adaptation cycles have text equivalents. | Pass | Draft planning |
| Non-drag alternatives | Sorting/sequencing | Sorting and sequencing activities include select-list or radio-list alternatives. | Pass | Approved |
| Accessible tools/PDFs | Worksheets | PDFs optional; in-platform accessible version required. | Pass | Filename pending |
| Mobile readability | All lessons | Single-column mobile layout; tables converted to cards where needed. | Pass | Approved |
| Low-bandwidth fallback | All media/visuals | Essential learning remains usable without image downloads. | Pass | Approved |
| Reduced motion | All interactions | Avoid unnecessary animation; provide reduced-motion behavior for diagrams/processes. | Pass | Approved |

## AI/data restriction

Raw reflections, optional notes, indicators, disaggregation choices, feedback records, story notes, adaptation notes, and portfolio content should not be sent to AI services. If AI is later used for safe summaries, use structured non-sensitive tags or participant-approved safe summaries only.

## Safe helper text

Use before any optional text field or tool output:

> Keep this safe and general. Do not include real data, reports, names, stories, complaints, safeguarding details, identifiable photos/audio/video, confidential records, political details, raw organizational data, or uploads.
