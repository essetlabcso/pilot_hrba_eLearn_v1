# Module 7 Interaction Logic

## Global rules

```text
Module 7 checks, tools, and reflections are formative only.
Certificate eligibility is not calculated in Module 7.
Certificate eligibility remains linked to the final course test with score >= 80%.

Do not expose to learners:
  screen IDs
  block IDs
  source IDs
  QA notes
  reviewer notes
  approval metadata
  implementation metadata

Do not request:
  real datasets
  reports
  feedback records
  stories
  photos
  audio
  video
  names
  complaints
  safeguarding/protection details
  confidential records
  political details
  raw organizational data
  uploads
```

## Required completion logic

```text
Module 7 is complete when:
  lesson 1 scenario/explainer/practice/reflection/check/summary completed or viewed
  lesson 2 scenario/explainer/indicator lab/tool/check/summary completed or viewed
  lesson 3 scenario/explainer/safety decision/checklist/check/summary completed or viewed
  lesson 4 scenario/explainer/feedback loop repair/tool/check/summary completed or viewed
  lesson 5 scenario/explainer/story checklist/tool/check/summary completed or viewed
  lesson 6 scenario/explainer/adaptation decision/portfolio checkpoint/check/summary completed or viewed

Tool outputs and reflections may save privately, but private save/download must not affect certificate eligibility.
```

## Interaction map

| Interaction ID | Lesson | Title | Type | Prompt/question | Response behavior | Feedback behavior | Completion rule | Scoring | Portfolio/proof | Safety/privacy | Accessibility |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| INT-M7-01 | M07-L01 | Evidence-use dilemma sorting | Sorting / non-drag list | Sort evidence uses into count-only, rights-based quality, and unsafe/excessive evidence. | Learner selects category per card; accessible list alternative. | Best and partial feedback explains why attendance alone is incomplete and unsafe data is excessive. | Complete once; retry allowed. | Formative only | None | No real data; safe sample evidence only. | Keyboard, tap and screen-reader accessible; no drag-only interaction. |
| INT-M7-02 | M07-L02 | Indicator repair lab | Tool activity + MCQ | Choose strongest HRBA indicator and improve one weak fictional indicator. | Learner selects best option and optionally writes a revised indicator. | Feedback explains activity/output/process/outcome distinction. | MCQ complete required; worksheet optional. | Formative only | Optional private portfolio note | No real project indicators required. | Accessible text input and table alternative. |
| INT-M7-03 | M07-L03 | Disaggregation safety decision | Checklist + scenario decision | Decide whether to disaggregate, aggregate, anonymize, or avoid collection. | Learner selects safest option for fictional small-sample scenario. | Feedback explains inclusion value and small-cell risk. | Complete once; retry allowed. | Formative only | Optional private checklist | No sensitive categories that could identify people. | Checklist with visible focus; no color-only risk categories. |
| INT-M7-04 | M07-L04 | Feedback-loop repair | Process activity | Add missing respond/report-back steps to a feedback loop. | Learner orders listen, analyze, decide, act, report back, learn. | Feedback emphasizes closing the loop safely. | Complete sequence or list alternative. | Formative only | Private feedback-loop note | No real complaints or complainant details. | Non-drag sequencing alternative. |
| INT-M7-05 | M07-L05 | Ethical story decision | Scenario decision | Decide whether a fictional story can be used, anonymized, summarized, or not used. | Learner chooses action and reason. | Feedback emphasizes consent, dignity, purpose, anonymization, and right not to share. | Complete once; retry allowed. | Formative only | Optional private ethical-story checklist | No real stories from rights-holders, survivors, children or vulnerable groups. | Screen-reader labels and text scenario. |
| INT-M7-06 | M07-L06 | Adaptation decision | Scenario decision + plan | Choose a safe adaptation based on fictional evidence and plan a report-back step. | Learner selects adaptation option and optional learning-use plan fields. | Feedback emphasizes evidence-to-action and accountability. | Decision required; plan optional/private. | Formative only | Optional private learning-use plan | Do not expose staff failure, conflict or real community tension. | Accessible form; mobile stacked fields. |

## Core behavior rules

### Sorting behavior

```text
For evidence-use sorting:
  provide non-drag alternatives:
    dropdown
    tap-select cards
    keyboard-selectable category buttons
  categories:
    count-only evidence
    rights-based quality evidence
    unsafe/excessive evidence
  show immediate explanatory feedback
  allow retry
  no certificate effect
```

### Indicator lab behavior

```text
For indicator repair:
  learner selects strongest indicator from options
  optional revised indicator field may be shown
  optional text is private and skippable
  do not ask for real donor indicators or project data
  show feedback explaining activity/output/process/outcome distinction
```

### Disaggregation safety behavior

```text
For disaggregation activities:
  always show safety reminder before learner action
  scenario uses synthetic small-sample data only
  learner may choose disaggregate, aggregate, anonymize, suppress, or avoid collection
  feedback explains inclusion value and small-cell identification risk
```

### Feedback loop behavior

```text
For feedback loop repair:
  allow sequence ordering OR accessible list alternative
  expected sequence:
    listen safely
    analyze
    decide
    act where possible
    report back
    learn and adapt
  feedback emphasizes closing the loop safely
```

### Ethical story behavior

```text
For story/qualitative evidence activities:
  use fictional story request only
  checklist covers consent, dignity, safety, anonymity, purpose, alternatives, and right to decline
  do not collect real stories
  do not ask for photos/audio/video
```

### Adaptation behavior

```text
For learning/adaptation activities:
  use fictional evidence pattern
  learner chooses a safe adaptation
  optional action note is private
  no real data required
```

### Knowledge check behavior

```text
For MCQ checks:
  formative only
  option-level feedback required
  no pass/fail language
  no certificate effect
  use “Not quite,” not “Incorrect”
  allow retry if platform supports it
```
