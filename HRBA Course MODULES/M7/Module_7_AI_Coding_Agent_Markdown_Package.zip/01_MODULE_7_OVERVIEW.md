# Module 7 Overview

## Course

**Applying the Human Rights-Based Approach (HRBA) in CSO Practice**

## Module title

**Module 7: HRBA in MEAL and Evidence Use**

## Module role

Module 7 is a substantive HRBA MEAL practice module. It helps participants use MEAL and evidence to strengthen participation, inclusion, accountability, ethical evidence use, feedback response, and adaptive decisions.

## Recommended duration

**90–110 minutes**

## Primary audience

Local and grassroots CSO staff, MEAL staff, project officers, accountability staff, programme coordinators, learning focal persons, and CSO leaders.

## Main learner shift

From:

> “MEAL is mainly counting activities and reporting upward.”

To:

> “Rights-based MEAL uses safe, inclusive, accountable evidence to understand who is included or excluded, what people say, what changed, and how CSOs should adapt.”

## Module learning outcomes

By the end of Module 7, participants should be able to:

1. identify what makes MEAL rights-based;
2. distinguish count-only evidence from rights-based quality evidence and unsafe/excessive evidence;
3. improve a basic indicator into a stronger HRBA-aligned indicator;
4. use disaggregation carefully to reveal exclusion without identifying or stigmatizing people;
5. repair a feedback loop so feedback leads to response, report-back, and learning;
6. handle qualitative evidence and stories ethically;
7. use safe evidence for learning and adaptation;
8. save or download private Module 7 evidence-use tools without affecting certificate eligibility.

## Approved lesson sequence

1. **What Makes MEAL Rights-Based?**
2. **HRBA Indicators**
3. **Disaggregation and Inclusion Evidence**
4. **Feedback and Community Voice**
5. **Qualitative Evidence and Stories**
6. **Learning and Adaptation**

## Main portfolio/tool outputs

- Evidence-use reflection
- HRBA indicator worksheet
- Disaggregation safety checklist
- Feedback loop repair note
- Ethical story checklist
- Adaptation decision note

## Assessment rule

All Module 7 checks are formative only. They support practice and review. They do not issue a certificate, unlock a certificate, rank participants, or rank CSOs.

## Certificate rule

Certificate eligibility remains tied to the final course test with a score of **80% or above**.

## Safety level

High for evidence-use activities, because MEAL data, stories, photos, audio, feedback records, complaints, safeguarding information, and raw datasets can expose people or organizations.

## Privacy rule

Tool outputs, optional notes, evidence-use reflections, worksheet entries, and portfolio outputs are private by default.

## Sensitive data rule

Do not ask learners to provide real datasets, reports, feedback records, stories, photos, audio, video, names, complaints, safeguarding details, confidential records, political details, raw organizational data, or uploads.
