# Module 7 Asset Placeholders and Alt Text

## Asset rule

Do not invent final asset filenames or paths. Use approved source-named assets where listed. If a file is missing, use a placeholder component with the approved filename reference.

## Visual style

Use CSO Learning Hub / DEC visual identity:

- primary blue: `#3B99D4`
- accent green: `#91C852`
- deep navy: `#0F172A`
- light background: `#F9FAFB`
- white cards
- dark text: `#111827`
- subtle borders: `#E5E7EB`
- rounded corners
- soft shadows

## Asset register

| Asset ID | Asset | Type | Placement | Purpose | Filename/path if approved | Alt text | Low-bandwidth alternative | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A-M7-01 | HRBA MEAL and evidence-use module opening image | Photographic image | M07 opening scenario | Create local, respectful context for evidence-use dilemma | images/module7/hrba-meal-opening.jpg | Back/over-shoulder view of local CSO team reviewing anonymized dashboard cards; no faces; no readable sensitive text. | Text-only scenario intro with same learning point. | Pending asset |
| A-M7-02 | Rights-based MEAL shifts diagram | SVG diagram | M07-L01 | Show shift from counting activities to using evidence for rights, inclusion, accountability and adaptation | images/module7/rights-based-meal-shifts.svg | Four-column diagram: Count, Include, Listen, Adapt; DEC colors; no people. | Plain text list of four shifts. | Pending asset |
| A-M7-03 | HRBA indicator comparison table visual | In-platform table / SVG | M07-L02 | Compare activity, output, process, outcome and HRBA indicator examples | images/module7/hrba-indicator-comparison.svg | Accessible table visual with sample fictional indicators only. | HTML/in-platform accessible table. | Pending asset |
| A-M7-04 | Structural/process/outcome indicator visual | SVG diagram | M07-L02 | Explain indicator families in plain language | images/module7/spo-indicator-bridge.svg | Three connected cards: commitment, effort, change; DEC palette. | Three text cards. | Pending asset |
| A-M7-05 | Disaggregation safety visual | SVG / checklist visual | M07-L03 | Show when disaggregation helps and when it can expose risk | images/module7/disaggregation-safety-check.svg | Safe/unsafe decision flow; no sensitive group names as examples. | Checklist text alternative. | Pending asset |
| A-M7-06 | Feedback loop diagram | SVG process diagram | M07-L04 | Show listen, decide, act, report back, learn | images/module7/feedback-loop-diagram.svg | Circular process with five steps; include report-back as essential step. | Numbered list text equivalent. | Pending asset |
| A-M7-07 | Ethical storytelling checklist visual | SVG / icon checklist | M07-L05 | Show consent, dignity, purpose, anonymization, right not to share | images/module7/ethical-story-checklist.svg | Five icon cards; no poverty/suffering imagery. | Checklist text alternative. | Pending asset |
| A-M7-08 | Learning and adaptation cycle diagram | SVG process diagram | M07-L06 | Show evidence to decision to adaptation to feedback | images/module7/learning-adaptation-cycle.svg | Simple cycle with safe evidence, sensemaking, decision, action, report-back. | Text equivalent cycle. | Pending asset |
| A-M7-09 | HRBA indicator worksheet | Worksheet / in-platform tool | M07-L02 tool | Help learners improve indicators using HRBA lens | tools/module7/hrba-indicator-worksheet.pdf | N/A | Accessible in-platform form with same fields. | Filename pending |
| A-M7-10 | Disaggregation safety checklist | Worksheet / in-platform checklist | M07-L03 tool | Help learners decide whether and how to disaggregate safely | tools/module7/disaggregation-safety-checklist.pdf | N/A | Accessible in-platform checklist. | Filename pending |
| A-M7-11 | Ethical story checklist | Worksheet / in-platform checklist | M07-L05 tool | Help learners decide whether a story is safe, consented and dignified | tools/module7/ethical-story-checklist.pdf | N/A | Accessible in-platform checklist. | Filename pending |
| A-M7-12 | Learning-use plan template | Worksheet / in-platform tool | M07-L06 tool | Help learners convert evidence into safe adaptation decisions | tools/module7/learning-use-plan.pdf | N/A | Accessible in-platform form. | Filename pending |

## Asset implementation rules

- Every image/SVG must include alt text.
- Complex diagrams need text alternatives.
- PDF tools must also have in-platform field versions where feasible.
- Do not use photos that identify people or sensitive situations.
- Do not show real datasets, feedback records, complaint text, names, photos, audio, video, political signage, or confidential records.
- Avoid text-heavy images; all essential text must also exist as HTML text.
- If assets are missing, render placeholder cards using the approved filename reference.
