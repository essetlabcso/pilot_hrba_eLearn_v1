# Module 7 Design and Visual Interaction Specification

## Module title

**Module 7: HRBA in MEAL and Evidence Use**

## Design purpose

Module 7 should feel like a safe, practical MEAL studio for local CSOs. It should help learners use evidence for rights, inclusion, accountability, feedback response, ethical storytelling, and adaptation without exposing people or raw data.

The visual experience should not feel like a statistics manual, donor reporting form, data extraction interface, or story-mining tool. It should feel like guided, ethical, rights-based learning.

## Visual identity

| Use | Color |
|---|---|
| Primary action / active progress | `#3B99D4` |
| Positive accent / completion / growth | `#91C852` |
| Deep heading / navigation text | `#0F172A` |
| Main text | `#111827` |
| Secondary text | `#6B7280` |
| Background | `#F9FAFB` |
| Card background | `#FFFFFF` |
| Border | `#E5E7EB` |
| Warning / safety accent | `#F97316` |
| Critical safety warning only | `#EF4444` |

## Source visual interaction controls

| Implementation area | Required visual/interaction specification | Status |
| --- | --- | --- |
| Global visual system | Use DEC primary blue #3B99D4, accent green #91C852, deep navy #0F172A, light background #F9FAFB, white cards, dark text #111827, borders #E5E7EB, rounded corners and soft shadows. | Approved |
| Lesson layout | Short lesson intro; one key idea card; one practice activity; one private reflection/tool; one formative check; one summary/transition. | Approved |
| Indicator tables | Use accessible in-platform tables on desktop; convert to stacked cards on mobile. Do not rely on color alone. | Approved |
| Feedback loop | Process diagram with text list fallback; steps: listen, record safely, decide, act, report back, learn. | Approved |
| Disaggregation safety | Checklist and decision cards; use neutral language and avoid sensitive examples. | Approved |
| Ethical story decision | Scenario card with safe options; no emotional images, faces, or real story-like details. | Approved |
| Adaptation cycle | Simple cycle with reduced motion; no auto-animation required. | Approved |
| Safety/warning styling | Use orange #F97316 for caution notes and red #EF4444 only for critical warnings; keep safety concise. | Approved |
| Completion behavior | Completion based on reading/interaction completion, not worksheet upload. Tools optional/private. | Approved |

## Lesson design rules

| Lesson | Visual / interaction treatment |
|---|---|
| What Makes MEAL Rights-Based? | Scenario card, key idea card, sorting/non-drag list, private reflection, MCQ |
| HRBA Indicators | Indicator comparison table, repair lab, private worksheet, MCQ |
| Disaggregation and Inclusion Evidence | Safety callout, checklist, scenario decision, private checklist, MCQ |
| Feedback and Community Voice | Feedback loop process, repair activity, report-back note, MCQ |
| Qualitative Evidence and Stories | Ethical story scenario, consent/safety checklist, safer evidence option, MCQ |
| Learning and Adaptation | Evidence pattern scenario, adaptation decision log, portfolio checkpoint, MCQ, summary |

## Sensitive design rules

- Do not show real datasets, charts with realistic sensitive values, names, feedback records, complaint logs, photos, audio, video, or story documents.
- Use synthetic dashboard cards and fictional examples.
- Use orange safety callouts before data, disaggregation, feedback, story, and adaptation activities.
- Use green only for safe completion; avoid red learner-failure states.
- Story screens should avoid pity imagery, trauma imagery, and identifiable people.

## Mobile behavior

On mobile:

- all layouts become single column;
- sorting becomes selectable cards/dropdowns;
- indicator tables become stacked cards;
- checklists use large tap targets;
- process loops become vertical step cards;
- tool forms use short grouped sections;
- CTAs are full width.

## Feedback states

| State | Design rule |
|---|---|
| Best response | Green accent; text begins “That’s right” or “Good choice” |
| Weaker response | Neutral or soft amber accent; text begins “Not quite” |
| Saved portfolio | Green confirmation; “Saved privately” language |
| Safety reminder | Orange accent; calm protective tone |
| Data privacy reminder | Orange/blue callout; no frightening legal tone |

## Design no-drift rules

The coding agent must not:

- turn Module 7 into a static article;
- turn Module 7 into a generic donor-reporting lesson;
- ask for real data or uploads;
- make tools download-only;
- use drag-only sorting;
- imply Module 7 tools/checks affect certificate;
- create public peer exchange;
- use “Incorrect” feedback;
- request or display real stories, photos, audio, video, or feedback records;
- invent asset filenames;
- omit text alternatives for essential visuals.
