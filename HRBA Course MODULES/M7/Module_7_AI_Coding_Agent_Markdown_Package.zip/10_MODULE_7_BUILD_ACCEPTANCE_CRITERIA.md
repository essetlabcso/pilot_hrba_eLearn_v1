# Module 7 Build Acceptance Criteria

## Source acceptance criteria

| Criteria area | Criterion | Acceptance check | Status |
| --- | --- | --- | --- |
| Module structure | Six lesson structure preserved and sequenced logically. | Pass if lesson map and player match workbook. | Draft planning |
| Content quality | Plain, practical, local-CSO language; no manual-like long lectures. | Pass if each lesson has short explanation plus practice. | Draft planning |
| HRBA accuracy | MEAL linked to rights, participation, inclusion, accountability, transparency, feedback and adaptation. | Pass if evidence IDs support content. | Draft planning |
| Indicator quality | Indicator content correctly distinguishes structural/process/outcome and avoids overclaiming. | Pass if Lesson 2 uses OHCHR-aligned logic. | Draft planning |
| Safe disaggregation | Disaggregation content explains usefulness and risks including small-cell disclosure and stigma. | Pass if safety checklist present. | Draft planning |
| Feedback-loop quality | Feedback loop includes response and report-back, not only collection. | Pass if loop has listen-record-decide-act-report-back-learn. | Draft planning |
| Ethical evidence/story handling | Stories require dignity, consent, purpose limitation, anonymization and right not to share. | Pass if no real story prompts exist. | Draft planning |
| Assessment/certificate | All Module 7 checks are formative; certificate remains final test 80%+. | Pass if no 90% or module-score certificate logic. | Approved |
| Proof/portfolio separation | Tools/reflections are private and optional, not proof or certificate requirements. | Pass if no upload gates. | Approved |
| Safety/privacy | No real MEAL data, stories, complaint logs, raw files or names requested. | Pass if all activities use fictional/synthetic examples. | Approved |
| Assets | All assets have filenames/status, prompts, alt text and low-bandwidth alternatives. | Pass once produced/uploaded. | Pending asset |
| Accessibility | Keyboard, screen-reader, text alternatives, non-drag alternatives and mobile stacked layouts. | Pass after QA. | Draft planning |
| Final learner-facing cleanup | No internal IDs, source notes or reviewer comments visible to learners. | Pass after implementation QA. | Draft planning |

## Additional clean-package acceptance checks

| Check | Pass condition |
|---|---|
| Clean content only | Learner-facing build excludes QA history, source inventories, evidence packs, change logs, approval locks, and internal reviewer notes. |
| Approved title | Module title is “HRBA in MEAL and Evidence Use.” |
| Approved sequence | Six lessons appear in approved order. |
| Correct screen count | 36 learner-facing screens/blocks are represented. |
| Feedback wording | Weaker responses use “Not quite,” not “Incorrect.” |
| Certificate integrity | No Module 7 check, tool, worksheet, checklist, story activity, or reflection affects certificate eligibility. |
| 80% rule | Learner copy states certificate is linked to final course test score of 80% or above. |
| Portfolio privacy | Tool outputs, evidence-use notes, and optional notes are private by default. |
| No sensitive data | No screen asks for real datasets, reports, feedback records, stories, photos, audio, video, names, complaints, safeguarding details, confidential records, political details, uploads, or raw data. |
| Story ethics boundary | Story activities protect consent, dignity, safety, anonymity, purpose, alternatives, and the right to decline. |
| Disaggregation safety | Disaggregation activities include small-cell, identification, stigma, and consent risk checks. |
| Peer exchange excluded | No required peer exchange or public evidence sharing appears in the build. |
| Accessibility | All interactions are keyboard/tap accessible and screen-reader friendly. |
| Low bandwidth | Essential learning does not depend on heavy media, PDFs, uploads, or external embeds. |
| Asset control | Source-named assets are preserved; missing assets remain placeholders. |
| Metadata hidden | Learners do not see screen IDs, block IDs, source IDs, QA notes, or implementation metadata. |
